import openpyxl
from typing import List


def getParamDict(name: List[str], val: List[int], book_name: str, sheet_name: str) -> dict:
    REF_ROW1_NO = 7  # 文字がある行
    REF_ROW2_NO = 8  # 数値の行
    wb = openpyxl.load_workbook(book_name, data_only=True)      # データオンリー
    sheet = wb[sheet_name]

    for column_i in range(1, sheet.max_column + 1):
        cell_1 = sheet.cell(row=REF_ROW1_NO, column=column_i)
        cell_2 = sheet.cell(row=REF_ROW2_NO, column=column_i)
        # 値があれば
        if (cell_1.value is not None):
            name.append(cell_1.value)
        if (cell_2.value is not None):
            val.append(cell_2.value)

    wb.close()
    return name, val


def getParamDetails(name: List[str], val: List[int], book_name: str, sheet_name: str) -> dict:
    REF_ROW1_NO = 11  # 文字がある行
    REF_ROW2_NO = 12  # 数値の行
    wb = openpyxl.load_workbook(book_name, data_only=True)      # データオンリー
    sheet = wb[sheet_name]

    for column_i in range(1, sheet.max_column + 1):
        cell_1 = sheet.cell(row=REF_ROW1_NO, column=column_i)
        cell_2 = sheet.cell(row=REF_ROW2_NO, column=column_i)
        # 値があれば
        if (cell_1.value is not None):
            name.append(cell_1.value)
        if (cell_2.value is not None):
            val.append(cell_2.value)

    wb.close()
    return name, val


# ★
def getPLCParam(book_name: str, sheet_name: str) -> dict:
    """PLCの通信設定を取得"""
    REF_ROW_NO = 4
    REF_COL_NO = 2
    wb = openpyxl.load_workbook(book_name, read_only=True,
                                keep_vba=True, data_only=True)
    sheet = wb[sheet_name]
    # NOTE:行走査
    ip_address = sheet.cell(row=REF_ROW_NO, column=REF_COL_NO).value
    port = sheet.cell(row=REF_ROW_NO, column=REF_COL_NO + 1).value
    manufacturer = sheet.cell(row=REF_ROW_NO, column=REF_COL_NO + 2).value
    series = sheet.cell(row=REF_ROW_NO, column=REF_COL_NO + 3).value
    plc_protocol = sheet.cell(row=REF_ROW_NO, column=REF_COL_NO + 4).value
    transport_protocol = sheet.cell(row=REF_ROW_NO, column=REF_COL_NO + 5).value
    bit = sheet.cell(row=REF_ROW_NO, column=REF_COL_NO + 6).value
    word = sheet.cell(row=REF_ROW_NO, column=REF_COL_NO + 7).value

    plc_param = dict(ip=ip_address,
                     port=str(port),
                     manufacturer=manufacturer,
                     series=series,
                     plc_protocol=plc_protocol,
                     transport_protocol=transport_protocol,
                     bit=bit,
                     word=word,
                     double_word='')

    wb.close()
    return plc_param


# ★
def getHeaderAddress(book_name: str, sheet_name: str) -> dict:
    """先頭アドレスを取得"""
    REF_ROW_NO = 8
    REF_COL_NO = 2
    wb = openpyxl.load_workbook(book_name, read_only=True, keep_vba=True, data_only=True)
    sheet = wb[sheet_name]
    in_bit = sheet.cell(row=REF_ROW_NO, column=REF_COL_NO).value
    in_word = sheet.cell(row=REF_ROW_NO, column=REF_COL_NO + 1).value
    out_bit = sheet.cell(row=REF_ROW_NO, column=REF_COL_NO + 2).value
    out_word = sheet.cell(row=REF_ROW_NO, column=REF_COL_NO + 3).value

    address_data = dict(IN_BIT_NO=in_bit,
                        IN_WORD_NO=in_word,
                        OUT_BIT_NO=out_bit,
                        OUT_WORD_NO=out_word,
                        )
    wb.close()
    return address_data


# def getWdataDict(book_name: str, sheet_name: str) -> dict:
def getWdataDict(name: List[str], val: List[int], book_name: str, sheet_name: str) -> dict:
    REF_ROW_NO = 3
    REF_COL_NO = 3
    MAX_COL_NO = 16
    wb = openpyxl.load_workbook(book_name, data_only=True)
    sheet = wb[sheet_name]
    # dict_data = {}
    # 行走査
    for row_i in range(0, sheet.max_row):
        cell = sheet.cell(row=row_i + REF_ROW_NO, column=REF_COL_NO)
        # 値があれば
        if (cell.value is not None):
            # word用連想配列作成
            # dict_data[cell.value] = row_i
            name.append(cell.value)
            val.append(row_i)
            # 列走査
            for col_i in range(0, MAX_COL_NO):
                cell = sheet.cell(row=row_i + REF_ROW_NO, column=REF_COL_NO + col_i)
                # 値があれば
                if ((cell.value is not None) and not (col_i == 0)):
                    # bit用連想配列作成
                    # dict_data[cell.value] = col_i - 1
                    name.append(cell.value)
                    val.append(col_i - 1)
    # print(dict_data)
    wb.close()
    # return dict_data

    return name, val


# def getDdataDict(book_name: str, sheet_name: str) -> dict:
def getDdataDict(name: List[str], val: List[int], book_name: str, sheet_name: str) -> dict:

    REF_ROW_NO = 3  # 行No
    REF_COL_NO = 3  # 列No
    wb = openpyxl.load_workbook(book_name, data_only=True)
    sheet = wb[sheet_name]
    # dict_data = {}
    # 行走査
    for row_i in range(0, sheet.max_row):
        cell = sheet.cell(row=row_i + REF_ROW_NO, column=REF_COL_NO)
        # 値があれば
        if (cell.value is not None):
            # word用連想配列作成
            # dict_data[cell.value] = row_i
            name.append(cell.value)
            val.append(row_i)
    # print(dict_data)
    wb.close()
    # return dict_data
    return name, val
