# ===============================================================================
# Name      : base_inspection_page.py
# Version   : 1.0.0
# Brief     :
# Time-stamp: 2023-07-26 09:23
# Copyirght 2021 Hiroya Aoyama
# ===============================================================================
import numpy as np
from typing import Any, Optional, Tuple, List

from lib.calibration.param_basemodel import CalibrationDataModel, ImageProcParamModel, PositionData, Field, CustomBaseModel
from lib.calibration.option_basemodel import OptionModel
from lib.calibration.rv_lib.coord_h import (
    trans_img2robot_coordinates,
    calc_resolution,
    calc_offset_vector
)
from lib.calibration.read_calibration_sheet import CustomCalibrationParam

try:
    from logger import setup_logger
    logger = setup_logger(__name__)
except Exception:
    from logging import getLogger
    logger = getLogger(__name__)


class AlignmentModule():
    def __init__(self, sheet_path):
        # NOTE:インスタンス
        self.ccp = CustomCalibrationParam(sheet_path)
        
    # ===============================================================================
    # NOTE: 補正量計算に関する処理
    # ===============================================================================

    def abs_correction(self, pos: PositionData,
                       param: CalibrationDataModel) -> Tuple[float, float, float]:
        """補正結果を絶対値で出力"""
        # NOTE: ロボット座標に変換
        x, y = trans_img2robot_coordinates(pos.x, pos.y,
                                           param.matrix_data.matrix)

        dr = pos.r - param.base_position.image_position.r
        return x, y, dr

    def rel_correction(self, pos: PositionData,
                       param: CalibrationDataModel) -> Tuple[float, float, float]:
        """補正結果を相対値で出力, 近い点からの補正量"""
        points_ = np.array(param.calibration_map.image_position)
        distances = np.sqrt((points_[:, 0] - pos.x)**2 + (points_[:, 1] - pos.y)**2)
        nearest_point_idx = np.argmin(distances)
        nearest_point = points_[nearest_point_idx]
        dx = pos.x - nearest_point[0]
        dy = pos.y - nearest_point[1]
        dr = pos.r - param.base_position.image_position.r
        # NOTE: ロボット座標に変換
        dx_t, dy_t = trans_img2robot_coordinates(dx, dy,
                                                 param.matrix_data.matrix,
                                                 ignore_translation=True)
        return dx_t, dy_t, dr

    def rel_correction_with_one_base_point(self, pos: PositionData,
                                           param: CalibrationDataModel) -> Tuple[float, float, float]:
        """補正結果を相対値で出力, ベース点1個からの補正量"""
        dr = pos.r - param.base_position.image_position.r
        # NOTE: 角度によるオフセット量の変化を考慮した画像座標の差分値
        dx = pos.x - param.base_position.image_position.x
        dy = pos.y - param.base_position.image_position.y
        # NOTE: ロボット座標に変換
        dx_t, dy_t = trans_img2robot_coordinates(dx, dy,
                                                 param.matrix_data.matrix,
                                                 ignore_translation=True)
        return dx_t, dy_t, dr

    def relative_correction(self, pos: PositionData,
                            param: CalibrationDataModel) -> Tuple[float, float, float]:
        """相対補正(検出点と回転中心が合ってない時用)"""
        # NOTE: 検出点と回転中心のオフセット量計算
        dr = pos.r - param.base_position.image_position.r
        # NOTE: マスター登録時の角度を考慮したオフセットベクトル
        reference_offset_vec = calc_offset_vector(u=param.offset_vector, angle=param.base_position.image_position.r)
        # NOTE: 現在の角度を考慮したオフセットベクトル
        current_offset_vec = calc_offset_vector(u=param.offset_vector, angle=pos.r)
        # NOTE: ベクトル差分
        diff_ofs_vec = current_offset_vec - reference_offset_vec

        # NOTE: 解像度からピクセルオフセット量を計算
        resol = calc_resolution(param.matrix_data.matrix)
        dvx, dvy = diff_ofs_vec[0] / resol, diff_ofs_vec[1] / resol

        # NOTE: 角度によるオフセット量の変化を考慮した画像座標の差分値
        dx = pos.x - param.base_position.image_position.x + dvx
        dy = pos.y - param.base_position.image_position.y + dvy

        # NOTE: ロボット座標に変換
        dx_t, dy_t = trans_img2robot_coordinates(dx, dy,
                                                 param.matrix_data.matrix,
                                                 ignore_translation=True)

        return dx_t, dy_t, dr
    
  


if __name__ == '__main__':
    pass
