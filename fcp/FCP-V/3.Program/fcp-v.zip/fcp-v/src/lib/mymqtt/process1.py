from mqtt_client_module import MQTTClient
import time
import numpy as np


class Process(object):
    def __init__(self) -> None:
        self.mqtt_client = MQTTClient()
        #
        self.mqtt_client.makePublisher()
        self.mqtt_client.makeSubscriber(topic_name='/plc/read')
        #
        self.mqtt_client.startPublisherLoop()
        self.mqtt_client.startSubscriberLoop()

    def main(self):
        array = [0] * 10
        data = {"array": array}
        while self.mqtt_client.process_loop:
            # time.sleep(0.2)
            #
            idx = np.random.randint(low=0, high=9)
            val = np.random.randint(low=0, high=9)
            data["array"][idx] = val
            #
            self.mqtt_client.publishToBroker(topic='/plc/write',
                                             payload=data,
                                             qos=0)
            print(f'publish={data["array"]}')
            print(
                f'subscribe={self.mqtt_client.SubscribeFromBroker(key="array")}')


if __name__ == '__main__':
    p = Process()
    p.main()
