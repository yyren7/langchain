import time
import numpy as np
from typing import Any
import json
import paho.mqtt.client as mqtt
import base64
import cv2

# 自作ライブラリ
from .custom_queue_class import LimitedLiFoQueue


# NOTE:JSON変換
def encodeJsonToByteData(json_data: dict):
    byte_data = json.dumps(json_data)
    return byte_data


def decodeByteDataToJson(byte_data: bytes):
    json_data = json.loads(byte_data.decode('utf-8'))
    return json_data


# NOTE:画像変換
def encodeImageToByteData(image: np.array):
    _, encimg = cv2.imencode(".png", image)
    img_str = encimg.tostring()
    img_byte = base64.b64encode(img_str).decode("utf-8")
    return img_byte


def decodeByteDataToImage(img_byte: bytes):
    image_dec = base64.b64decode(img_byte)
    data_np = np.fromstring(image_dec, dtype='uint8')
    image = cv2.imdecode(data_np, 1)
    return image


def convertJson2Dataclass(json_data: dict, data_class):
    # JSONをディクショナリに変換
    dict_data = json.loads(json_data)
    # データ型に変換
    data_instance = data_class(**dict_data)
    return data_instance


def convertDataclass2Json(mqtt_data) -> str:
    # Dataclassをディクショナリに変換し、それをJSONに変換
    dict_data = mqtt_data.dict()
    json_data = json.dumps(dict_data)
    return json_data


class MQTTClient(object):
    def __init__(self) -> None:
        self.topic_name: str = ''
        self.process_loop: bool = True
        self.pub_payload: str = ''
        self.sub_payload: str = ''
        max_size = 3
        self.sub_queue = LimitedLiFoQueue(maxsize=max_size)

    ##########################################################
    # Publisher Functions
    ##########################################################

    def makePublisher(self):
        """Publisherのインスタンス生成"""
        self.pub_client = mqtt.Client()
        self.pub_client.on_connect = self.onConnectBrokerAsPublisher
        self.pub_client.on_disconnect = self.onDisconnectBrokerAsPublisher
        self.pub_client.on_publish = self.onPublishMessageToBroker

    def startPublisherLoop(self,
                           host: str = "localhost",
                           port: int = 1883,
                           keepalive: int = 60,
                           ) -> None:
        """送信ループ開始(Publisher)"""
        self.pub_client.connect(host,
                                port,
                                keepalive)
        self.pub_client.loop_start()

    def publishToBroker(self,
                        topic_name: str = '',
                        payload: any = '',
                        qos: int = 1,
                        ):
        """データを送信(Publisher)"""
        self.pub_payload = encodeJsonToByteData(payload)

        self.pub_client.publish(topic_name,
                                self.pub_payload,
                                qos)

    def stopPublisherLoop(self):
        """送信ループ停止(Publisher)"""
        self.pub_client.loop_stop()

    def killPublisherLoop(self):
        """送信ループ削除(Publisher)"""
        self.pub_client.loop_stop()
        self.pub_client.disconnect()

    def onConnectBrokerAsPublisher(self,
                                   client: mqtt.Client,
                                   userdata: Any,
                                   flag: dict,
                                   return_code: int) -> None:
        """ブローカに接続したときの処理(Publisher)"""
        print("Connected with result code " + str(return_code))

    def onDisconnectBrokerAsPublisher(self,
                                      client: mqtt.Client,
                                      userdata: Any,
                                      return_code: int) -> None:
        """ブローカが切断したときの処理(Publisher)"""
        if return_code != 0:
            print("Unexpected disconnection.")

    def onPublishMessageToBroker(self,
                                 client: mqtt.Client,
                                 userdata: Any,
                                 message_id: int) -> None:
        """Publishが完了したときの処理(Publisher)"""
        # print("publish: {0}".format(message_id))
        pass

    ##########################################################
    # Subscriber Functions
    ##########################################################

    def makeSubscriber(self, topic_name: str):
        """Subscriberのインスタンス生成"""
        self.sub_client = mqtt.Client()
        self.setTopicName(topic_name=topic_name)
        self.sub_client.on_connect = self.onConnectBrokerAsSubscriber
        self.sub_client.on_message = self.onSubscribeMessageFromBroker

    def startSubscriberLoop(self,
                            host: str = "localhost",
                            port: int = 1883,
                            keepalive: int = 60,
                            ) -> None:
        """受信ループ開始(Subscriber)"""
        self.sub_client.connect(host,
                                port,
                                keepalive)
        self.sub_client.loop_start()

    def SubscribeFromBroker(self):
        data = self.sub_queue.get()
        if data is None:
            return None
        else:
            return data

    def stopSubscriberLoop(self):
        """受信ループ停止(Subscriber)"""
        self.sub_client.loop_stop()

    def killSubscriberLoop(self):
        """受信ループ削除(Subscriber)"""
        self.sub_client.loop_stop()
        self.sub_client.disconnect()

    def setTopicName(self, topic_name: str) -> None:
        """トピック名を定義(Subscriber)"""
        self.topic_name = topic_name

    def onConnectBrokerAsSubscriber(self,
                                    client: mqtt.Client,
                                    userdata: Any,
                                    flags: dict,
                                    return_code: int) -> None:
        """ブローカに接続したときの処理(Subscriber)"""
        self.sub_client.subscribe(self.topic_name)

    def onSubscribeMessageFromBroker(self,
                                     client: mqtt.Client,
                                     userdata: Any,
                                     msg: mqtt.MQTTMessage) -> None:
        """Subscribeが完了したときの処理(Subscriber)"""
        payload = msg.payload  # NOTE: メッセージの中身
        topic = msg.topic  # NOTE: トピック名
        qos = msg.qos  # NOTE: 通信保証レベル

        sub_payload = decodeByteDataToJson(payload)
        self.sub_queue.put(sub_payload)

        # print(sub_payload)
        # print(topic)
        # print(qos)

# ===============================================================================
# NOTE: MQTT用汎用メソッド
# ===============================================================================


def _subscribeFromBroker(mqtt_client: MQTTClient, _mqtt_data, data_class):
    #####################################################################
    # NOTE:Subscribe処理  (MQTT ->Any プロセス )
    #####################################################################
    # Subscribe from MQTTBroker
    _json = mqtt_client.SubscribeFromBroker()
    if _json is not None:
        # convert json->Dataclass
        _mqtt_data = convertJson2Dataclass(json_data=_json, data_class=data_class)
        return _json, _mqtt_data

    else:
        return None, _mqtt_data


def _publishToBroker(mqtt_client: MQTTClient,
                     mqtt_data,
                     topic_name,
                     qos: int = 1):
    #####################################################################
    # NOTE:Publish処理  ()
    #####################################################################
    # Publish to MQTTBroker
    # convert dataclass->json
    send_json = convertDataclass2Json(mqtt_data=mqtt_data)
    # Publish to MQTTBroker
    mqtt_client.publishToBroker(topic_name=topic_name,
                                payload=send_json,
                                qos=qos)


if __name__ == '__main__':
    mqtt_client = MQTTClient()

    pub2 = mqtt_client.makePublisher()
    sub2 = mqtt_client.makeSubscriber(topic_name='PLC/READ')

    pub2.connect(host="localhost",
                 port=1883,
                 keepalive=60)
    sub2.connect(host="localhost",
                 port=1883,
                 keepalive=60)

    pub2.loop_start()
    sub2.loop_start()

    while mqtt_client.process_loop:
        pub2.publish(topic='PLC/WRITE',
                     payload='hogehuga',
                     qos=0)

        time.sleep(1)

    pub2.loop_stop()
    sub2.loop_stop()
    pub2.disconnect()
    sub2.disconnect()
