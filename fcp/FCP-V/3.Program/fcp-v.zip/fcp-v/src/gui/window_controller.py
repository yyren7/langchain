# ===============================================================================
# Name      : window_controller.py
# Version   : 1.0.0
# Brief     : メインウィンドウのコントローラ
# Time-stamp: 2024-09-26 10:28
# Copyirght 2021 Hiroya Aoyama
# ===============================================================================
import os
import subprocess
from cv2 import imread
from PySide2 import QtWidgets
from typing import Any
from ui_settings import D11_FLAG, PASSWORD_REQUEST

# NOTE: gui
from gui.pyside_dynamic import loadUi
from gui.widgets_controller import (
    show_dialog,
    show_error,
    open_keyboard,
    show_roi,
    show_notice
)
from gui.pyside_lib import set_message_on_statusbar, paste_image_on_qlabel

# NOTE: utils
from ui_utils.file_handler import FileHandler
from ui_utils.path_manager import PathManager

from ui_utils.security.certification import check_hash

# NOTE: カメラモジュール
if os.name == 'nt':
    from ui_utils.camera.usb_camera import USBCamera as CameraClass
else:
    if D11_FLAG:
        from ui_utils.camera.hqcamera import HQCamera as CameraClass  # type: ignore
    else:
        from ui_utils.camera.raspi_camera import RaspiCamera as CameraClass  # type: ignore

# NOTE: マテリアルデザインを適用
try:
    from qt_material import apply_stylesheet
except Exception:
    pass

try:
    from logger import setup_logger
    logger = setup_logger(__name__)
except Exception:
    from logging import getLogger
    logger = getLogger(__name__)


# NOTE: 設定値のフォーマット
from module.component.param_basemodel import ImageProcParamModel, CalibrationDataModel
from module.component.option_basemodel import OptionModel
from ui_utils.camera.abc_camera import CameraParam


def check_usb_mount(mount_dir: str) -> bool:
    """USBのマウントチェック"""
    mount_cmd = f"mountpoint -q {mount_dir}; echo $?"
    mount_flag = int((
        subprocess.Popen(mount_cmd, stdout=subprocess.PIPE, shell=True).communicate()[0]).decode("utf-8"))
    # NOTE: 1であればUSBが挿入されていない
    if mount_flag == 1:
        return False
    return True


class WindowController(QtWidgets.QMainWindow):
    """
    Args:
        QtWidgets (_type_): _description_
    """

    def __init__(self, ui_path: str, ui_title: str, pg_type: str = ''):
        super().__init__()
        loadUi(ui_path, self)
        # NOTE: アノテーション
        self.stackedWidget: QtWidgets.QStackedWidget

        self._current_page = 0
        self._password_req = True
        self._password = 'pass'

        self.setWindowTitle(ui_title + ' ' + pg_type)
        set_message_on_statusbar(self.statusbar, ui_title)

        # NOTE:ハンドラーの登録
        self.pm = PathManager(header='', modelname='')
        self.fh = FileHandler(header='')

    # ===============================================================================
    # NOTE: デザイン適用
    # ===============================================================================
    def apply_qt_material(self, app: QtWidgets.QApplication) -> None:
        try:
            apply_stylesheet(app, theme='light_blue.xml')
        except Exception:
            pass

    # ===============================================================================
    # NOTE: ハンドラー更新
    # ===============================================================================
    def init_manager(self, header: str) -> None:
        self.pm.set_header(header=header)
        self.fh.set_header(header=header)

    def set_manager(self, header: str) -> None:
        self.init_manager(header)

        # NOTE: モデルのフォルダが存在しないとき生成
        if not os.path.exists(self.pm._header):
            self.create_config_file()
            self.show_notice('No data exists. Generating initial data.\nPlease click [OK] and wait a second!')

        # NOTE: エクセルファイルが存在しないとき大元からコピー
        # if not os.path.exists(self.pm.plc_address_sheet):
        #     if not os.path.exists(self.pm.orig_plc_address_sheet):
        #         self.show_error('Original PLC Address Sheet is not Found')
        #         return
        #     self.fh._copy_file(self.pm.orig_plc_address_sheet, self.pm.plc_address_sheet)

        # NOTE: エクセルファイルが存在しないとき大元からコピー
        if not os.path.exists(self.pm.setting_address):
            self.fh._make_dir(path=self.pm.config_dir, allow_user=True)
            if not os.path.exists(self.pm.orig_setting_address):
                self.show_error('Original PLC Address Sheet is not Found')
                return
            self.fh._copy_file(self.pm.orig_setting_address, self.pm.setting_address)

        if not os.path.exists(self.pm.setting_ini):
            if not os.path.exists(self.pm.orig_setting_ini):
                self.show_error('Original ini File is not Found')
                return
            self.fh._copy_file(self.pm.orig_setting_ini, self.pm.setting_ini)

        if not os.path.exists(self.pm.setting_calib):
            if not os.path.exists(self.pm.orig_setting_calib):
                self.show_error('Original Calibration File is not Found')
                return
            self.fh._copy_file(self.pm.orig_setting_calib, self.pm.setting_calib)

        auto_search = False
        # NOTE: 最後に読み込んだモデル名を記録したファイルがあるか確認
        data = self.fh.load_config(self.pm.last_used_cfg, modelname='last_used', no_log=True)
        if data is None:
            auto_search = True
        else:
            # NOTE: 最後に読み込んだモデル名が記録されているか確認
            modelname = data.get('last_used_modelname', None)
            if not isinstance(modelname, str):
                auto_search = True
            else:
                # NOTE: 該当モデルに設定ファイルが存在するか確認
                self.pm.update(modelname)
                data = self.fh.load_config(self.pm.param_cfg, modelname=modelname, no_log=True)
                if data is None:
                    auto_search = True

        if auto_search:
            # NOTE: モデルリストを取得し一番前のモデルを呼び出し
            try:
                model_list = os.listdir(os.path.join(header, 'model'))  # NOTE: フォルダがないとエラー
            except Exception:
                # NOTE: フォルダを作成
                self.fh._make_dir(os.path.join(header, 'model'), allow_user=True)
                model_list = os.listdir(os.path.join(header, 'model'))  # NOTE: フォルダがないとエラー
                self.show_notice('No data exists. Generating initial data.\nPlease click [OK] and wait a second!')
            # NOTE: 中身からっぽ
            if len(model_list) == 0:
                self.pm.update('---')
                return
            modelname = model_list[0]
            self.pm.update(modelname)

    def create_config_file(self) -> None:
        """初期データを作成"""
        # NOTE: カメラファイルとオプションファイルを生成
        if not os.path.exists(self.pm.camera_cfg):
            common_dir = self.pm._common_header
            self.fh._make_dir(path=common_dir, allow_user=True)
            self.fh.create_new_file(os.path.join(common_dir, 'camera.json'), dict(PiCamera=CameraParam().dict()))
            self.fh.create_new_file(os.path.join(common_dir, 'option.json'), OptionModel().dict())

        # NOTE: キャリブレーションファイルと画像処理パラメータファイルを作成
        model_dir = os.path.join(self.pm._model_header, 'default_model')
        self.fh._make_dir(path=model_dir, allow_user=True)
        self.fh.create_new_file(os.path.join(model_dir, 'param.json'), ImageProcParamModel().dict())
        self.fh.create_new_file(os.path.join(model_dir, 'calib_param.json'), CalibrationDataModel().dict())
        self.fh.create_new_file(os.path.join(model_dir, 'option.json'), OptionModel().dict())  # 追加　optionも機種毎に

    # ===============================================================================
    # NOTE: ページ管理
    # ===============================================================================

    def get_current_page(self) -> int:
        return self._current_page

    def page_changed(self, page_idx: int) -> bool:
        if page_idx == self._current_page:
            return False
        else:
            return True

    def page_update(self, page_idx: int) -> None:
        self._current_page = page_idx

    def password_check(self) -> bool:
        # NOTE: パスワード機能が無効な場合
        if not PASSWORD_REQUEST:
            return True

        # NOTE: 既にパスワードを通している場合
        if not self._password_req:
            return True

        input_word = open_keyboard(widget=None)

        if input_word == '__init__':
            # NOTE: パスワード画面を消した場合
            return False
        elif input_word == self._password:
            # NOTE: 合っている場合
            self._password_req = False
            return True
        else:
            # NOTE: 間違っている場合
            self.show_error('Password is incorrect.')
            return False

    # ===============================================================================
    # NOTE: ダイアログ表示
    # ===============================================================================
    def show_error(self, msg: str) -> None:
        show_error(message=msg)

    def show_dialog(self, msg: str) -> bool:
        return show_dialog(msg)

    def show_roi(self, img: Any, title: str) -> None:
        show_roi(img, title=title)

    def show_notice(self, msg: str) -> None:
        show_notice(message=msg)

    # ===============================================================================
    # NOTE: 終了処理
    # ===============================================================================
    def process_on_exit(self) -> None:
        pass

    def closeEvent(self, event: Any) -> None:
        # NOTE: GUIの終了イベント時の処理
        self.process_on_exit()
        event.accept()

    # ===============================================================================
    # NOTE: カメラ設定
    # ===============================================================================
    def set_camera(self) -> bool:
        data = self.fh.load_config(self.pm.camera_cfg, modelname='common')
        if not isinstance(data, dict):
            self.show_error('Failed to load camera configuration file')
            return False

        cam_data = data.get('PiCamera', None)
        if cam_data is None:
            self.show_error('Camera configuration file\'s format is wrong[1]')
            return False

        try:
            self.camera = CameraClass()
        except Exception as e:
            print(str(e))
            self.show_error('Camera Connection Error')
            return False

        # NOTE: カメラの設定読み込み
        try:
            if os.name != 'nt':
                self.camera.set_parameter(cam_data)
        except Exception as e:
            print(str(e))
            self.show_error('Camera configuration file\'s format is wrong[2]')
            return False

        return True

    def check_vast_key(self) -> bool:
        """ハッシュキーをチェック"""
        data = self.fh.load_config('/media/usb/hash.json', modelname='', no_log=True)
        if data is None:
            self.show_error('License not valid')
            return False
        code = data.get('hash', '')
        ret = check_hash(code)
        if ret:
            return True
        self.show_error('License not valid')
        return False

    def usb_check(self) -> bool:
        """USBの接続確認"""
        ret = check_usb_mount('/media/usb')
        if ret:
            return True
        img = imread('./utils/usb/notice.png')
        self.show_roi(img, 'Error')
        return False
