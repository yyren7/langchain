from PySide2 import QtWidgets


class CustomTableWidget(QtWidgets.QWidget):
    def __init__(self,
                 table_widget: QtWidgets.QTableWidget):
        super().__init__()
        self._table_widget = table_widget

    def getFocusedRow(self) -> int:
        index = self._table_widget.currentRow()
        return index

    def getSelectedRow(self) -> int:
        """RadioButtonを一列目に配置したときの行の取得の仕方"""
        for i in range(self._table_widget.rowCount()):
            if self._table_widget.cellWidget(i, 0).isChecked():
                return i
        return -1

    def setHeaderLabels(self, labels: list) -> None:
        num_headers = len(labels)
        self._table_widget.setColumnCount(num_headers)
        self._table_widget.setHorizontalHeaderLabels(labels)
        # NOTE: A行目のIndex表示無効
        self._table_widget.verticalHeader().setVisible(False)
        self._row_count = 0

    def createCellWidget(self) -> list:
        return []

    def addTableRow(self) -> None:
        # NOTE: 行追加
        self._table_widget.insertRow(self._row_count)
        cell_widgets = self.createCellWidget()

        num_cell_widgets = len(cell_widgets)

        if num_cell_widgets <= 0:
            return

        # NOTE: 差し込み
        for i in range(num_cell_widgets):
            self._table_widget.setCellWidget(self._row_count, i, cell_widgets[i])

        # NOTE: ウィジェットのサイズにセルサイズを合わせる
        self._table_widget.resizeRowToContents(self._row_count)
        self._table_widget.resizeColumnToContents(self._row_count)

        # NOTE: リサイズ（ストレッチ)
        for i in range(num_cell_widgets - 1):
            self._table_widget.horizontalHeader().setSectionResizeMode(i + 1, QtWidgets.QHeaderView.Stretch)

            # NOTE: カウントアップ
        self._row_count += 1

    def removeConfigRow(self) -> None:
        pass

    def addConfigRow(self) -> None:
        pass

    def removeTableRowCol(self) -> None:
        """テーブル初期化"""
        self._row_count = 0
        self._table_widget.setRowCount(0)
        self._table_widget.setColumnCount(0)

    def initializeTableWidget(self) -> None:
        pass

    def setTableData(self) -> None:
        pass
