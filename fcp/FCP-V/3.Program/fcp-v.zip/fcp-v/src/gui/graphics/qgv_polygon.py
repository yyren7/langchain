# ===============================================================================
# Name      : qgv_polygon.py
# Version   : 1.0.0
# Brief     : QGraphicsViewを使用したポリゴン描画のクラス
# Time-stamp: 2022-11-23 18:06
# Copyirght 2022 Hiroya Aoyama
# ===============================================================================

from PySide2 import QtCore, QtGui, QtWidgets
import numpy as np
from typing import Optional, Union
from .qgv_base import (
    GraphicsBaseItem,
    COLOR_LIST,
    array_to_qpt,
    qpt_to_numpy
)

try:
    from logger import setup_logger
    logger = setup_logger(__name__)
except Exception:
    from logging import getLogger
    logger = getLogger(__name__)


class GraphicsPolygon(GraphicsBaseItem):
    def __init__(self):
        super().__init__()
        self._handle_item: Optional[QtWidgets.QGraphicsPolygonItem] = None
        self._poly_points = []
        self._start = QtCore.QPointF()
        # self._poly_points: List[QtCore.QPointF] = []

    def set_polygon_as_object(self):
        """図形をアイテムとして固定"""
        if self._handle_item is not None:
            self._handle_item.setBrush(QtGui.QColor(255, 0, 0, 128))
            self._handle_item.setPolygon(QtGui.QPolygonF(self._poly_points))
            self._handle_item.setFlag(QtWidgets.QGraphicsItem.ItemIsMovable, True)
            self._new_shape_flag = False
            # NOTE: 初期化
            self._poly_points = []

    def set_polygon_data(self, np_poly: Union[np.ndarray, list]):
        """
        ポリゴンをセット

        Args:
            np_poly (Union[np.ndarray, list]): _description_
        """
        # NOTE: アイテムが存在している場合削除
        if self._handle_item is not None:
            self.removeItem(self._handle_item)

        self._handle_item = QtWidgets.QGraphicsPolygonItem()
        # self._current_rect_item.setBrush(QColor(255, 0, 0, 128))   # 矩形塗りつぶしの設定
        self._handle_item.setPen(QtGui.QPen(
            COLOR_LIST[0], self._thickness, QtCore.Qt.SolidLine
        ))
        self.addItem(self._handle_item)
        self._poly_points = array_to_qpt(np_poly)
        self.set_polygon_as_object()

    def get_polygon_data(self) -> Optional[np.ndarray]:
        """
        図形アイテムから座標を取得

        Returns:
            Optional[np.ndarray]: _description_
        """
        if self._handle_item is not None:
            return qpt_to_numpy(self._handle_item)
        else:
            return None

    def set_shape_item(self, event: QtWidgets.QGraphicsSceneMouseEvent):
        """
        図形アイテムを設定
        Args:
            event (QtWidgets.QGraphicsSceneMouseEvent): _description_
        """
        self._handle_item = QtWidgets.QGraphicsPolygonItem()
        self._handle_item.setPen(QtGui.QPen(
            COLOR_LIST[0], self._thickness, QtCore.Qt.SolidLine
        ))
        # NOTE: アイテムを追加
        self.addItem(self._handle_item)
        self._start = event.scenePos()
        self._poly_points.append(QtCore.QPointF(event.scenePos()))
        self._handle_item.setPolygon(QtGui.QPolygonF(self._poly_points))

    def mousePressEvent(self, event: QtWidgets.QGraphicsSceneMouseEvent) -> None:
        """マウスプレス時の処理"""
        return super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QtWidgets.QGraphicsSceneMouseEvent):
        """マウス移動時の処理"""
        if self._new_shape_flag:
            if self._handle_item is not None:
                temp_poly = self._poly_points.copy()
                temp_poly.append(QtCore.QPointF(event.scenePos()))
                self._handle_item.setPolygon(QtGui.QPolygonF(temp_poly))
        super(GraphicsPolygon, self).mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QtWidgets.QGraphicsSceneMouseEvent) -> None:
        """マウスリリース時の処理"""
        if self._handle_item is not None:
            # logger.info(qpt_to_numpy(self._handle_item))
            pass
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event: QtWidgets.QGraphicsSceneMouseEvent):
        """マウスダブルクリック時の処理"""
        # NOTE: アイテムを設定する
        if self._handle_item is not None:
            self._poly_points.append(QtCore.QPointF(event.scenePos()))
            self.set_polygon_as_object()

        super(GraphicsPolygon, self).mouseDoubleClickEvent(event)
