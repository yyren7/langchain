# ===============================================================================
# Name      : pyqtgraph_view.py
# Version   : 1.0.0
# Brief     :
# Time-stamp: 2023-06-11 10:27
# Copyirght 2022 Hiroya Aoyama
# ===============================================================================
import pyqtgraph as pg
from typing import Tuple
from PySide2 import QtCore


class CustomCircleROI(pg.CircleROI):
    def __init__(self,
                 img_w: int,
                 img_h: int,
                 center_x: int,
                 center_y: int,
                 radius: int,
                 color: tuple = (255, 0, 0),
                 **kwards):

        self._img_w = img_w
        self._img_h = img_h

        _maxbounds = QtCore.QRectF(0, 0, self._img_w, self._img_h)  # NOTE: QRectだとうまくうごかない
        super().__init__(pos=[center_x - radius, center_y - radius],
                         size=[radius * 2, radius * 2],
                         maxBounds=_maxbounds,
                         pen=pg.mkPen(color=pg.mkColor(color[0], color[1], color[2]), width=2),
                         hoverPen=pg.mkPen(color=pg.mkColor(color[0], color[1], color[2]), width=4),
                         **kwards)

    def addHandle(self, *args, **kwargs):
        self.handleSize = 9
        super(CustomCircleROI, self).addHandle(*args, **kwargs)

    def get_circle_data(self) -> Tuple[int, int, int]:
        """円ROIの座標,半径を出力

        Returns:
            Tuple[int, int, int]: _description_
        """
        pos = self.pos()
        size = self.size()

        _radius = int(size[0] / 2)
        _center_x = int(pos[0] + _radius)
        _center_y = int(self._img_h - (pos[1] + _radius))

        return _center_x, _center_y, _radius

    def set_circle_data(self, center_x: int, center_y: int, radius: int) -> None:
        """円ROIの座標,半径を入力

        Args:
            center_x (int): _description_
            center_y (int): _description_
            radius (int): _description_
        """
        _center_x = center_x - radius
        _center_y = self._img_h - center_y - radius
        self.setPos([_center_x, _center_y])
        self.setSize([radius * 2, radius * 2])

    def is_editable(self, enable: bool):
        self.resizable = enable
        self.movable = enable
        if enable:
            self.setPen(color=pg.mkColor(255, 0, 0), width=1)
            self.addScaleHandle(pos=(0.5 * 2.**-0.5 + 0.5, 0.5 * 2.**-0.5 + 0.5),
                                center=(0.5, 0.5))
        else:
            self.setPen(color=pg.mkColor(255, 255, 255), width=1)
            _handles = self.getHandles()
            for handle in _handles:
                self.removeHandle(handle)
