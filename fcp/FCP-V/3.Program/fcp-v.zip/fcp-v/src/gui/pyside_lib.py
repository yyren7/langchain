# ===============================================================================
# Name      : pyside_lib.py
# Version   : 1.0.0
# Brief     : PySide2のWidget操作関数ライブラリ
# Time-stamp: 2023-05-19 18:55
# Copyirght 2022 Hiroya Aoyama
# ===============================================================================
import os
import numpy as np
import cv2
import time
import threading
from PySide2 import QtWidgets, QtCore, QtGui
from typing import Tuple, Any, Optional

try:
    import qimage2ndarray
    IMPORT_QIMG2ARR = True
except Exception:
    IMPORT_QIMG2ARR = False


# ===============================================================================
# NOTE: QThread
# ===============================================================================

class VideoThread(QtCore.QThread):
    # signal_frame: QtCore.SignalInstance
    # signal_message: QtCore.SignalInstance
    signal_frame: Any = QtCore.Signal(np.ndarray)
    # NOTE: シグナルの設定
    error_signal = QtCore.Signal(str)
    # signal_message = QtCore.Signal(str)
    # NOTE: デフォルトでは640x480で送信

    def __init__(self, camera=None, rsize: bool = False, base_width: int = 480):
        super().__init__()
        self.mutex = QtCore.QMutex()
        self.stopped = True
        self.camera = camera
        self.rsize = rsize
        self.b_width = base_width
        # self.cnt = 0

    def __del__(self):
        self.set_stopper()
        self.quit()
        self.wait()

    def set_stopper(self):
        self.stopped = True
        with QtCore.QMutexLocker(self.mutex):
            # Prohibit access to other resources
            self.stopped = True

    def unlock_stopper(self):
        self.stopped = False
        with QtCore.QMutexLocker(self.mutex):
            # Prohibit access to other resources
            self.stopped = False

    def run(self):
        while not self.stopped:
            frame = self.camera.capture()
            if frame is None:
                self.error_signal.emit(self.camera.error_message)  # type:ignore
                time.sleep(0.1)
                break
            else:
                if self.rsize:
                    height, width = frame.shape[:2]
                    r_height = int(height * (self.b_width / width))
                    resol = (self.b_width, r_height)
                    frame = cv2.resize(frame, resol)

                self.signal_frame.emit(frame)  # type:ignore
                break


class ProgressDialog(QtWidgets.QDialog):

    """
    dialog with progress bar
    """

    def __init__(self):
        super().__init__()
        vlo = QtWidgets.QVBoxLayout()
        prog_bar = QtWidgets.QProgressBar()
        # marquee
        self.setWindowTitle('prog')
        prog_bar.setRange(0, 0)
        vlo.addWidget(prog_bar)
        self.setLayout(vlo)


def display_progress_bar(th: threading.Thread, timeout: int = 60) -> bool:
    """_summary_

    Args:
        th (threading.Thread): Thread
        timeout (int, optional): Timeout[sec]. Defaults to 60.

    Returns:
        bool: _description_
    """
    pg = ProgressDialog()
    pg.open()
    success = True
    t_s = time.perf_counter()
    while th.is_alive():
        time.sleep(0.2)
        QtWidgets.QApplication.processEvents()
        dt = time.perf_counter() - t_s
        # NOTE: 経過時間がTimeoutを超えたらbreak
        if dt > timeout:
            success = False
            break
    pg.accept()
    return success

# ===============================================================================
# NOTE: QPushButton
# ===============================================================================


def disable_button(widget: QtWidgets.QPushButton) -> None:
    """ QtWidgets.QApplication.processEvents()付き

    Args:
        widget (QtWidgets.QPushButton): _description_
    """
    bg_color = '#808080'
    font_color = '#FFFFFF'
    border_color = 'gray'
    css_str = 'QPushButton {' \
        + f'background-color: {bg_color};' \
        + f'color: {font_color};' \
        + f'border: 1px solid {border_color};' \
        + 'border-radius: 2px;' \
        + '}'
    widget.setStyleSheet(css_str)
    widget.setDisabled(True)
    QtWidgets.QApplication.processEvents()


def enable_button(widget: QtWidgets.QPushButton) -> None:
    """QtWidgets.QApplication.processEvents()付き

    Args:
        widget (QtWidgets.QPushButton): _description_
    """
    bg_color = '#1976d2'
    inv_font_color = '#FFFFFF'
    font_color = '#FFFFFF'
    border_color = 'blue'
    css_str = 'QPushButton {' \
        + f'background-color: {bg_color};' \
        + f'color: {font_color};' \
        + f'border: 1px solid {border_color};' \
        + 'border-radius: 2px;' \
        + '}' \
        + 'QPushButton::pressed {' \
        + f'background-color: {inv_font_color};' \
        + f'color: {bg_color};' \
        + f'border: 1px solid {border_color};' \
        + 'border-radius: 2px;' \
        + '}'
    widget.setStyleSheet(css_str)
    widget.setDisabled(False)
    QtWidgets.QApplication.processEvents()


def lightup_button(widget: QtWidgets.QPushButton, disabled: bool = False) -> None:
    bg_color = '#ff4500'
    inv_font_color = '#FFFFFF'
    font_color = '#FFFFFF'
    border_color = 'orange'
    css_str = 'QPushButton {' \
        + f'background-color: {bg_color};' \
        + f'color: {font_color};' \
        + f'border: 1px solid {border_color};' \
        + 'border-radius: 2px;' \
        + '}' \
        + 'QPushButton::pressed {' \
        + f'background-color: {inv_font_color};' \
        + f'color: {bg_color};' \
        + f'border: 1px solid {border_color};' \
        + 'border-radius: 2px;' \
        + '}'
    widget.setStyleSheet(css_str)
    widget.setDisabled(disabled)
    QtWidgets.QApplication.processEvents()


# ===============================================================================
# NOTE: QSpinBox, QSlider
# ===============================================================================

class DoubleSlider(QtWidgets.QSlider):
    # create our our signal that we can connect to if necessary
    doubleValueChanged: Any = QtCore.Signal(float)

    def __init__(self, decimals=1, *args, **kargs):
        super(DoubleSlider, self).__init__(*args, **kargs)
        self._multi = 10 ** decimals
        self.valueChanged.connect(self.emitDoubleValueChanged)

    def emitDoubleValueChanged(self):
        value = float(super(DoubleSlider, self).value()) / self._multi
        self.doubleValueChanged.emit(value)

    def value(self):
        return float(super(DoubleSlider, self).value()) / self._multi

    def setMinimum(self, value):
        return super(DoubleSlider, self).setMinimum(value * self._multi)

    def setMaximum(self, value):
        return super(DoubleSlider, self).setMaximum(value * self._multi)

    def setSingleStep(self, value):
        return super(DoubleSlider, self).setSingleStep(value * self._multi)

    def singleStep(self):
        return float(super(DoubleSlider, self).singleStep()) / self._multi

    def setValue(self, value):
        super(DoubleSlider, self).setValue(int(value * self._multi))


def set_slider_range(slider: QtWidgets.QSlider,
                     min_v: int, max_v: int, step: int, val: int = -1) -> None:
    slider.setMinimum(min_v)
    slider.setMaximum(max_v)
    slider.setSingleStep(step)
    if val > min_v:
        slider.setValue(val)
    else:
        slider.setValue(min_v)


def set_double_slider_range(slider: DoubleSlider,
                            min_v: float, max_v: float, step: float, val: float = -1.0) -> None:
    slider.setMinimum(min_v)
    slider.setMaximum(max_v)
    slider.setSingleStep(step)
    if val > min_v:
        slider.setValue(val)
    else:
        slider.setValue(min_v)


def set_spinbox_range(spinbox: QtWidgets.QSpinBox,
                      min_v: int, max_v: int, step: int, val: int = -1) -> None:
    spinbox.setMinimum(min_v)
    spinbox.setMaximum(max_v)
    spinbox.setSingleStep(step)
    if val > min_v:
        spinbox.setValue(val)
    else:
        spinbox.setValue(min_v)


def set_doublespinBox_range(spinbox: QtWidgets.QDoubleSpinBox,
                            min_v: float, max_v: float, step: float,
                            decimals: int = 1,
                            val: float = -1.0) -> None:
    spinbox.setMinimum(min_v)
    spinbox.setMaximum(max_v)
    spinbox.setSingleStep(step)
    spinbox.setDecimals(decimals)
    if val > min_v:
        spinbox.setValue(val)
    else:
        spinbox.setValue(min_v)


def connect_slider_to_spinbox(slider: QtWidgets.QSlider,
                              spinbox: QtWidgets.QSpinBox) -> None:
    # NOTE: QSliderとQSpinBoxを同期
    slider.valueChanged.connect(lambda: spinbox.setValue(slider.value()))
    spinbox.valueChanged.connect(lambda: slider.setValue(spinbox.value()))


def connect_double_slider_to_spinbox(slider: DoubleSlider,
                                     spinbox: QtWidgets.QDoubleSpinBox) -> None:
    # NOTE: DoubleSliderとQDoubleSpinBoxを同期
    slider.doubleValueChanged.connect(lambda: spinbox.setValue(slider.value()))
    spinbox.valueChanged.connect(lambda: slider.setValue(spinbox.value()))


def set_spinbox_value(spinbox: QtWidgets.QSpinBox, val: int) -> None:
    spinbox.setValue(val)


def get_spinbox_value(spinbox: QtWidgets.QSpinBox) -> int:
    return spinbox.value()


def set_doublespinbox_value(spinbox: QtWidgets.QDoubleSpinBox, val: float):
    spinbox.setValue(val)


def get_doublespinbox_value(spinbox: QtWidgets.QDoubleSpinBox) -> float:
    return spinbox.value()

# ===============================================================================
# NOTE: QLabel, QGraphicsView
# ===============================================================================


def cv2_to_pixmap(cv2_img: np.ndarray) -> QtGui.QPixmap:
    # NOTE: np.arrayをQPixmapに変換
    if IMPORT_QIMG2ARR:
        qimage = qimage2ndarray.array2qimage(cv2.cvtColor(cv2_img, cv2.COLOR_BGR2RGB))
        pixmap = QtGui.QPixmap.fromImage(qimage)
    else:
        if cv2_img.ndim == 2:
            # NOTE: grayscaleだとエンコードできない
            # ndim == 2のときはGray2BGRで次元数増やす
            cv2_img = cv2.cvtColor(cv2_img, cv2.COLOR_GRAY2BGR)
        _, buf = cv2.imencode('.ppm', cv2_img)
        pixmap = QtGui.QPixmap()
        pixmap.loadFromData(buf.tobytes())
    return pixmap


def get_scale_size(frame: np.ndarray, size: QtCore.QSize) -> Tuple[QtCore.QSize, float]:
    """sizeとアスペクト比に合わせてframeを拡縮"""
    h, _ = frame.shape[:2]
    pixmap = cv2_to_pixmap(frame)
    pixmap = pixmap.scaled(size, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
    return QtCore.QSize(pixmap.width(), pixmap.height()), h / pixmap.height()  # NOTE: w/pixmap.width()でも可


def paste_image_on_qlabel(widget: QtWidgets.QLabel, frame: np.ndarray, *,
                          size: Optional[QtCore.QSize] = None, scale: float = 0.95) -> None:
    widget.clear()
    pixmap = cv2_to_pixmap(frame)
    if size is not None:
        pixmap = pixmap.scaled(size, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
    else:
        size = QtCore.QSize(int(widget.size().width() * scale),
                            int(widget.size().height() * scale))
        pixmap = pixmap.scaled(size, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
    widget.setPixmap(pixmap)


def paste_image_on_qgv(widget: QtWidgets.QGraphicsScene, frame: np.ndarray,
                       *, size: Optional[QtCore.QSize] = None) -> None:
    widget.clear()
    pixmap = cv2_to_pixmap(frame)
    if size is not None:
        pixmap = pixmap.scaled(size, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
    widget.addPixmap(pixmap)


def set_qlabel(widget: QtWidgets.QLabel, text: str) -> None:
    widget.setText(text)


# ===============================================================================
# NOTE: QFileDialog
# ===============================================================================

def get_file_path(filter: str, dir: str = '../') -> Tuple[bool, str]:
    # NOTE: filter ;; = &
    # "Images (*.png *.xpm *.jpg);;Text files (*.txt);;XML files (*.xml)"
    # NOTE: フィルタのフォーマット
    filter_list = dict(image="Images (*.png *.jpg *.bmp *.JPG *.JPEG)",
                       json="Text files (*.json)",
                       xml="XML files (*.xml)",
                       zip="Zip files (*.zip)",
                       all=""
                       )
    # NOTE: キーを参照してフィルタのフォーマットを取得
    filter_s = filter_list.get(filter, None)
    # NOTE: 取得できなければ無効
    if filter_s is None:
        return False, ""

    # NOTE: フィルタをかけた状態でファイルダイアログを表示
    path_s = QtWidgets.QFileDialog.getOpenFileName(
        caption="Open File",
        dir=dir,
        filter=filter_s
    )
    if path_s[0] != "":
        return True, path_s[0]
    else:
        return False, ""


def get_directory_path(dir: str = "../") -> Tuple[bool, str]:
    path_s = QtWidgets.QFileDialog.getExistingDirectory(
        caption="Select Directory",
        dir=dir,
    )
    if path_s != "":
        return True, path_s
    else:
        return False, ""


def get_filelist(path: str) -> list:
    """フォルダ名をリストで返す"""
    filelist = []
    try:
        # NOTE: include folder name
        filelist = os.listdir(path)
    except Exception as e:
        print(e)
        filelist = []
    return filelist

# ===============================================================================
# NOTE: QTextEdit
# ===============================================================================


def set_message(widget: QtWidgets.QTextEdit, msg: str = '',
                reset: bool = False, level: str = 'error') -> None:
    """QTextEditで表示"""
    if reset:
        widget.setText('')

    if level == 'info':
        q_color = QtGui.QColor(255, 255, 255)
    elif level == 'warning':
        q_color = QtGui.QColor(255, 255, 0)
    elif level == 'error':
        q_color = QtGui.QColor(255, 0, 0)
    else:
        q_color = QtGui.QColor(0, 255, 0)

    q_font = QtGui.QFont.DemiBold
    q_pt_size = 12
    widget.setFontWeight(q_font)
    widget.setTextColor(q_color)
    widget.setFontPointSize(q_pt_size)
    widget.append(msg)


def reset_message(widget: QtWidgets.QTextEdit) -> None:
    widget.setText('')


def set_text_edit(widget: QtWidgets.QTextEdit, msg: str) -> None:
    widget.setText(msg)


# ===============================================================================
# NOTE: QLineEdit
# ===============================================================================

def set_value_into_line_edit(widget: QtWidgets.QLineEdit, value: float, decimal: int = -1) -> bool:
    if decimal < 0:
        widget.setText(str(value))
        return True
    widget.setText(str(round(value, decimal)))
    return True


def get_value_from_line_edit(widget: QtWidgets.QLineEdit) -> Tuple[bool, float]:
    value = widget.text()
    try:
        return True, eval(value)
    except ValueError as ve:
        print(ve)
        return False, 0.0
    except Exception as e:
        print(e)
        return False, 0.0


def set_value_qle(widget: QtWidgets.QLineEdit, value: float, type: str = 'int', decimals: int = 1):
    """Set Value into QLineEdit with Validation"""
    if type == 'int':
        validator = QtGui.QIntValidator()
    elif type == 'float':
        validator = QtGui.QDoubleValidator()
    else:
        return
    widget.setValidator(validator)
    widget.setText(str(round(value, decimals)))


def get_value_qle(widget: QtWidgets.QLineEdit):
    """Get Value from QLineEdit"""
    value = widget.text()
    try:
        return True, eval(value)
    except ValueError as ve:
        print(ve)
        return False, 0.0
    except Exception as e:
        print(e)
        return False, 0.0

# ===============================================================================
# NOTE: QCheckBox
# ===============================================================================


def set_checkbox(widget: QtWidgets.QCheckBox, checked: bool) -> None:
    """"""
    widget.setChecked(checked)


def get_checkbox(widget: QtWidgets.QCheckBox) -> bool:
    """"""
    return widget.isChecked()


# ===============================================================================
# NOTE: QRadioButton
# ===============================================================================

def set_radiobutton(widget: QtWidgets.QRadioButton, checked: bool) -> None:
    """"""
    widget.setChecked(checked)


def get_radiobutton(widget: QtWidgets.QRadioButton) -> bool:
    """"""
    return widget.isChecked()


# ===============================================================================
# NOTE: QWidgets
# ===============================================================================

def set_qwidget(widget: QtWidgets.QWidget, title: str):
    widget.setWindowTitle(title)
    widget.setModal(True)
    widget.show()


# ===============================================================================
# NOTE: QMainWidget
# ===============================================================================

def set_window_title(widget: QtWidgets.QMainWindow, text: str) -> None:
    widget.setWindowTitle(text)


# ===============================================================================
# NOTE: QStackedWidget
# ===============================================================================

def switch_result_stackcard(widget: QtWidgets.QStackedWidget, judge: int):
    """ 判定結果のカード切り替え (WAIT=0, OK=1, NG=2, ERROR=3)"""
    widget.setCurrentIndex(judge)


def switch_stacked_widget(widget: QtWidgets.QStackedWidget, index: int):
    """ 判定結果のカード切り替え (WAIT=0, OK=1, NG=2, ERROR=3)"""
    widget.setCurrentIndex(index)

# ===============================================================================
# NOTE: QTabWidget
# ===============================================================================


def set_tabname(widget: QtWidgets.QTableWidget, index: int, name: str):
    """ タブテキストの変更 """
    widget.setTabText(index, name)

# ===============================================================================
# NOTE: QComboBox
# ===============================================================================


def set_combobox(widget: QtWidgets.QComboBox, index_: int) -> None:
    """ 値を設定 """
    widget.setCurrentIndex(index_)


def get_combobox(widget: QtWidgets.QComboBox) -> Tuple[str, int]:
    """ テキストとindexを取得 """
    idx = widget.currentIndex()
    text = widget.currentText()
    return text, idx


def set_items_into_combobox(widget: QtWidgets.QComboBox, items: list) -> None:
    """コンボボックスの選択肢をセット"""
    widget.clear()
    widget.addItems(items)


# ===============================================================================
# NOTE: QStausBar
# ===============================================================================

def show_message_on_statusbar(widget: QtWidgets.QStatusBar, text: str) -> None:
    widget.showMessage(text)


def set_message_on_statusbar(widget: QtWidgets.QStatusBar, text: str) -> None:
    label = QtWidgets.QLabel()
    # NOTE: 文字の色を白に設定
    font_color = '#FFFFFF'
    label.setStyleSheet(f'color: {font_color};')
    # NOTE: QLabelのフォント設定
    q_font = QtGui.QFont()
    q_font.setBold(True)
    q_font.setPointSize(11)
    label.setFont(q_font)
    label.setAttribute(QtCore.Qt.WA_TranslucentBackground)
    label.setText(text)
    widget.addPermanentWidget(label)


# ===============================================================================
# NOTE: CV2
# ===============================================================================

def crop_roi(src: np.ndarray, box: list) -> np.ndarray:
    return src[box[0]:box[2], box[1]:box[3]]
