#!/bin/bash
echo "Move to Current Dir..."
sudo systemctl start mosquitto
