#!/bin/bash

echo "Move to Current Dir..."
cd "$(dirname "$0")/"
cd "../"
cd "src"

echo "Activate a virtual environment..."
source env/.venv/bin/activate

echo "Move to Current Dir..."
cd "$(dirname "$0")/"
cd "../"
cd "src"

python main_process.py

read -p "Press Enter to exit"
