#!/bin/bash
echo "Move to Current Dir..."
cd "$(dirname "$0")"
echo "Make an env folder..."
source env/.venv/bin/activate
echo "Move to Current Dir..."
cd "$(dirname "$0")"
python main.py

read -p "Press Enter to continue..."
