#!/bin/bash
#"Donot Change"Get a desktop path.
echo "Desktop path:$HOME/Desktop"
#"Do not Change" Move to desktop path.
echo "Move to Desktop Dir..."
cd $HOME/Desktop
# "Change" Move to program path.
echo "Move to Program Dir..."
cd ./XXXXXXX/YYYYYYY/src
# "Do not Change" Activate a virtual environment
echo "Activate a virtual environment..."
source env/.venv/bin/activate
# "Do not Change" Run a program
echo "Run a process_controller_udp.py..."
python process_controller_udp.py
