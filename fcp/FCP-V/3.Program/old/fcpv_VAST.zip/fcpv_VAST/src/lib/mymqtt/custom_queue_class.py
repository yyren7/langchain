from collections import deque
import threading
from typing import Any


class LimitedLiFoQueue(object):
    def __init__(self, maxsize: int = 0) -> None:
        self.maxsize: int = maxsize
        self.q: deque = deque(maxlen=maxsize)
        self.lock = threading.Lock()

    def put(self, item: Any) -> None:
        with self.lock:
            self.q.appendleft(item)

    def get(self) -> Any:
        with self.lock:
            if len(self.q) > 0:
                return self.q[0]
            else:
                return None

    @property
    def queue(self) -> Any:
        with self.lock:
            return list(self.q)


if __name__ == '__main__':
    lifo_queue = LimitedLiFoQueue(maxsize=3)

    # データを追加
    lifo_queue.put(1)
    lifo_queue.put(2)
    lifo_queue.put(3)

    print(lifo_queue.queue)  # [3, 2, 1]

    lifo_queue.put(4)
    print(lifo_queue.queue)  # [4, 3, 2]

    lifo_queue.put(5)
    print(lifo_queue.queue)  # [5, 4, 3]

    # データを取り出す
    item = lifo_queue.get()
    print(item)  # 5
    print(lifo_queue.queue)  # [5, 4, 3]
