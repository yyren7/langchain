#! /usr/bin/python
# -*- coding: utf-8 -*-
# ===============================================================================
# Name      : VastVision_api.py
# Version   : 1.0.0
# Brief     : vast api
# Time-stamp:2024-02-16 15:45
# Copyirght 2024 Tatsuya Sugino
# ===============================================================================
# from typing import Tuple, List, Union, Optional
# Faculea Controller
import socket
import sys

try:
    from logger import setup_logger

    logger = setup_logger(__name__)
except Exception:
    from logging import getLogger

    logger = getLogger(__name__)

# デバッグ用
Debug = ""


class VisionApi:
    # FRVP Vision No.
    TARGET_NO = 3
    # エラー判定
    OK = 1
    NG = 2
    ERR = 3

    # 結果取得用変数
    judge = None  # 結果判定
    seq = None  # 実行シーケンスNo
    param = None  # 受信パラメータ
    result_text = None  # VAST専用　結果文字列
    ack_header = None  # VAST専用　リターンヘッダー
    ack_trigger = None  # VAST専用　リターントリガ
    # 結果取得時 定数
    ResultStBlank = None

    # 送信処理におけるエラー
    TimeOut = False    # True:エラー有, False:エラー無し
    OpenErr = False    # True:エラー有, False:エラー無し
    # VAST用　ヘッダー定義
    TRIGGER_HEADER = "TR1"
    ERROR_HEADER = "ER1"
    # VAST用　定義
    RETURN_FOOTER = "\r\n"

    def __init__(self, dst_ip_address: str, dst_port: str):
        # 実行フロー初期値
        self.flow = 0
        self.config = 0
        self.model = 0
        self.position = 0
        # encode・DeCode Format
        self.FORMAT = "ASCII"
        # ReceiveBuffer
        self.ReceiveBuffer = 1024

        # dst ip addres  and port
        self.dst_ip_address = dst_ip_address
        self.dst_port = dst_port

    def _init_socket(self) -> None:
        if self.dst_port != "":
            self._port = int(self.dst_port)
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # NOTE: 電文が返ってくるまでのタイムアウト
        self.client.settimeout(10)
        print("start Vision Engine TCP server")

    def _connect_server(self) -> None:
        self.TimeOut = False
        self.OpenErr = False
        if "debugpy" not in sys.modules or Debug != "notvast":
            try:
                self.client.connect((self.dst_ip_address, self._port))
                self.client.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                self.OpenErr = True
            except Exception as e:
                print("_connect_server:", e)
                self.OpenErr = False
        else:   # デバックモード以外 and Debug != "notvm" の時に処理されずpassする
            pass

        return self.OpenErr

    def _close(self) -> None:
        if "debugpy" not in sys.modules or Debug != "notvast":
            try:
                self.client.shutdown(socket.SHUT_RDWR)
                self.client.close()
            except Exception as e:
                print("_close:", e)
                pass
        else:   # デバックモード以外 and Debug != "notvm" の時に処理されずpassする
            pass

    def send(self, command: str) -> str:
        if "debugpy" not in sys.modules or Debug != "notvast":
            # 送信
            self.client.send(command.encode(self.FORMAT))

            ReceiveData = None  # 応答データ変数
            try:
                # NOTE: 電文受信までタイムアウト
                rcv_data = self.client.recv(self.ReceiveBuffer)
                ReceiveData = rcv_data.decode(self.FORMAT)
                # print("ReceiveData",ReceiveData)
                self.TimeOut = False
                # return rcv_data.decode(self.FORMAT)
            except Exception as e:
                print("send:", e)
                self._close()
                ReceiveData = None
                self.TimeOut = True
                # return None
        else:
            ReceiveData = '0,1,1463.41,342.034,1464.466,388.774,1468.853,292.454,88.706,-83.735\r'
        return ReceiveData

    def SendAndReceive(self, flow: any = 0, cfg: any = 0, mdl: any = 0, pos: any = 0) -> bool:
        # 送信Data : str → 送信前にstrに変換を行う
        # 受信Data : self.judge, self.seq, *self.param
        #               →　受信直後に int,int,float に変換する
        import re
        send_list = []

        # 送信データの変換
        if isinstance(flow, int):
            flow = str(flow)
        if isinstance(cfg, int):
            cfg = str(cfg)
        if isinstance(mdl, int):
            mdl = str(mdl)
        if isinstance(pos, int):
            pos = str(pos)

        # Errチェック
        if self.OpenErr is False and self.TimeOut is False:
            # print("_closed is True")
            pass
        else:
            self._init_socket()
            self._connect_server()
            # print("_closed is False")
            pass

        try:
            # 検査トリガ
            send_list = [self.TRIGGER_HEADER, flow, cfg, mdl, pos, self.RETURN_FOOTER]
            # 結合
            send_str = ','.join(map(str, send_list))

            tmp = self.send(send_str)
            # print("tmp",tmp)
            if tmp is not None:  # 送信成功の場合
                ret = re.split(f"{self.RETURN_FOOTER}|,", tmp)
                # print("ret",ret)
                # self.judge, self.seq, *self.param = ret  # [0]結果判定,[1]実行シーケンス
                # print("ret",ret,self.TRIGGER_HEADER)
                # print("ret[0]: ",ret[0],", self.TRIGGER_HEADER: ",self.TRIGGER_HEADER)
                if ret[0] == self.TRIGGER_HEADER:  # ヘッダーが結果レスポンスの場合
                    # print("はいった")
                    # 識別ヘッダー,判定結果※,x座標[um],y座標,z座標,Θ,判定内容（テキスト）,CRLF
                    self.judge = (int(ret[1]) if self.isint(ret[1]) else self.ResultStBlank)  # [1]結果判定   有:0~ 無:None
                    self.seq = int(flow)
                    self.param = [float(n) for n in ret[2:6] if self.isfloat(n)]  # [2~5]結果パラメータ
                    # print("param :", self.param)
                    self.result_text = ret[6]

                elif ret[0] == self.ERROR_HEADER:  # ヘッダーがエラーレスポンスの場合
                    # 識別ヘッダー,エラー番号,エラー内容（テキスト）,
                    #  トリガ情報(識別ヘッダー,プログラム番号,コンフィグ番号,モデル番号,ポジション番号),CRLF
                    self.judge = 3  # システムエラーも3とする
                    self.seq = int(flow)
                    self.param = [-1, -1, -1, -1]
                    self.result_text = ret[2]
                    self.ack_header = ret[3]
                    self.ack_trigger = [int(n) for n in ret[4:7] if self.isint(n)]  # [4~7]結果パラメータ


                return True
            else:  # 送信失敗の場合
                return False
        except Exception as e:
            print("SendAndReceive:", e)
            return False

    def getReslut(self, judge: int) -> int:
        # シーケンス切替だけで使用する
        # vast OK
        if judge == self.OK:
            return 0
        # vast NG
        elif judge == self.NG:
            return 1
        # vast Err
        elif (judge == self.ERR):
            return 2
        # 検出待機中
        else:
            return None

    def isfloat(self, s) -> bool:
        # 浮動小数点数値を表しているかどうかを判定
        try:
            float(s)  # 文字列を実際にfloat関数で変換してみる
        except ValueError:
            return False
        else:
            return True

    def isint(self, s) -> bool:
        # 整数表しているかどうかを判定
        try:
            int(s)  # 文字列を実際にint関数で変換してみる
        except ValueError:
            return False
        else:
            return True


if __name__ == "__main__":
    # 初期化
    dst_ip_address = "127.0.0.1"
    dst_port = "4001"
    dev_port = ""
    baudrate = ""

    v = VisionApi(dst_ip_address, dst_port)
    ret = v._connect_server()

    # JsonFileから参照する
    _tag = ["Center_gx", "Center_gy", "Bos1_gx",
            "Bos1_gy", "Bos2_gx", "Bos2_gy", "Angle1", "Angle2", ]

    import re
    while True:
        tmp = v.send(v.Flow + "\r")
        if tmp is not None:
            ret = re.split("\r|,", tmp)  # \rが無い場合がある為回避する
            judge, seq, *_ = ret  # [0]結果判定,[1]実行シーケンス
            print(ret)

        print("self.OpenErr:", v.OpenErr,
              "self.TimeOut:", v.TimeOut)
        # judge, Seq, param = v.SendAndReceive(Flow=int(v.Flow))
        v.SendAndReceive(Flow=int(v.Flow))

        if v.judge is not None:
            # フロー切替　(撮影→解析)
            if v.Flow == TAKE_FLOW:
                v.Flow = ANALYSIS_FLOW
            # エラー処理
            elif v.judge is not v.OK:
                v.Flow = TAKE_FLOW

            # 結果出力
            if v.judge == v.OK and v.Seq == ANALYSIS_FLOW:
                Index = _tag
                cnt = 0
                for val in Index:
                    print(val + ":" + v.param[cnt])
                    cnt += 1
