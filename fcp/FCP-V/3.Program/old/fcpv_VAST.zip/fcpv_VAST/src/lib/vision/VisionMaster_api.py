#! /usr/bin/python
# -*- coding: utf-8 -*-

# from typing import Tuple, List, Union, Optional
# Faculea Controller
import socket
import sys

from jinja2 import pass_eval_context

try:
    from logger import setup_logger

    logger = setup_logger(__name__)
except Exception:
    from logging import getLogger

    logger = getLogger(__name__)


# Debug = "notvm"
Debug = ""


class VisionApi:
    # FVP Vision No.
    TARGET_NO = 2
    # エラー判定
    OK = 0
    NG = 1
    ERR = 2

    # 結果取得用変数
    judge = None  # 結果判定
    seq = None  # 実行シーケンスNo
    param = None  # 受信パラメータ
    # 結果取得時 定数
    ResultStBlank = None

    # 送信処理におけるエラー
    TimeOut = False    # True:エラー有, False:エラー無し
    OpenErr = False    # True:エラー有, False:エラー無し

    def __init__(self, dst_ip_address: str, dst_port: str):
        # 実行フロー初期値
        self.flow = 0
        self.config = 0
        self.model = 0
        self.position = 0
        # encode・DeCode Format
        self.FORMAT = "ASCII"
        # ReceiveBuffer
        self.ReceiveBuffer = 1024
        # dst ip addres  and port
        self.dst_ip_address = dst_ip_address
        self.dst_port = dst_port

    def _init_socket(self) -> None:
        if self.dst_port != "":
            self._port = int(self.dst_port)
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # NOTE: 電文が返ってくるまでのタイムアウト
        self.client.settimeout(10)
        print("start Vision Engine TCP server")

    def _connect_server(self) -> None:
        self.TimeOut = False
        self.OpenErr = False
        if "debugpy" not in sys.modules or Debug != "notvm":
            try:
                self.client.connect((self.dst_ip_address, self._port))
                self.client.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                self.OpenErr = True
            except Exception as e:
                print("_connect_server:", e)
                self.OpenErr = False
        else:   # デバックモード以外 and Debug != "notvm" の時に処理されずpassする
            pass

        return self.OpenErr

    def _close(self) -> None:
        if "debugpy" not in sys.modules or Debug != "notvm":
            try:
                self.client.shutdown(socket.SHUT_RDWR)
                self.client.close()
            except Exception as e:
                print("_close:", e)
                pass
        else:   # デバックモード以外 and Debug != "notvm" の時に処理されずpassする
            pass

    def send(self, command: str) -> str:
        if "debugpy" not in sys.modules or Debug != "notvm":
            # 送信
            self.client.send(command.encode(self.FORMAT))

            ReceiveData = None  # 応答データ変数
            try:
                # NOTE: 電文受信までタイムアウト
                rcv_data = self.client.recv(self.ReceiveBuffer)
                ReceiveData = rcv_data.decode(self.FORMAT)
                self.TimeOut = False
                # return rcv_data.decode(self.FORMAT)
            except Exception as e:
                print("send:", e)
                self._close()
                ReceiveData = None
                self.TimeOut = True
                # return None
        else:   # デバックモード以外 and Debug != "notvm" の時に処理されずpassする
            ReceiveData = '0,1,1463.41,342.034,1464.466,388.774,1468.853,292.454,88.706,-83.735\r'
            pass
        return ReceiveData

    def SendAndReceive(self, flow: any = 0, cfg: any = 0, mdl: any = 0, pos: any = 0) -> bool:
        # 送信Data : str → 送信前にstrに変換を行う
        # 受信Data : self.judge, self.Seq, *self.param
        #               →　受信直後に int,int,float に変換する
        import re

        # 送信データの変換
        if isinstance(flow, int):
            flow = str(flow)
        else:
            flow = flow

        # Errチェック
        if self.OpenErr is False and self.TimeOut is False:
            # print("_closed is True")
            pass
        else:
            self._init_socket()
            self._connect_server()
            # print("_closed is False")
            pass

        try:
            tmp = self.send(flow)  # VMは\rなしで送る
            if tmp is not None:  # 送信成功の場合
                ret = re.split("\r|,", tmp)  # \rが無い場合がある為回避する
                # if "debugpy" not in sys.modules and Debug != "notvm":

                # self.judge, self.Seq, *self.param = ret  # [0]結果判定,[1]実行シーケンス
                self.judge, self.seq = (int(ret[0]) if self.isint(ret[0]) else self.ResultStBlank,  # [0]結果判定   有:0~ 無:None
                                        int(ret[1]) if self.isint(ret[1]) else self.ResultStBlank)  # [1]実行Seq    有:0~ 無:None
                self.param = [float(n) for n in ret[2:] if self.isfloat(n)]  # [2~]結果パラメータ
                print(ret)
                return True
            else:  # 送信失敗の場合
                return False
        except Exception as e:
            print("SendAndReceive:", e)
            return False

    def getReslut(self, judge: int) -> int:
        # シーケンス切替だけで使用する
        # vm OK
        if judge == self.OK:
            return 0
        # vm NG
        elif judge == self.NG:
            return 1
        # vm Err
        elif (judge == self.ERR):
            return 2
        # 検出待機中?
        else:
            return None

    def isfloat(self, s) -> bool:
        # 浮動小数点数値を表しているかどうかを判定
        try:
            float(s)  # 文字列を実際にfloat関数で変換してみる
        except ValueError:
            return False
        else:
            return True

    def isint(self, s) -> bool:
        # 整数表しているかどうかを判定
        try:
            int(s)  # 文字列を実際にint関数で変換してみる
        except ValueError:
            return False
        else:
            return True


if __name__ == "__main__":
    pass
