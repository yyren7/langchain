# ===============================================================================
# Name      : base_db_module.py
# Version   : 1.0.0
# Brief     : シーケンスベース関数
# Time-stamp:2024-02-07 11:41
# Copyirght 2023 Tatsuya Sugino
# ===============================================================================
import os
# import sys
# import numpy as np
# from typing import Any, Optional
# from pydantic import BaseModel
# import pandas as pd
# import ibis

try:
    from logger import setup_logger
    logger = setup_logger(__name__)
except Exception:
    from logging import getLogger
    logger = getLogger(__name__)

try:
    from .param.base_param.base_db_param import PostgresVisionColumns, PostgresVisionValues
except Exception:
    from module.param.base_param.base_db_param import PostgresVisionColumns, PostgresVisionValues

import psycopg2
import datetime


def formattedTimestamp():
    current_datetime = datetime.datetime.now()
    # ミリ秒までの文字列に変換
    formatted_datetime = current_datetime.strftime('%Y-%m-%d %H:%M:%S.%f')
    return formatted_datetime


class PostgresDatabase:
    def __init__(self, user, password, host, port, database):

        self.conn = None
        self.cursor = None
        self.open(user, password, host, port, database)
        self.v_col = PostgresVisionColumns()
        self.v_val = PostgresVisionValues()

    def open(self, user, password, host, port, database):
        self.conn = psycopg2.connect(database=database,
                                     user=user,
                                     password=password,
                                     host=host,
                                     port=port)

        self.cursor = self.conn.cursor()
        # オートコミット
        self.conn.autocommit = False

    def close(self):
        if self.conn:
            self.conn.commit()
            self.cursor.close()
            self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()

    def setTableName(self, tablename):
        self.tablename = tablename

    def createTable(self, init_data: dict):

        # テーブルを作成するSQLクエリのテンプレート
        create_table_query_template = """
        CREATE TABLE IF NOT EXISTS {tablename}(
            id           bigserial NOT NULL primary key,
            create_at    timestamp with time zone,
            {columns}
        )
        """

        # カラムの文字列を生成
        columns = ',\n'.join([f'{column_name} {column_type} NOT NULL' for column_name,
                             column_type in init_data.items()])

        # テーブルを作成するSQLクエリを生成
        query = create_table_query_template.format(tablename=self.tablename, columns=columns)
        # 実行
        self.cursor.execute(query)
        # トランザクションをコミット
        self.conn.commit()

    def insertData(self, data: dict):
        # タイムスタンプを追加
        _data = {'create_at': formattedTimestamp(), **data}
        # データを挿入するSQLクエリのテンプレート
        insert_query_template = """
        INSERT INTO {tablename} ({columns}) VALUES
            ({values})
        """

        # カラムと値の文字列を生成
        columns = ', '.join(_data.keys())
        values = ', '.join([f"'{value}'" if isinstance(value, str) else str(value) for value in _data.values()])

        # データを挿入するSQLクエリを生成
        query = insert_query_template.format(tablename=self.tablename, columns=columns, values=values)
        # 実行
        self.cursor.execute(query)
        # トランザクションをコミット
        self.conn.commit()

    def getAllData(self, show=False):
        # データを取得するSQLクエリ
        select_query_template = f"SELECT * FROM {self.tablename}"

        # SQLクエリを実行
        self.cursor.execute(select_query_template)

        # 結果を取得
        result = self.cursor.fetchall()

        # 結果を表示
        if show:
            for row in result:
                print(row)

        return result

    def getData(self, data: dict, limit=None):
        # データを挿入するSQLクエリのテンプレート
        select_query_template = """
        SELECT {columns} FROM {tablename}
        """
        # カラムと値の文字列を生成
        columns = ', '.join(data.keys())
        # values = ', '.join([f"'{value}'" if isinstance(value, str) else str(value) for value in data.values()])

        # データを挿入するSQLクエリを生成
        query = select_query_template.format(columns=columns, tablename=self.tablename, )
        # 実行
        self.cursor.execute(query)
        # トランザクションをコミット
        self.conn.commit()

        # 結果を取得
        result = self.cursor.fetchall()

        return result[len(result) - limit if limit else 0:]

    def getLastData(self, data):
        return self.getData(data, limit=1)

    # def get(self, table, columns, limit=None):

    #     query = "SELECT {0} from {1};".format(columns, table)
    #     self.cursor.execute(query)

    #     # fetch data
    #     rows = self.cursor.fetchall()

    #     return rows[len(rows) - limit if limit else 0:]

    # def getLast(self, table, columns):

    #     return self.get(table, columns, limit=1)

    # def write(self, table, columns, data):

    #     query = "INSERT INTO {0} ({1}) VALUES ({2});".format(table, columns, data)

    #     self.cursor.execute(query)

    def query(self, sql):
        self.cursor.execute(sql)


@staticmethod
def toCSV(data, fname="output.csv"):

    with open(fname, 'a') as file:
        file.write(",".join([str(j) for i in data for j in i]))


if __name__ == "__main__":
    user = "postgres"
    password = "nidec"
    host = "localhost"
    port = "5436"
    database = "FRVP"
    dbm = PostgresDatabase(user, password, host, port, database)
    tablename = "frvp_status"
    dbm.setTableName(tablename=tablename)
    # 初期データの例 (カラム名とデータ型の辞書)
    init_data = {
        'column1': 'integer',
        'column2': 'text',
    }
    dbm.createTable(init_data=init_data)
    # print(dbm.getAllData(show=True))
    # データの追加
    insert_data = {
        'column1': 1,
        'column2': 'hoge',
    }
    dbm.insertData(data=insert_data)
