# ===============================================================================
# Name      : software_keyboard.py
# Version   : 1.0.0
# Brief     :
# Time-stamp: 2023-03-20 14:35
# Copyirght 2021 Hiroya Aoyama
# ===============================================================================

from PySide2 import QtWidgets  # , QtGui, QtCore
from typing import Union, Optional
from .ui_path import KEYBOARD_UI, NUMPAD_UI
from ..pyside_css import pyside_keyboard_css
from ..pyside_dynamic import loadUi


class KeyBoard(QtWidgets.QDialog):
    def __init__(self, widget: Optional[QtWidgets.QLineEdit]):
        super().__init__()
        loadUi(KEYBOARD_UI, self)
        self._line_string = ""  # NOTE: 記入した文字
        self._password = "__init__"
        self._shift_flag = False
        self._connect_function()
        # NOTE:
        self.setStyleSheet(pyside_keyboard_css())
        self.KeyEnter.clicked.connect(lambda: self._enter_string(widget))

    def _connect_function(self):
        self._connect_key(self.Key0, "0")
        self._connect_key(self.Key1, "1")
        self._connect_key(self.Key2, "2")
        self._connect_key(self.Key3, "3")
        self._connect_key(self.Key4, "4")
        self._connect_key(self.Key5, "5")
        self._connect_key(self.Key6, "6")
        self._connect_key(self.Key7, "7")
        self._connect_key(self.Key8, "8")
        self._connect_key(self.Key9, "9")
        self._connect_key(self.KeyA, "a")
        self._connect_key(self.KeyB, "b")
        self._connect_key(self.KeyC, "c")
        self._connect_key(self.KeyD, "d")
        self._connect_key(self.KeyE, "e")
        self._connect_key(self.KeyF, "f")
        self._connect_key(self.KeyG, "g")
        self._connect_key(self.KeyH, "h")
        self._connect_key(self.KeyI, "i")
        self._connect_key(self.KeyJ, "j")
        self._connect_key(self.KeyK, "k")
        self._connect_key(self.KeyL, "l")
        self._connect_key(self.KeyM, "m")
        self._connect_key(self.KeyN, "n")
        self._connect_key(self.KeyO, "o")
        self._connect_key(self.KeyP, "p")
        self._connect_key(self.KeyQ, "q")
        self._connect_key(self.KeyR, "r")
        self._connect_key(self.KeyS, "s")
        self._connect_key(self.KeyT, "t")
        self._connect_key(self.KeyU, "u")
        self._connect_key(self.KeyV, "v")
        self._connect_key(self.KeyW, "w")
        self._connect_key(self.KeyX, "x")
        self._connect_key(self.KeyY, "y")
        self._connect_key(self.KeyZ, "z")
        self._connect_key(self.KeyUnderBar, "_")
        self._connect_key(self.KeyHyphen, "-")
        self.KeyBackSpace.clicked.connect(lambda: self._edit_string("bs"))
        self.KeyShift.clicked.connect(lambda: self._edit_string("shift"))

    def _connect_key(self, widget: QtWidgets.QPushButton, key: str):
        widget.clicked.connect(lambda: self._input_key(key))

    def _input_key(self, key: str):
        if self._shift_flag:
            self._line_string = self._line_string + key.upper()
        else:
            self._line_string = self._line_string + key
        self.lineEdit.setText(self._line_string)

    def _edit_string(self, mode: str):
        if mode == "ac":
            # NOTE: All Clearの処理
            self._line_string = ""
            self.lineEdit.setText(self._line_string)
        elif mode == "bs":
            # NOTE: Back Spaceの処理
            if self._line_string == "":
                pass
            else:
                self._line_string = self._line_string[0:-1]
            self.lineEdit.setText(self._line_string)
        elif mode == "shift":
            # NOTE: Shiftの処理 A <-> a
            if self._shift_flag:
                self._shift_flag = False
            else:
                self._shift_flag = True
        else:
            pass

    def _enter_string(self, widget: Optional[QtWidgets.QLineEdit]):
        if widget is not None:
            widget.setText(self._line_string)
        # NOTE: _passwordを更新
        # NOTE: Dialogをenterで閉じたか、×で閉じたかの切り分けのため
        self._password = self._line_string
        self.accept()

    def get_input_word(self) -> str:
        return self._password


class NumPad(QtWidgets.QDialog):
    def __init__(self,
                 widget: Union[QtWidgets.QSpinBox,
                               QtWidgets.QDoubleSpinBox,
                               QtWidgets.QLineEdit],
                 numType: str = "int"):

        super().__init__()
        # self = QUiLoader().load(NUMPAD_UI)
        loadUi(NUMPAD_UI, self)
        self._line_string = ""
        self._connect_function()
        self.setStyleSheet(pyside_keyboard_css())

        if numType == 'int':
            self.KeyEnter.clicked.connect(lambda: self._enter_int_number(widget))
        elif numType == 'float':
            self.KeyEnter.clicked.connect(lambda: self._enter_double_number(widget))
        else:
            self.KeyEnter.clicked.connect(lambda: self._enter_str_number(widget))

    def _connect_function(self):
        self._connect_key(self.Key0, 0)
        self._connect_key(self.Key1, 1)
        self._connect_key(self.Key2, 2)
        self._connect_key(self.Key3, 3)
        self._connect_key(self.Key4, 4)
        self._connect_key(self.Key5, 5)
        self._connect_key(self.Key6, 6)
        self._connect_key(self.Key7, 7)
        self._connect_key(self.Key8, 8)
        self._connect_key(self.Key9, 9)

        self.KeyMinus.clicked.connect(lambda: self._input_signiture("-"))
        self.KeyDot.clicked.connect(lambda: self._input_signiture("."))
        self.KeyAllClear.clicked.connect(lambda: self._edit_string("ac"))
        self.KeyBackSpace.clicked.connect(lambda: self._edit_string("bs"))
        # self.setStyleSheet(pyside_keyboard_css())

    def _connect_key(self, widget: QtWidgets.QPushButton, num: int):
        widget.clicked.connect(lambda: self._input_number(num))

    def _input_number(self, num: int):
        self._line_string = self._line_string + str(num)
        self.lineEdit.setText(self._line_string)

    def _input_signiture(self, sgn: str):
        self._line_string = self._line_string + sgn
        self.lineEdit.setText(self._line_string)

    def _edit_string(self, mode: str):
        if mode == "ac":
            self._line_string = ""
            self.lineEdit.setText(self._line_string)
        elif mode == "bs":
            if self._line_string == "":
                pass
            else:
                self._line_string = self._line_string[0:-1]
            self.lineEdit.setText(self._line_string)
        else:
            pass

    def _enter_int_number(self, widget: QtWidgets.QSpinBox):
        # NOTE: 対象WidgetsがSpinBox int型
        widget.setValue(int(float(self._line_string)))
        self.accept()

    def _enter_double_number(self, widget: QtWidgets.QDoubleSpinBox):
        # NOTE: 対象WidgetsがDoubleSpinBox float型
        widget.setValue(float(self._line_string))
        self.accept()

    def _enter_str_number(self, widget: QtWidgets.QLineEdit):
        # NOTE: 対象WidgetsがLineEdit str型
        widget.setText(self._line_string)
        self.accept()


# class NumPad4LineEdit(QtWidgets.QDialog):
#     def __init__(self,
#                  widget: QtWidgets.QLineEdit,
#                  validationType: str = "int"):

#         super().__init__()
#         self = QUiLoader().load(NUMPAD_UI)
#         self.validation = validationType
#         self._line_string = ""
#         self._connect_function()

#         self.KeyEnter.clicked.connect(lambda: self._enter_str_number(widget))

#     def _connect_function(self):
#         self._connect_key(self.Key0, 0)
#         self._connect_key(self.Key1, 1)
#         self._connect_key(self.Key2, 2)
#         self._connect_key(self.Key3, 3)
#         self._connect_key(self.Key4, 4)
#         self._connect_key(self.Key5, 5)
#         self._connect_key(self.Key6, 6)
#         self._connect_key(self.Key7, 7)
#         self._connect_key(self.Key8, 8)
#         self._connect_key(self.Key9, 9)

#         self.KeyMinus.clicked.connect(lambda: self._input_signiture("-"))
#         self.KeyDot.clicked.connect(lambda: self._input_signiture("."))
#         self.KeyAllClear.clicked.connect(lambda: self._edit_string("ac"))
#         self.KeyBackSpace.clicked.connect(lambda: self._edit_string("bs"))
#         # self.setStyleSheet(pyside_keyboard_css())

#     def _connect_key(self, widget: QtWidgets.QPushButton, num: int):
#         widget.clicked.connect(lambda: self._input_number(num))

#     def _input_number(self, num: int):
#         self._line_string = self._line_string + str(num)
#         self.lineEdit.setText(self._line_string)

#     def _input_signiture(self, sgn: str):
#         self._line_string = self._line_string + sgn
#         self.lineEdit.setText(self._line_string)

#     def _edit_string(self, mode: str):
#         if mode == "ac":
#             self._line_string = ""
#             self.lineEdit.setText(self._line_string)
#         elif mode == "bs":
#             if self._line_string == "":
#                 pass
#             else:
#                 self._line_string = self._line_string[0:-1]
#             self.lineEdit.setText(self._line_string)
#         else:
#             pass

#     def _enter_str_number(self, widget: QtWidgets.QLineEdit):
#         # NOTE: 数値validation
#         try:
#             val = eval(self._line_string)
#         except Exception:
#             val = 0
#         if self.validation == 'int':
#             widget.setText(str(int(val)))
#         else:
#             widget.setText(self._line_string)

#         self.accept()
