# ===============================================================================
# Name      : qgv_circle.py
# Version   : 1.0.0
# Brief     : QGraphicsViewを使用した正円描画のクラス
# Time-stamp: 2022-11-23 16:51
# Copyirght 2022 Hiroya Aoyama
# ===============================================================================

from PySide2 import QtWidgets, QtGui, QtCore
from typing import Optional
from .qgv_base import (
    GraphicsBaseItem,
    COLOR_LIST,
)

try:
    from logger import setup_logger
    logger = setup_logger(__name__)
except Exception:
    from logging import getLogger
    logger = getLogger(__name__)

import math


def convert_ellipse2circle(ellipse: QtCore.QRectF) -> QtCore.QRectF:
    """EllipseItemで正円を表現

    """
    x = ellipse.x()
    y = ellipse.y()
    w = ellipse.width()
    h = ellipse.height()
    radius = int(math.sqrt(w**2 + h**2))
    diameter = radius * 2
    xc = x - radius
    yc = y - radius
    ellipse.setRect(xc, yc, diameter, diameter)

    return ellipse


def circle2ellipse(circle_data: list) -> QtCore.QRectF:
    xc, yc, r = circle_data
    x = float(xc - r)
    y = float(yc - r)
    width, height = float(2 * r), float(2 * r)
    qrf = QtCore.QRectF(x, y, width, height)
    return qrf


def ellipse2circle(ellipse_item: QtWidgets.QGraphicsEllipseItem) -> list:
    if ellipse_item is None:
        return None
    dx = ellipse_item.pos().x()
    dy = ellipse_item.pos().y()
    x = ellipse_item.rect().x() + dx
    y = ellipse_item.rect().y() + dy
    w = ellipse_item.rect().width()
    # h = ellipse_item.rect().height()
    radius = int(w / 2)
    xc = int(x + radius)
    yc = int(y + radius)
    return [xc, yc, radius]


class GraphicsCircle(GraphicsBaseItem):
    def __init__(self):
        # super(GraphicsScene_, self).__init__()
        super().__init__()
        self._handle_item = None
        self._circle: list = []
        self._new_shape_flag = False
        self._start = QtCore.QPointF()

    def set_circle_as_object(self):
        if self._handle_item is not None:
            self._handle_item.setPen(QtGui.QPen(
                COLOR_LIST[0], self._thickness, QtCore.Qt.SolidLine
            ))
            self._handle_item.setRect(circle2ellipse(self._circle))
            self._handle_item.setFlag(QtWidgets.QGraphicsItem.ItemIsMovable, True)
            self._new_shape_flag = False
            # NOTE: 初期化
            self._circle = []

    def set_circle_data(self, circle: list):
        # NOTE: アイテムが存在している場合削除
        if self._handle_item is not None:
            self.removeItem(self._handle_item)

        self._handle_item = QtWidgets.QGraphicsEllipseItem()
        self._circle = circle
        self.addItem(self._handle_item)
        self.set_circle_as_object()

    def get_circle_data(self) -> Optional[list]:
        if self._handle_item is not None:
            return ellipse2circle(self._handle_item)
        else:
            return None

    def set_shape_item(self, event: QtWidgets.QGraphicsSceneMouseEvent):
        if not self._new_shape_flag:
            self._new_shape_flag = True
        self._handle_item = QtWidgets.QGraphicsEllipseItem()
        self._handle_item.setPen(QtGui.QPen(
            COLOR_LIST[0], self._thickness, QtCore.Qt.SolidLine
        ))
        self.addItem(self._handle_item)
        self.s_pos = event.scenePos()
        r = QtCore.QRectF(self.s_pos, self.s_pos)
        r = convert_ellipse2circle(r)
        self._handle_item.setRect(r)

    def mousePressEvent(self, event: QtWidgets.QGraphicsSceneMouseEvent) -> None:
        return super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QtWidgets.QGraphicsSceneMouseEvent) -> None:
        if self._handle_item is not None:
            if self._new_shape_flag:
                r = QtCore.QRectF(self.s_pos, event.scenePos()).normalized()
                r = convert_ellipse2circle(r)
                self._handle_item.setRect(r)

        super(GraphicsCircle, self).mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QtWidgets.QGraphicsSceneMouseEvent) -> None:
        if self._handle_item is not None:
            if self._new_shape_flag:
                self._handle_item.setFlag(QtWidgets.QGraphicsItem.ItemIsMovable, True)
                self._new_shape_flag = False

            self._circle = ellipse2circle(self._handle_item)

        super(GraphicsCircle, self).mouseReleaseEvent(event)
