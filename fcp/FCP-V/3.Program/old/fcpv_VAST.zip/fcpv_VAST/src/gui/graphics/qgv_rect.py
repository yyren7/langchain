# ===============================================================================
# Name      : qgv_rect.py
# Version   : 1.0.0
# Brief     : QGraphicsViewを使用した矩形描画のクラス
# Time-stamp: 2022-11-23 18:05
# Copyirght 2022 Hiroya Aoyama
# ===============================================================================

from PySide2 import QtWidgets, QtGui, QtCore
from typing import Optional
from .qgv_base import (
    GraphicsBaseItem,
    COLOR_LIST,
    list_to_qrf,
    qrf_to_list
)

try:
    from logger import setup_logger
    logger = setup_logger(__name__)
except Exception:
    from logging import getLogger
    logger = getLogger(__name__)


class GraphicsRectangle(GraphicsBaseItem):
    def __init__(self):
        # super(GraphicsScene_, self).__init__()
        super().__init__()
        self._handle_item = None
        self._rect: list = []
        self._new_shape_flag = False
        self._start = QtCore.QPointF()

    def set_rect_as_object(self) -> None:
        """図形をアイテムとして固定"""
        if self._handle_item is not None:
            self._handle_item.setPen(QtGui.QPen(
                COLOR_LIST[0], self._thickness, QtCore.Qt.SolidLine
            ))
            self._handle_item.setRect(list_to_qrf(self._rect))
            self._handle_item.setFlag(QtWidgets.QGraphicsItem.ItemIsMovable, True)
            self._new_shape_flag = False
            # NOTE: 初期化
            self._rect = []

    def set_rect_data(self, rect: list) -> None:
        """
        矩形アイテムをセット

        Args:
            rect (list): _description_
        """
        # NOTE: アイテムが存在している場合削除
        if self._handle_item is not None:
            self.removeItem(self._handle_item)

        self._handle_item = QtWidgets.QGraphicsRectItem()
        self._rect = rect
        self.addItem(self._handle_item)
        self.set_rect_as_object()

    def get_rect_data(self) -> Optional[list]:
        """
        図形アイテムから座標を取得

        Returns:
            Optional[list]: _description_
        """
        if self._handle_item is not None:
            return qrf_to_list(self._handle_item)
        else:
            return None

    def set_shape_item(self, event: QtWidgets.QGraphicsSceneMouseEvent):
        """
        図形アイテムを設定
        Args:
            event (QtWidgets.QGraphicsSceneMouseEvent): _description_
        """
        if not self._new_shape_flag:
            self._new_shape_flag = True
        self._handle_item = QtWidgets.QGraphicsRectItem()
        self._handle_item.setPen(QtGui.QPen(
            COLOR_LIST[0], self._thickness, QtCore.Qt.SolidLine
        ))
        self.addItem(self._handle_item)
        self.s_pos = event.scenePos()
        r = QtCore.QRectF(self.s_pos, self.s_pos)
        self._handle_item.setRect(r)

    def mousePressEvent(self, event: QtWidgets.QGraphicsSceneMouseEvent) -> None:
        """マウスプレス時の処理"""
        return super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QtWidgets.QGraphicsSceneMouseEvent) -> None:
        """マウス移動時の処理"""
        if self._handle_item is not None:
            if self._new_shape_flag:
                r = QtCore.QRectF(self.s_pos, event.scenePos()).normalized()
                self._handle_item.setRect(r)

        super(GraphicsRectangle, self).mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QtWidgets.QGraphicsSceneMouseEvent) -> None:
        """マウスリリース時の処理"""
        if self._handle_item is not None:
            if self._new_shape_flag:
                self._handle_item.setFlag(QtWidgets.QGraphicsItem.ItemIsMovable, True)
                self._new_shape_flag = False

            self._rect = qrf_to_list(self._handle_item)

        super(GraphicsRectangle, self).mouseReleaseEvent(event)
