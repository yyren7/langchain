import sys
import numpy as np
# import cv2
import pyqtgraph as pg
from pyqtgraph.Qt import QtGui
from typing import Tuple, Optional

# def update_region():
#     start, end = select_region.getRegion()
#     indices = np.where((hist[1][:-1] >= start) & (hist[1][:-1] <= end))
#     hist_item.setData(hist[1][indices], hist[0][indices])


class HistGraph:
    def __init__(self, pw: pg.PlotWidget):
        self.pw = pw
        self.add_plot(pw)
        self.add_region(pw)
        self.add_config(pw)
        self.set_style(pw)
        self.set_region(10, 100)

    def add_plot(self, pw: pg.PlotWidget, hist: Optional[np.ndarray] = None, color: tuple = (0, 255, 0)):
        if hist is None:
            # NOTE: histデータがない時、適当なデータを生成
            vals = np.hstack([np.random.normal(loc=100, scale=10, size=500), np.random.normal(size=260, scale=10, loc=180)])
            y, x = np.histogram(vals, bins=np.linspace(0, 255, 255))
        else:
            x = np.arange(257)
            y = np.squeeze(hist)

        pw.plot(x, y, stepMode="center", fillLevel=0, fillOutline=True,
                pen=color, brush=(color[0], color[1], color[2], 150))

    def add_region(self, pw: pg.PlotWidget):
        """選択"""
        self.select_region = pg.LinearRegionItem()
        self.select_region.setZValue(10)
        pw.addItem(self.select_region)

    def update_data(self, hist: Optional[np.ndarray] = None, v1: int = 10, v2: int = 100, color: tuple = (30, 3, 200)):
        # NOTE: 全て消去してから再描画
        self.pw.clear()
        self.add_plot(self.pw, hist, color)
        self.add_region(self.pw)
        self.set_region(v1, v2)

    def set_region(self, v1: int, v2: int) -> None:
        """"""
        self.select_region.setRegion((v1, v2))

    def add_config(self, pw: pg.PlotWidget):
        """永久設定"""
        # NOTE: X軸のレンジを固定
        pw.setXRange(0, 255)
        # NOTE: マウスによる拡大縮小無効
        pw.setMouseEnabled(x=False, y=False)

    def set_style(self, pw: pg.PlotWidget):
        """永久設定"""
        pw.setBackground((255, 255, 255))

    def get_region(self) -> Tuple[int, int]:
        min_x, max_x = self.select_region.getRegion()
        return round(min_x), round(max_x)


if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    pw = pg.PlotWidget()
    hst = HistGraph(pw)
    pw.show()
    app.exec_()
