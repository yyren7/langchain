from PySide2 import QtWidgets, QtCore, QtGui
import numpy as np
import cv2

try:
    import matplotlib
    matplotlib.use('Agg')
finally:
    from matplotlib import pyplot as plt


class ParameterGraph:
    '''CREATE GRAPH CLASS'''

    def __init__(self):
        self.focus_max = 0
        self.focus_score_array = []
        self.x_grid = []
        self.frame_count = 0

    def call_focus_graph(self, src):
        height, width = src.shape[:2]
        roi = src[int(height * 0.25):int(height * 0.75),
                  int(width * 0.25):int(width * 0.75)]

        # focus_score = ParameterGraph.get_focus_score(roi)
        focus_score = self.get_focus_score(roi)

        # if self.focus_max < focus_score:
        #     self.focus_max = focus_score

        self.focus_score_array.append(focus_score)
        self.x_grid.append(self.frame_count)

        self.frame_count += 1

        # 配列長を制限
        while len(self.focus_score_array) > 30:
            del self.focus_score_array[0]
            del self.x_grid[0]

        graph_image = self.create_focus_graph(x=self.x_grid,
                                              y=self.focus_score_array)

        return graph_image

    def call_rgb_graph(self, src):
        height, width = src.shape[:2]
        roi = src[int(height * 0.25):int(height * 0.75),
                  int(width * 0.25):int(width * 0.75)]
        # b, g, r = ParameterGraph.get_rgb(roi)
        b, g, r = self.get_rgb(roi)
        graph_image = self.create_rgb_graph(r, g, b)
        return graph_image

    @staticmethod
    def get_focus_score(src: np.ndarray):
        gray = cv2.cvtColor(src, cv2.COLOR_BGR2GRAY)
        focus_score = cv2.Laplacian(gray, cv2.CV_64F).var()
        return focus_score

    @staticmethod
    def get_rgb(src: np.ndarray):
        r = np.average(src[:, :, 2])
        g = np.average(src[:, :, 1])
        b = np.average(src[:, :, 0])
        return b, g, r

    @staticmethod
    def create_focus_graph(x, y):
        focus_score_max = np.max(y)
        fig, ax = plt.subplots(figsize=(4.0, 2.0))
        ax.tick_params(labelbottom=False)
        ax.set_ylim(0, focus_score_max)
        ax.set_title("Focus score")
        ax.plot(x, y, 'b,-')
        fig.canvas.draw()
        # graph_image = np.array(fig.canvas.renderer.buffer_rgba())  # matplotlib >= 3.10
        graph_image = np.array(fig.canvas.renderer._renderer)  # matplotlib < 3.10
        graph_image = cv2.cvtColor(graph_image, cv2.COLOR_RGBA2BGR)
        # graph_image = cv2.resize(graph_image, (200, 100))
        plt.close()
        return graph_image

    @staticmethod
    def create_rgb_graph(r, g, b):
        fig, ax = plt.subplots(figsize=(4.0, 2.0))
        y = [r, g, b]
        x = ["R", "G", "B"]
        color = ["r", "g", "b"]
        ax.bar(x, y, color=color)
        ax.set_ylim(0, 255)
        ax.set_title("RGB average")
        fig.canvas.draw()
        # graph_image = np.array(fig.canvas.renderer.buffer_rgba())  # matplotlib >= 3.10
        graph_image = np.array(fig.canvas.renderer._renderer)  # matplotlib < 3.10
        graph_image = cv2.cvtColor(graph_image, cv2.COLOR_RGBA2BGR)
        # graph_image = cv2.resize(graph_image, (200, 100))
        plt.close()
        return graph_image
