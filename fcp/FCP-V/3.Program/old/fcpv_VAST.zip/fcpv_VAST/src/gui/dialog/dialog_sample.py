# ===============================================================================
# Name      : area_selector.py
# Version   : 1.0.0
# Brief     :
# Time-stamp: 2023-01-11 15:24
# Copyirght 2021 Hiroya Aoyama
# ===============================================================================
import os
import cv2
import sys
import numpy as np

from PySide2 import QtWidgets
from typing import Tuple, Optional

from ..graphics.qgv_lib import GraphicsRectangleLib
from ..widgets_controller import DialogController
from ..pyside_css import pyside_dialog_css
from .. import pyside_lib as pl
from pydantic import BaseModel


from ..pyside_dynamic import loadUi
try:
    from logger import setup_logger
    logger = setup_logger(__name__)
except Exception:
    from logging import getLogger
    logger = getLogger(__name__)


BASE_DIR = './gui/ui/register/'
WINDOW_UI = os.path.join(BASE_DIR, 'dialog_window.ui')
DIALOG_UI = os.path.join(BASE_DIR, 'blob_setting_page.ui')

COLOR_LS = ['gray', 'red', 'blue', 'green', 'custom']


def get_color_index(color: str) -> int:
    try:
        index = COLOR_LS.index(color)
        return index
    except Exception:
        return -1


class BlobExData(BaseModel):
    """管理データ"""
    input_color: str = 'gray'
    binary_thresh: int = 0
    num_of_blob: int = 0
    min_blob_size: int = -1
    max_blob_size: int = -1
    circularity_thresh: float = -1.0
    negative: bool = False


class DialogSample(DialogController):
    def __init__(self, image: np.ndarray):
        super().__init__()
        self.image = image.copy()
        self.add_widget()
        self.param = BlobExData()
        self.ui.setStyleSheet(pyside_dialog_css())
        self.set_graphics_view(image)
        self.connect_numpad()
        self.set_dialog()

    def add_widget(self):
        """ページの貼り付け"""
        loadUi(WINDOW_UI, self)
        self.ui = loadUi(DIALOG_UI)
        self.stackedWidget.addWidget(self.ui)

    def set_graphics_view(self, image: np.ndarray):
        self.qgv = GraphicsRectangleLib(image,
                                        view_widget=self.ui.graphicsView,
                                        scroll_widget=self.ui.scrollArea)

    def set_dialog(self, title: str = 'dialog') -> None:
        """ダイアログの表示処理
        """
        # NOTE: ダイアログを開いてから処理することで適切な画面サイズを取得
        self.setWindowTitle(title)
        self.setModal(True)
        self.show()

        self.qgv.set_frame(self.qgv.image)
        # NOTE: fit in viewをした場合scale = 1と考える
        self.qgv.scene.fit_in_view(self.qgv.w, self.qgv.h)

    def set_parameter(self):
        """GUIに設定値を反映"""
        pl.set_combobox(self.ui.inputImageBox, get_color_index(self.param.input_color))
        pl.set_value_into_line_edit(self.ui.binaryThresh, self.param.binary_thresh)
        pl.set_value_into_line_edit(self.ui.numOfBlob, self.param.num_of_blob)
        pl.set_value_into_line_edit(self.ui.minBlobSize, self.param.min_blob_size)
        pl.set_value_into_line_edit(self.ui.maxBlobSize, self.param.max_blob_size)
        pl.set_value_into_line_edit(self.ui.circularityThresh, self.param.circularity_thresh)
        pl.set_checkbox(self.negativeImageCheckBox, self.param.negative)

    def connect_numpad(self):
        self.ui.numPad_1.clicked.connect(lambda: self._open_numpad(widget=self.ui.binaryThresh, num_type='str'))
        self.ui.numPad_2.clicked.connect(lambda: self._open_numpad(widget=self.ui.numOfBlob, num_type='str'))
        self.ui.numPad_3.clicked.connect(lambda: self._open_numpad(widget=self.ui.minBlobSize, num_type='str'))
        self.ui.numPad_4.clicked.connect(lambda: self._open_numpad(widget=self.ui.maxBlobSize, num_type='str'))
        self.ui.numPad_5.clicked.connect(lambda: self._open_numpad(widget=self.ui.circularityThresh, num_type='str'))

    def get_value(self, widget: QtWidgets.QLineEdit):
        ret, value = pl.get_value_from_line_edit(widget)
        if not ret:
            self._show_error('Invalied Value')
        return value

    def get_parameter(self) -> dict:
        """GUIの設定値を読込"""
        _, id = pl.get_combobox(self.ui.inputImageBox)
        v1 = pl.get_value_from_line_edit(self.ui.binaryThresh)
        v2 = pl.get_value_from_line_edit(self.ui.numOfBlob)
        v3 = pl.get_value_from_line_edit(self.ui.minBlobSize)
        v4 = pl.get_value_from_line_edit(self.ui.maxBlobSize)
        v5 = pl.get_value_from_line_edit(self.ui.circularityThresh)
        b1 = pl.get_checkbox(self.ui.negativeImageCheckBox)

        return BlobExData(input_color=COLOR_LS[id],
                          binary_thresh=v1,
                          num_of_blob=v2,
                          min_blob_size=v3,
                          max_blob_size=v4,
                          circularity_thresh=v5,
                          negative=b1).dict()
