# ===============================================================================
# Name      : qgv_base.py
# Version   : 1.0.0
# Brief     : QGraphicsViewを使用した図形描画の基本クラス　qgv_rectやqgv_polygonに継承される
# Time-stamp: 2023-02-26 21:39
# Copyirght 2022 Hiroya Aoyama
# ===============================================================================

import numpy as np
from PySide2 import QtWidgets, QtGui, QtCore
from typing import Union, Tuple, Any
try:
    from logger import setup_logger
    logger = setup_logger(__name__)
except Exception:
    from logging import getLogger
    logger = getLogger(__name__)

ITEM_ID = {
    'BACKGROUND': None,
    'RECT': 3,
    'SVG': 4,
    'ELLIPSE': 3,
    'POLYGON': 5,
    'PIXELMAP': 7
}
COLOR_LIST = [
    QtCore.Qt.red, QtCore.Qt.blue,
    QtCore.Qt.green, QtCore.Qt.yellow
]


def qrf_to_list(rect_item: QtWidgets.QGraphicsRectItem) -> list:
    """QRectF(Float)のアイテムを受け取って座標をリストで返す

    Args:
        rect_item (QtWidgets.QGraphicsRectItem): _description_

    Returns:
        list: _description_
    """
    if rect_item is None:
        return None
    dx = rect_item.pos().x()
    dy = rect_item.pos().y()
    x = rect_item.rect().x() + dx
    y = rect_item.rect().y() + dy
    w = rect_item.rect().width()
    h = rect_item.rect().height()
    rect = [y, x, y + h, x + w]

    return [round(val) for val in rect]


def list_to_qrf(rect: list) -> QtCore.QRectF:
    """リストを受け取ってQRectFのアイテムを返す"""
    # NOTE: QRectFのためにint->float
    r = [float(val) for val in rect]
    qrf = QtCore.QRectF(r[1],
                        r[0],
                        r[3] - r[1],
                        r[2] - r[0])
    return qrf


def qpt_to_numpy(polygon_item: QtWidgets.QGraphicsPolygonItem) -> np.ndarray:
    """QPointのアイテムを受け取ってnumpyで返す"""
    if polygon_item is None:
        return None

    pts = polygon_item.polygon().toList()
    (dx, dy) = (polygon_item.pos().x(),
                polygon_item.pos().y())
    np_poly = [[pt.x() + dx, pt.y() + dy] for pt in pts]

    return np.array(np_poly, dtype=np.int32)


def array_to_qpt(polygon: Union[np.ndarray, list]) -> list:
    """
    numpyで受け取ってQPointのアイテムの入ったリストを返す
    QGraphicsPolygonItemはList[QPointF]と同義
    """
    qpt_poly = [QtCore.QPointF(poly[0], poly[1]) for poly in polygon]
    return qpt_poly


class GraphicsBaseItem(QtWidgets.QGraphicsScene):
    def __init__(self):
        # super(GraphicsScene_, self).__init__()
        super().__init__()
        # self.view_widget: QtWidgets.QGraphicsView
        self._handle_item: Any
        # self.view_widget = view
        self._handle_item = None
        self._new_shape_flag = False
        # NOTE: 線の太さ
        self._thickness = 3

    def set_view_widget(self, view: QtWidgets.QGraphicsView) -> None:
        """QGraphicsView Widgetをセット"""
        # self.view_widget: QtWidgets.QGraphicsView
        self.view_widget = view

    def set_thickness(self, thickness: int):
        """線の太さを指定"""
        self._thickness = thickness

    def clear_shape_item(self) -> None:
        """図形アイテムを削除"""
        if self._handle_item is not None:
            self.removeItem(self._handle_item)
            self._handle_item = None

    def set_shape_item(self, event: QtWidgets.QGraphicsSceneMouseEvent):
        """
        図形アイテムの生成処理（継承先で処理を書く）
        Args:
            event (QtWidgets.QGraphicsSceneMouseEvent): _description_
        """
        pass

    def mousePressEvent(self, event: QtWidgets.QGraphicsSceneMouseEvent) -> None:
        """マウスプレス時の処理

        Args:
            event (QtWidgets.QGraphicsSceneMouseEvent): _description_
        """
        clicked_item = self.itemAt(event.scenePos(), QtGui.QTransform())
        if clicked_item is None:
            logger.debug('mousePressEvent: clicked item is None Why?')
            return

        if self._new_shape_flag:
            # NOTE: 図形オブジェクトを確定する前
            # NOTE: setMouseTracking(True)にするとpixelmapの選択が不可能になる
            # NOTE: そのためオブジェクト未生成時はnewshapeflagでこっちの処理に入る
            if self._handle_item is not None:
                self.removeItem(self._handle_item)
            # NOTE: 継承先で好きな処理を入れる
            self.set_shape_item(event)

        else:
            # NOTE: 図形オブジェクトを確定した後
            if clicked_item.type() == ITEM_ID['PIXELMAP']:
                if not self._new_shape_flag:
                    self._new_shape_flag = True
                if self._handle_item is not None:
                    self.removeItem(self._handle_item)
                # NOTE: 継承先で好きな処理を入れる
                self.set_shape_item(event)

            elif clicked_item.type() == ITEM_ID['POLYGON']:
                self._handle_item = clicked_item

            elif clicked_item.type() == ITEM_ID['RECT']:
                self._handle_item = clicked_item

            else:
                pass

        super(GraphicsBaseItem, self).mousePressEvent(event)

    # def focusInEvent(self, event: QtWidgets.QGraphicsSceneResizeEvent) -> None:
    #     if self.view_widget is not None:
    #         self.view_widget.fitInView(self.sceneRect(), QtCore.Qt.KeepAspectRatio)

    def fit_in_view(self, width: int, height: int) -> None:
        """widgetに合わせて画像を拡大縮小
        任意に拡大縮小（ズームボタンを設ける）する場合は使ってはならない
        fitInViewでscaleが勝手が決まってしまうため、内部で管理しているズームサイズと整合性がとれない

        Args:
            event (QtWidgets.QGraphicsSceneMouseEvent): _description_
        """
        if self.view_widget is not None:
            self.setSceneRect(0, 0, width, height)
            self.view_widget.fitInView(self.sceneRect(), QtCore.Qt.KeepAspectRatio)


class GraphicsSceneRGB(QtWidgets.QGraphicsScene):
    # NOTE: カーソル位置のRGB情報を取得するクラス
    signal_list = QtCore.Signal(tuple)

    def __init__(self, use_slot: bool = False):
        super().__init__()
        # self.view_widget: QtWidgets.QGraphicsView = view
        self.use_slot = use_slot
        self._current_pos = QtCore.QPointF(0, 0)

    def set_view_widget(self, view: QtWidgets.QGraphicsView) -> None:
        # self.view_widget: QtWidgets.QGraphicsView
        self.view_widget = view

    def clear_shape_item(self) -> None:
        # NOTE: empty function
        pass

    def mousePressEvent(self, event: QtWidgets.QGraphicsSceneMouseEvent) -> None:
        if self.use_slot:
            self._current_pos = event.scenePos()
            x, y = self.get_current_pos()
            self.signal_list.emit((x, y))  # type: ignore
        super(GraphicsSceneRGB, self).mousePressEvent(event)

    def get_current_pos(self) -> Tuple[int, int]:
        return int(self._current_pos.x()), int(self._current_pos.y())

    # def focusInEvent(self, event: QtWidgets.QGraphicsSceneResizeEvent):
    #     if self.view_widget is not None:
    #         self.view_widget.fitInView(self.sceneRect(), QtCore.Qt.KeepAspectRatio)

    def fit_in_view(self, width: int, height: int) -> None:
        if self.view_widget is not None:
            self.setSceneRect(0, 0, width, height)
            self.view_widget.fitInView(self.sceneRect(), QtCore.Qt.KeepAspectRatio)
