# ===============================================================================
# Name      : pyqtgraph_view.py
# Version   : 1.0.0
# Brief     :
# Time-stamp: 2023-05-18 18:12
# Copyirght 2022 Hiroya Aoyama
# ===============================================================================
import pyqtgraph as pg
from PySide2 import QtCore


def pg2cv(pos: pg.Point, len: pg.Point, h: int) -> list:
    xmin = int(pos[0])
    xmax = int(pos[0] + len[0])
    ymin = int(h - (pos[1] + len[1]))
    ymax = int(h - pos[1])

    return [xmin, ymin, xmax, ymax]


class CustomRectROI(pg.RectROI):
    def __init__(self,
                 img_w: int,
                 img_h: int,
                 ymin: int,
                 xmin: int,
                 ymax: int,
                 xmax: int,
                 color: tuple = (255, 0, 0),
                 **kwards):

        self._img_w = img_w
        self._img_h = img_h

        # NOTE: 座標調整
        _ymin = img_h - ymax
        pos = [xmin, _ymin]
        size = [xmax - xmin, ymax - ymin]

        _maxbounds = QtCore.QRectF(0, 0, self._img_w, self._img_h)  # NOTE: QRectだとうまくうごかない

        super().__init__(pos=pos,
                         size=size,
                         pen=pg.mkPen(color=pg.mkColor(color[0], color[1], color[2]), width=2),
                         hoverPen=pg.mkPen(color=pg.mkColor(color[0], color[1], color[2]), width=4),
                         maxBounds=_maxbounds,
                         **kwards)

    def addHandle(self, *args, **kwargs):
        self.handleSize = 9
        super(CustomRectROI, self).addHandle(*args, **kwargs)

    def get_rect_data(self) -> list:
        """矩形ROIの座標を出力"""
        pos = self.pos()
        size = self.size()

        _ymin = int(self._img_h - pos[1] - size[1])
        _xmin = int(pos[0])
        _ymax = int(self._img_h - pos[1])
        _xmax = int(pos[0] + size[0])

        return [_ymin, _xmin, _ymax, _xmax]

    def set_rect_data(self, rect: list) -> None:
        """矩形ROIの座標を入力

        Args:
            ymin (int): _description_
            xmin (int): _description_
            ymax (int): _description_
            xmax (int): _description_
        """
        ymin, xmin, ymax, xmax = rect
        _ymin = self._img_h - ymax
        self.setPos([xmin, _ymin])
        self.setSize([xmax - xmin, ymax - ymin])

    def is_editable(self, enable: bool):
        self.resizable = enable
        self.translatable = enable
        if enable:
            self.setPen(color=pg.mkColor(255, 0, 0), width=1)
            self.addScaleHandle(pos=(1, 1),
                                center=(0.5, 0.5))
        else:
            self.setPen(color=pg.mkColor(255, 255, 255), width=1)
            _handles = self.getHandles()
            for handle in _handles:
                self.removeHandle(handle)
