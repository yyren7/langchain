import numpy as np
import pyqtgraph as pg


class FocusScoreGraph:
    '''CREATE GRAPH CLASS'''

    def __init__(self, pw: pg.PlotWidget):

        self.pw = pw

        self.HTML_DICT: dict = {
            'OK': '<div style="font-size: 20pt; background-color:#008000; padding: 1em;visibility: visible;">&nbsp;OK&nbsp;</div>',
            'NG': '<div style="font-size: 20pt; padding: 1em;visibility: hidden;"></div>',
            'SETUP': '<div style="font-size: 20pt; padding: 1em;visibility: visible;">&nbsp;SETUP&nbsp;</div>',
            'DEFAULT': '<div style="font-size: 20pt; padding: 1em;visibility: hidden;"></div>'
        }
        self.vb = self.pw.getViewBox()
        self.vb.enableAutoRange(axis='x', enable=True)
        self.text = pg.TextItem('')
        self.vb.setBackgroundColor('w')
        self.text.setHtml(self.HTML_DICT['DEFAULT'])
        self.text.setColor((0, 0, 0, 255))  # black
        self.text.setParentItem(self.vb)
        self.plot_score = pg.PlotDataItem(pen=pg.mkPen(color=(0, 0, 0, 255)))  # black
        self.pw.addItem(self.plot_score)
        self.pw.setTitle('Focus score', color=(0, 0, 0, 255))  # black
        self.pw.setYRange(0, 100, update=False)

        # NOTE: Qtmaterial適用によるviewBox見切れ問題回避
        # あえてすべての軸を表示としてAxisItem4種を入れ込み、setHeightとPen設定で
        # メモリが存在しないような見た目にする
        self.pw.showAxis('right', True)
        r_axis_item = self.pw.getAxis('right')
        r_axis_item.setWidth(10)
        r_axis_item.setPen((255, 255, 255, 0))
        r_axis_item.setTextPen((255, 255, 255, 0))

    def initialize(self):
        pass

    def update_focus_graph(self, x, y):
        # NOTE: 配列長を制限
        self.pw.setXRange(x[0], x[-1])
        self.plot_score.setData(x, y)
        return

    def switch_score_result(self, flag: str):
        # NOTE: HTMLで文字色切り替えできず、setColorで別途設定
        self.plot_score.setPen(pg.mkPen(color=(0, 0, 0, 255)))  # black
        self.vb.setBackgroundColor('w')
        self.text.setHtml(self.HTML_DICT['DEFAULT'])
        self.text.setColor((0, 0, 0, 0))  # black

        if flag == 'OK':
            # self.plot_score.setPen(pg.mkPen(color='green'))
            self.plot_score.setPen(pg.mkPen(color=(0, 255, 0, 255)))
            self.vb.setBackgroundColor((0, 255, 0, 100))
            self.text.setHtml(self.HTML_DICT['OK'])
            self.text.setColor((255, 255, 255, 255))
        elif flag == 'NG':
            # self.plot_score.setPen(pg.mkPen(color='r'))
            self.plot_score.setPen(pg.mkPen(color=(255, 0, 0, 255)))
            self.vb.setBackgroundColor('w')
            self.text.setHtml(self.HTML_DICT['NG'])
            self.text.setColor((255, 255, 255, 0))
        elif flag == 'SETUP':
            # self.plot_score.setPen(pg.mkPen(color='blue'))
            self.plot_score.setPen(pg.mkPen(color=(0, 0, 255, 255)))
            self.vb.setBackgroundColor('w')
            self.text.setHtml(self.HTML_DICT['SETUP'])
            self.text.setColor((0, 0, 255, 0))
        return


class RGBGraph:
    def __init__(self, pw: pg.PlotWidget):

        self.bar_r = pg.BarGraphItem(x=[0], height=[1], width=0.6, brush='r')
        self.bar_g = pg.BarGraphItem(x=[1], height=[1], width=0.6, brush='g')
        self.bar_b = pg.BarGraphItem(x=[2], height=[1], width=0.6, brush='b')

        pw.addItem(self.bar_r)
        pw.addItem(self.bar_g)
        pw.addItem(self.bar_b)

        pw.setTitle('RGB average', color=(0, 0, 0, 255))  # black

        ticks = {0: 'R', 1: 'G', 2: 'B'}
        pw.getAxis('bottom').setTicks([ticks.items()])

        pw.setXRange(-0.5, 2.5, update=False)
        pw.setYRange(0, 255, update=False)

        # NOTE: Qtmaterial適用によるviewBox見切れ問題回避
        pw.showAxis('right', True)

        r_axis_item = pw.getAxis('right')
        r_axis_item.setWidth(10)
        r_axis_item.setPen((255, 255, 255, 0))
        r_axis_item.setTextPen((255, 255, 255, 0))

        b_axis_item = pw.getAxis('bottom')
        b_axis_item.setHeight(30)

        # l_axis_item = pw.getAxis('left')
        # l_axis_item.setHeight(10)
        # l_axis_item.setPen((255, 255, 255, 0))
        # l_axis_item.setTextPen((255, 255, 255, 0))

    @ staticmethod
    def get_rgb(src: np.ndarray):
        r = np.average(src[:, :, 2])
        g = np.average(src[:, :, 1])
        b = np.average(src[:, :, 0])
        return b, g, r

    @ staticmethod
    def get_pt_rgb(src: np.ndarray, pt: tuple):
        h, w = src.shape[:2]
        if pt[0] < 0 or pt[0] > w - 1:
            return 0, 0, 0
        if pt[1] < 0 or pt[1] > h - 1:
            return 0, 0, 0
        b, g, r = src[pt[1], pt[0], :]
        return b, g, r

    def update_rgb_graph(self, src: np.ndarray):
        height, width = src.shape[:2]
        roi = src[int(height * 0.25):int(height * 0.75),
                  int(width * 0.25):int(width * 0.75)]

        b, g, r = self.get_rgb(roi)

        self.bar_r.setOpts(height=r)
        self.bar_g.setOpts(height=g)
        self.bar_b.setOpts(height=b)

    # NOTE: カーソルのRGB表示
    def update_pt_rgb_graph(self, src: np.ndarray, pt: tuple):
        b, g, r = self.get_pt_rgb(src, pt)
        self.bar_r.setOpts(height=r)
        self.bar_g.setOpts(height=g)
        self.bar_b.setOpts(height=b)
