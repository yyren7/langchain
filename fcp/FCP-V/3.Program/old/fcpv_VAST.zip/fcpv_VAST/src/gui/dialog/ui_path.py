import os

BASE_DIR = '.ui/'

# NOTE: ソフトウェアキーボード
KEYBOARD_UI = os.path.join(BASE_DIR, 'u_keyboard.ui')
NUMPAD_UI = os.path.join(BASE_DIR, 'u_numpad.ui')

# NOTE: レスポンス・結果表示
SUCCESS_UI = os.path.join(BASE_DIR, 'u_success.ui')
FAILED_UI = os.path.join(BASE_DIR, 'u_failed.ui')
ERROR_UI = os.path.join(BASE_DIR, 'u_error.ui')
NOTICE_UI = os.path.join(BASE_DIR, 'u_notice.ui')
DIALOG_UI = os.path.join(BASE_DIR, 'u_confirm_dialog.ui')
ROI_UI = os.path.join(BASE_DIR, 'u_show_roi.ui')

# NOTE: モデル操作
MODEL_CREATOR_UI = os.path.join(BASE_DIR, 'u_model_creator_dialog.ui')
MODEL_OPERATOR_UI = os.path.join(BASE_DIR, 'u_model_operator_dialog.ui')

# NOTE: 描画ダイアログ
GET_AREA_UI = os.path.join(BASE_DIR, 's_area_select.ui')
CREATE_ROI_UI = os.path.join(BASE_DIR, 's_roi_dialog.ui')
CREATE_MASK_UI = os.path.join(BASE_DIR, 's_mask_dialog.ui')
