# ===============================================================================
# Name      : graphicsView.py
# Version   : 1.0.0
# Brief     :
# Time-stamp: 2023-02-26 21:42
# Copyirght 2021 Hiroya Aoyama
# ===============================================================================
import cv2
import sys
import numpy as np

from PySide2 import QtWidgets, QtCore
from typing import Tuple, Optional

from .qgv_polygon import GraphicsPolygon
from .qgv_rect import GraphicsRectangle
from .qgv_base import GraphicsSceneRGB
from ..pyside_lib import paste_image_on_qgv, get_scale_size

try:
    from logger import setup_logger
    logger = setup_logger(__name__)
except Exception:
    from logging import getLogger
    logger = getLogger(__name__)


class GraphicsBaseLib:
    def __init__(self,
                 image: Optional[np.ndarray] = None,
                 combo_widget: Optional[QtWidgets.QComboBox] = None,
                 scroll_widget: Optional[QtWidgets.QScrollArea] = None):

        if image is None:
            self.image = None
        else:
            self.image = image.copy()
            self.h, self.w = image.shape[:2]

        # NOTE: スケールサイズ
        self._size = QtCore.QSize(0, 0)
        self._scale = 1.0

        # NOTE: widget
        self.combo_widget = combo_widget
        self.scroll_widget = scroll_widget

        # NOTE: その他
        self._applied = False

    def _zoom_in(self):
        """ズームイン"""
        if self.scroll_widget is None:
            return
        if self.image is None:
            return
        # NOTE: スケールサイズの計算
        self._size = QtCore.QSize(round(self._size.width() * 1.1),
                                  round(self._size.height() * 1.1))
        self._size, self._scale = get_scale_size(self.image, self._size)

    def _zoom_reset(self):
        """ズームリセット"""
        if self.scroll_widget is None:
            return
        if self.image is None:
            return
        # NOTE: スケールサイズの計算
        self._size = QtCore.QSize(int(self.scroll_widget.size().width() * 0.95),
                                  int(self.scroll_widget.size().height() * 0.95))
        self._size, self._scale = get_scale_size(self.image, self._size)

    def _update_combobox(self, items: list) -> None:
        """多角形を増加したときにコンボボックスをアップデート"""
        if self.combo_widget is not None:
            self.combo_widget.clear()
            self.combo_widget.addItems(items)

    def _get_combobox_text(self) -> str:
        """選択中のコンボボックスの値を取得"""
        if self.combo_widget is not None:
            return self.combo_widget.currentText()
        else:
            return ''


class GraphicsRGBLib(GraphicsBaseLib):
    # NOTE: QGraphicsViewを入れたDialogの基本クラス
    def __init__(self,
                 view_widget: QtWidgets.QGraphicsView,
                 image: Optional[np.ndarray] = None,
                 scroll_widget: Optional[QtWidgets.QScrollArea] = None,
                 use_slot: bool = False):

        super().__init__(image=image,
                         scroll_widget=scroll_widget)

        # NOTE: 描画クラス定義
        self.scene = GraphicsSceneRGB(use_slot=use_slot)
        self._set_graphics_view(widget=view_widget, w=self.w, h=self.h)

    def _set_graphics_view(self, widget: QtWidgets.QGraphicsView, *, w=0, h=0):
        if self.scene is None:
            return
        self.scene.set_view_widget(widget)
        widget.setScene(self.scene)
        if w != 0 and h != 0:
            self.scene.setSceneRect(0, 0, w, h)

    def _set_base_image(self, frame: np.ndarray) -> None:
        self.image = frame.copy()
        self.h, self.w = frame.shape[:2]
        self.mask_image = np.zeros((self.h, self.w, 3), np.uint8)

    # ===============================================================================
    # NOTE: 描画
    # ===============================================================================

    def set_frame(self, frame: Optional[np.ndarray] = None, *, w: int = 0, h: int = 0):
        if self.scene is None:
            return

        self.scene.clear_shape_item()
        if frame is None:
            if self.image is not None:
                frame = self.image.copy()
            else:
                return

        if w == 0 and h == 0:
            w = self._size.width()
            h = self._size.height()

        self.scene.setSceneRect(0, 0, w, h)
        paste_image_on_qgv(widget=self.scene, frame=frame, size=self._size)

    def zoom_in(self) -> None:
        self._zoom_in()
        self.set_frame(self.image)

    def zoom_out(self) -> None:
        self._zoom_reset()
        self.set_frame(self.image)

    def set_thickness(self, thickness: int) -> None:
        self.scene.set_thickness(thickness)

    # ===============================================================================
    # NOTE: レスポンス確認
    # ===============================================================================

    def is_enabled(self):
        return self._applied

    def is_applied(self):
        return self._applied


class GraphicsPolygonLib(GraphicsBaseLib):
    """多角形描画クラス"""

    def __init__(self, view_widget: QtWidgets.QGraphicsView,
                 image: Optional[np.ndarray] = None,
                 combo_widget: Optional[QtWidgets.QComboBox] = None,
                 scroll_widget: Optional[QtWidgets.QScrollArea] = None):

        super().__init__(image=image,
                         combo_widget=combo_widget,
                         scroll_widget=scroll_widget)

        if image is not None:
            self.mask_image = np.zeros((self.h, self.w, 3), np.uint8)

        # NOTE: 図形の座標、インデックス
        self._polygons: list = []
        self.poly_indexs: list = ['']

        # NOTE: 描画クラス定義
        self.scene = GraphicsPolygon()
        self._set_graphics_view(widget=view_widget)

    def _set_base_image(self, frame: np.ndarray) -> None:
        self.image = frame.copy()
        self.h, self.w = frame.shape[:2]
        self.mask_image = np.zeros((self.h, self.w, 3), np.uint8)

    def _set_graphics_view(self, widget: QtWidgets.QGraphicsView):
        """初期設定"""
        if self.scene is None:
            return
        self.scene.set_view_widget(widget)
        widget.setScene(self.scene)
        widget.setMouseTracking(True)

    # ===============================================================================
    # NOTE: 拡大縮小
    # ===============================================================================

    def _adjust_scale_view2poly(self, polys: list) -> list:
        # NOTE: GraphicsViewの座標から画像座標へ変換
        trans_poly = []
        for poly in polys:
            trans_poly.append([round(val * self._scale) for val in poly])
        return trans_poly

    def _adjust_scale_poly2view(self, polys: list) -> list:
        # NOTE: 画像座標からGraphicsViewの座標へ変換
        trans_poly = []
        for poly in polys:
            trans_poly.append([round(val / self._scale, 2) for val in poly])
        return trans_poly

    # ===============================================================================
    # NOTE: マルチボックス
    # ===============================================================================

    def _get_selected_polygon(self) -> Tuple[bool, list, int]:
        """選択した多角形の情報を取得"""
        poly_id = self._get_combobox_text()
        if poly_id == '':
            return False, [-1], -1
        poly = self._polygons[int(poly_id)]
        return True, poly, int(poly_id)

    # ===============================================================================
    # NOTE: 座標取得
    # ===============================================================================

    def _get_polygons(self):
        return self._polygons

    def _get_polygon(self) -> Tuple[bool, list]:
        poly = self.scene.get_polygon_data()
        if poly is None:
            return False, []
        poly_ls = poly.tolist()
        poly_ls = self._adjust_scale_view2poly(poly_ls)
        return True, poly_ls

    # ===============================================================================
    # NOTE: 各操作（読み込み、書き込み、削除、登録）
    # ===============================================================================

    def load_polygon(self, polygons: list) -> None:
        num_poly = len(polygons)
        if num_poly <= 0:
            return
        self._polygons = polygons
        self.poly_indexs = ['']
        for i in range(num_poly):
            self.poly_indexs.append(str(i))
        self._update_combobox(self.poly_indexs)
        dst = self.draw_polygons()
        self.set_frame(dst)

    def set_polygon(self) -> None:
        ret, poly, poly_id = self._get_selected_polygon()
        if not ret:
            # NOTE: 全ポリゴン描画
            dst = self.draw_polygons()
            self.set_frame(dst)
            return
        # NOTE: 対象のポリゴン以外描画
        dst = self.draw_polygons(poly_id)
        self.set_frame(dst)
        self.scene.set_polygon_data(self._adjust_scale_poly2view(poly))

    def add_polygon(self) -> None:
        poly = self.scene.get_polygon_data()
        if poly is None:
            return

        poly_ls = poly.tolist()
        poly_ls = self._adjust_scale_view2poly(poly_ls)
        text = self._get_combobox_text()
        if text == '':
            # NOTE: 新規ポリゴン追加時
            self._polygons.append(poly_ls)
            _idx = len(self.poly_indexs) - 1
            self.poly_indexs.append(str(_idx))
        else:
            # NOTE: ポリゴン変更時
            target_id = int(text)
            self._polygons[target_id] = poly_ls

        self._update_combobox(self.poly_indexs)
        dst = self.draw_polygons()
        self.set_frame(dst)

    def del_polygon(self) -> None:
        if len(self._polygons) == 0:
            return
        text = self._get_combobox_text()
        if text == '':
            # NOTE: 最後尾を削除時
            del self._polygons[-1]
            del self.poly_indexs[-1]
        else:
            # NOTE: 選択したポリゴン削除時
            target_id = int(text)
            del self._polygons[target_id]
            del self.poly_indexs[-1]

        self._update_combobox(self.poly_indexs)
        dst = self.draw_polygons()
        self.set_frame(dst)

    # ===============================================================================
    # NOTE: 描画
    # ===============================================================================

    def set_frame(self, frame: Optional[np.ndarray] = None,
                  *, w: int = 0, h: int = 0) -> None:
        """画像貼り付け"""
        if self.scene is None:
            return
        self.scene.clear_shape_item()

        if frame is None:
            if self.image is not None:
                frame = self.image.copy()
            else:
                return

        if w == 0 and h == 0:
            w = self._size.width()
            h = self._size.height()

        # NOTE: 現在のサイズでGraphicsViewを固定
        self.scene.setSceneRect(0, 0, w, h)
        paste_image_on_qgv(widget=self.scene, frame=frame, size=self._size)

    def draw_polygons(self, ignore_id: int = -1) -> np.ndarray:
        """複数の多角形を描画"""
        if self.image is None:
            raise Exception("")
        dst = self.image.copy()
        for i, polygon in enumerate(self._polygons):
            if i == ignore_id:
                continue
            dst = cv2.polylines(dst, [np.array(polygon)], isClosed=True, color=(0, 255, 0), thickness=2)
        return dst

    def zoom_in(self) -> None:
        """矩形の描画込みでズームイン"""
        self._zoom_in()
        dst = self.draw_polygons()
        self.set_frame(dst)

    def zoom_out(self) -> None:
        """矩形の描画込みでズームリセット"""
        self._zoom_reset()
        dst = self.draw_polygons()
        self.set_frame(dst)

    def set_thickness(self, thickness: int) -> None:
        """描画する矩形の線の太さを設定"""
        self.scene.set_thickness(thickness)

    # ===============================================================================
    # NOTE: レスポンス確認
    # ===============================================================================

    def is_enabled(self) -> bool:
        return self._applied

    def is_applied(self) -> bool:
        return self._applied


class GraphicsRectangleLib(GraphicsBaseLib):
    """矩形描画クラス"""

    def __init__(self, view_widget: QtWidgets.QGraphicsView,
                 image: Optional[np.ndarray] = None,
                 combo_widget: Optional[QtWidgets.QComboBox] = None,
                 scroll_widget: Optional[QtWidgets.QScrollArea] = None):

        super().__init__(image=image,
                         combo_widget=combo_widget,
                         scroll_widget=scroll_widget)

        # NOTE: 図形の座標、インデックス
        self.rectangles: list = []
        self.rect_indexs: list = ['']

        # NOTE: コンボボックスの有り無しでモード管理
        if combo_widget is None:
            self.multi_object = False
        else:
            self.multi_object = True

        # NOTE: その他
        self._applied = False

        self.scene = GraphicsRectangle()
        self._set_graphics_view(widget=view_widget)

    def _set_base_image(self, frame: np.ndarray) -> None:
        self.image = frame.copy()
        self.h, self.w = frame.shape[:2]

    def _set_graphics_view(self, widget: QtWidgets.QGraphicsView) -> None:
        """初期設定"""
        if self.scene is None:
            return
        self.scene.set_view_widget(widget)
        widget.setScene(self.scene)

    # ===============================================================================
    # NOTE: 拡大縮小
    # ===============================================================================

    def _adjust_scale_view2rect(self, rect: list) -> list:
        """GraphicsViewの座標から画像座標へ変換"""
        return [round(val * self._scale) for val in rect]

    def _adjust_scale_rect2view(self, rect: list) -> list:
        """座標画像座標からGraphicsViewの座標へ変換"""
        return [round(val / self._scale, 2) for val in rect]

    # ===============================================================================
    # NOTE: マルチボックス
    # ===============================================================================

    def _get_selected_rectangle(self) -> Tuple[bool, list, int]:
        """選択した矩形の情報を取得"""
        rect_id = self._get_combobox_text()
        if rect_id == '':
            return False, [-1], -1
        rect = self.rectangles[int(rect_id)]
        return True, rect, int(rect_id)

    # ===============================================================================
    # NOTE: 座標取得
    # ===============================================================================

    def _get_rectangles(self) -> list:
        """複数の矩形の座標を取得"""
        return self.rectangles

    def _get_rectangle(self) -> Tuple[bool, list]:
        """矩形の座標を取得"""
        rect = self.scene.get_rect_data()
        if rect is None:
            return False, []
        rect = self._adjust_scale_view2rect(rect)
        return True, rect

    # ===============================================================================
    # NOTE: 各操作（読み込み、書き込み、削除、登録）
    # ===============================================================================

    def load_rect(self, rectangles: list) -> None:
        """矩形を読み込む"""
        if self.combo_widget is not None:
            # NOTE: 図形複数保持 input=[[ymin,xmin,ymax,xmax],...]
            num_rect = len(rectangles)
            if num_rect <= 0:
                self.rectangles.clear()
                self.rect_indexs = ['']
                self._update_combobox([''])
                return

            self.rectangles = rectangles.copy()
            self.rect_indexs = ['']
            for i in range(num_rect):
                self.rect_indexs.append(str(i))
            self._update_combobox(self.rect_indexs)
            dst = self.draw_rectangles()
            self.set_frame(dst)
        else:
            # NOTE: 図形一個のみ input=[ymin,xmin,ymax,xmax]
            num_rect = len(rectangles)
            if num_rect <= 3:
                return
            self.scene.set_rect_data(self._adjust_scale_rect2view(rectangles))

    def set_rect(self) -> None:
        """
        対象IDの矩形オブジェクトをアイテムとして描画
        """
        ret, rect, rect_id = self._get_selected_rectangle()
        if not ret:
            # NOTE: 全矩形描画
            dst = self.draw_rectangles()
            self.set_frame(dst)
            return
        # NOTE: 対象の矩形以外描画
        dst = self.draw_rectangles(ignore_id=rect_id)
        self.set_frame(dst)
        self.scene.set_rect_data(self._adjust_scale_rect2view(rect))

    def add_rect(self) -> Tuple[bool, int]:
        """矩形を追加"""
        add_trigger = False

        rect = self.scene.get_rect_data()
        if rect is None:
            return False, -1
        rect = self._adjust_scale_view2rect(rect)
        if rect is None:
            return False, -1
        text = self._get_combobox_text()
        if text == '':
            # NOTE: 新規矩形追加時
            self.rectangles.append(rect)
            target_id = len(self.rect_indexs) - 1
            self.rect_indexs.append(str(target_id))
            add_trigger = True
        else:
            # NOTE: 矩形変更時
            target_id = int(text)
            self.rectangles[target_id] = rect

        self._update_combobox(self.rect_indexs)
        dst = self.draw_rectangles()
        self.set_frame(dst)
        return add_trigger, target_id

    def del_rect(self) -> int:
        """矩形を削除"""
        target_id = -1  # NOTE: 削除するインディックスを返す

        if len(self.rectangles) == 0:
            return -1
        text = self._get_combobox_text()
        if text == '':
            # NOTE: 最後尾を削除時
            target_id = len(self.rectangles) - 1
            del self.rectangles[-1]
            del self.rect_indexs[-1]
        else:
            # NOTE: 選択したポリゴン削除時
            target_id = int(text)
            del self.rectangles[target_id]
            del self.rect_indexs[-1]

        self._update_combobox(self.rect_indexs)
        dst = self.draw_rectangles()
        self.set_frame(dst)
        return target_id

    # ===============================================================================
    # NOTE: 描画
    # ===============================================================================

    def set_frame(self, frame: Optional[np.ndarray] = None,
                  *, w: int = 0, h: int = 0) -> None:
        """画像貼り付け"""
        if self.scene is None:
            return
        self.scene.clear_shape_item()

        if frame is None:
            if self.image is not None:
                frame = self.image.copy()
            else:
                return

        if w == 0 and h == 0:
            w = self._size.width()
            h = self._size.height()

        # NOTE: 現在のサイズでGraphicsViewを固定
        self.scene.setSceneRect(0, 0, w, h)
        paste_image_on_qgv(widget=self.scene, frame=frame, size=self._size)

    def rect2array(self, r: list) -> np.ndarray:
        """矩形から多角形に変換"""
        arr = np.array([[r[1], r[0]], [r[1], r[2]], [r[3], r[2]], [r[3], r[0]]])
        return arr

    def draw_rectangles(self, ignore_id: int = -1) -> np.ndarray:
        """多角形として複数の矩形を描画"""
        if self.image is None:
            raise Exception("")
        dst = self.image.copy()
        for i, rect in enumerate(self.rectangles):
            if i == ignore_id:
                continue
            dst = cv2.polylines(dst, [self.rect2array(rect)], isClosed=True, color=(0, 255, 0), thickness=2)
        return dst

    def draw_rectangle(self, rect: list) -> np.ndarray:
        """多角形として一個の矩形を描画"""
        if self.image is None:
            raise Exception("")
        dst = self.image.copy()
        dst = cv2.polylines(dst, [self.rect2array(rect)], isClosed=True, color=(0, 255, 0), thickness=2)
        return dst

    def zoom_in(self) -> None:
        """矩形の描画込みでズームイン"""
        self._zoom_in()
        dst = self.draw_rectangles()
        self.set_frame(dst)

    def zoom_out(self) -> None:
        """矩形の描画込みでズームリセット"""
        self._zoom_reset()
        dst = self.draw_rectangles()
        self.set_frame(dst)

    def set_thickness(self, thickness: int) -> None:
        """描画する矩形の線の太さを設定"""
        self.scene.set_thickness(thickness)

    # ===============================================================================
    # NOTE: レスポンス確認
    # ===============================================================================

    def is_enabled(self) -> bool:
        return self._applied

    def is_applied(self) -> bool:
        return self._applied

    # def get_current_image(self) -> np.ndarray:
    #     return self.image


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
