# ===============================================================================
# Name      : camera_page.py
# Version   : 1.0.0
# Brief     :
# Time-stamp: 2024-03-08 15:07
# Copyirght 2021 Hiroya Aoyama
# ===============================================================================
import sys
from PySide2 import QtWidgets
from typing import Union, Any
from .dialog.utils_dialog import (
    show_response,
    show_dialog,
    show_error,
    open_keyboard,
    open_numpad,
    show_roi,
    show_notice
)
from .pyside_dynamic import loadUi
from ui_utils.file_handler import FileHandler
from ui_utils.path_manager import PathManager
from gui.pyside_lib import set_message_on_statusbar
from typing import Optional


class WindowController(QtWidgets.QMainWindow):

    def __init__(self, ui_path: str, ui_title: str, page_idx: int = 99):
        super().__init__()
        self.statusbar: QtWidgets.QStatusBar
        self._current_page = page_idx
        loadUi(ui_path, self)
        self.setWindowTitle(ui_title)
        set_message_on_statusbar(self.statusbar, ui_title)

    def set_statusbar_message(self):
        pass

    def get_current_page(self) -> int:
        return self._current_page

    def page_changed(self, page_idx: int) -> bool:
        if page_idx == self._current_page:
            return False
        else:
            return True

    def page_update(self, page_idx: int) -> None:
        self._current_page = page_idx

    def show_error(self, msg: str):
        show_error(message=msg)

    def show_dialog(self, msg: str):
        return show_dialog(msg)

    def process_on_exit(self):
        pass

    def closeEvent(self, event: Any):
        # NOTE: GUIの終了イベント時の処理
        self.process_on_exit()
        event.accept()


class WidgetsController(QtWidgets.QWidget):
    """ページのコントローラクラス"""

    __version__ = '1.0.0'

    def __init__(self,
                 file_handler: FileHandler,
                 path_manager: PathManager):
        super().__init__()
        self.fh = file_handler
        self.pm = path_manager

    def initialize(self) -> None:
        pass

    def connect_function(self) -> None:
        pass

    def _show_dialog(self, text: str) -> bool:
        return show_dialog(text=text)

    def _show_response(self, res: bool) -> None:
        show_response(res=res)

    def _show_error(self, msg: str) -> None:
        show_error(message=msg)

    def _show_notice(self, msg: str) -> None:
        show_notice(message=msg)

    def _open_keyboard(self, widget: QtWidgets.QLineEdit) -> None:
        open_keyboard(widget=widget)

    def _open_numpad(self, widget: Union[QtWidgets.QSpinBox,
                                         QtWidgets.QDoubleSpinBox,
                                         QtWidgets.QLineEdit],
                     num_type: str = 'float') -> None:

        open_numpad(widget=widget, numType=num_type)

    def _show_img(self, src: Any) -> None:
        show_roi(src)


class DialogController(QtWidgets.QDialog):
    __version__ = '1.0.0'

    def __init__(self, file_handler: Optional[FileHandler] = None,
                 path_manager: Optional[PathManager] = None):
        super().__init__()
        if file_handler is not None:
            self.fh = file_handler
        if path_manager is not None:
            self.pm = path_manager

    def initialize(self) -> None:
        pass

    def connect_function(self) -> None:
        pass

    def _show_dialog(self, text: str) -> bool:
        return show_dialog(text=text)

    def _show_response(self, res: bool) -> None:
        show_response(res=res)

    def _show_error(self, msg: str) -> None:
        show_error(message=msg)

    def _show_notice(self, msg: str) -> None:
        show_notice(message=msg)

    def _open_keyboard(self, widget: QtWidgets.QLineEdit) -> None:
        open_keyboard(widget=widget)

    def _open_numpad(self,
                     widget: Union[QtWidgets.QSpinBox,
                                   QtWidgets.QDoubleSpinBox,
                                   QtWidgets.QLineEdit],
                     num_type: str = 'float',
                     validation: str = 'float') -> None:

        open_numpad(widget=widget, numType=num_type)

    def _show_img(self, src: Any, *, thickness: int = -1) -> None:
        show_roi(src, thickness=thickness)


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
