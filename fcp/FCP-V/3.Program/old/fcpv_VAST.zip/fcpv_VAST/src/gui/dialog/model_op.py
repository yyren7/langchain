# ===============================================================================
# Name      : model_handler.py
# Version   : 1.0.0
# Brief     :
# Time-stamp: 2023-01-25 13:53
# Copyirght 2021 Hiroya Aoyama
# ===============================================================================
import os
from PySide2.QtUiTools import QUiLoader
from ..widgets_controller import DialogController
from ..pyside_css import pyside_dialog_css
from typing import Tuple
from .ui_path import MODEL_CREATOR_UI, MODEL_OPERATOR_UI


def _get_filelist(path: str) -> list:
    filelist = []
    try:
        # NOTE: include folder name
        filelist = os.listdir(path)
    except Exception as e:
        print(e)
        filelist = []

    return filelist


class ModelCreator(DialogController):
    def __init__(self):
        super().__init__()
        self.ui = QUiLoader().load(MODEL_CREATOR_UI)
        self.ui.setStyleSheet(pyside_dialog_css())

        # NOTE: 内部管理
        self._applied = False
        self._modelname = ''

        self.connect_function()

    def initialize(self):
        return super().initialize()

    def connect_function(self) -> None:
        self.ui.toolButton.clicked.connect(lambda: self._open_keyboard(widget=self.ui.lineEdit))
        self.ui.applyButton.clicked.connect(lambda: self.create_model())
        self.ui.cancelButton.clicked.connect(lambda: self.ui.accept())

    def create_model(self) -> None:
        ret = self._show_dialog(text='Do you create new model?')
        if ret:
            self._modelname = self.ui.lineEdit.text()
            self._applied = True
        self.ui.accept()

    def is_enabled(self) -> bool:
        return self._applied

    def get_modelname(self) -> str:
        return self._modelname


class ModelOperator(DialogController):
    def __init__(self, model_dir: str, *, op: str = 'read'):
        super().__init__()
        self.ui = QUiLoader().load(MODEL_OPERATOR_UI)
        self.ui.setStyleSheet(pyside_dialog_css())

        if op != 'read':
            self.ui.opLabel.setText('DELETE MODEL')
        # self.ui.setStyleSheet(pyside_dialog_css())
        # NOTE: 内部管理
        self._applied = False
        self._modelname = ''

        self.model_dir = model_dir
        self.load_models()
        self.connect_function()

    def initialize(self):
        return super().initialize()

    def connect_function(self):
        self.ui.applyButton.clicked.connect(lambda: self.operation_apply())
        self.ui.cancelButton.clicked.connect(lambda: self.ui.accept())
        return super().connect_function()

    def load_models(self):
        modellist = _get_filelist(path=self.model_dir)
        for modelname in modellist:
            self.ui.comboBox.addItem(str(modelname))

    def operation_apply(self):
        modelname = self.ui.comboBox.currentText()
        self._applied = True
        self._modelname = modelname
        self.ui.accept()

    def is_enabled(self):
        return self._applied

    def get_modelname(self):
        return self._modelname


def operate_model(model_dir: str, op: str) -> Tuple[bool, str]:
    if op == 'create':
        dlg = ModelCreator()
        dlg.ui.setWindowTitle("Create Model")
        dlg.ui.exec_()
    elif op == 'read':
        dlg = ModelOperator(model_dir=model_dir)
        dlg.ui.setWindowTitle("Read Model")
        dlg.ui.exec_()
    else:
        dlg = ModelOperator(model_dir=model_dir, op='del')
        dlg.ui.setWindowTitle("Delete Model")
        dlg.ui.exec_()

    if dlg.is_enabled():
        modelname = dlg.get_modelname()
        return True, modelname
    else:
        return False, ''
