# -*- coding : UTF-8 -*-
# ===============================================================================
# Name      : main_process.py
# Version   : 1.0.0
# Brief     : main process
# Time-stamp: 2024-03-15 15:16
# Copyirght 2024 Tatsuya Sugino
# ===============================================================================
# #####################################
# ##### 標準モジュール
import sys
import os
import datetime
import re
import json
import time
import copy
from time import sleep, perf_counter                # noqa
from typing import List, Union, Tuple, Type, TypeVar
from pydantic import BaseModel

# NOTE: test用
import csv

# #####################################
# ##### 自作モジュール
from lib.calibration.option_basemodel import OptionModel
from lib.calibration.param_basemodel import (
    CalibrationDataModel,
)
from lib.calibration.alignment_controller import AlignmentModule
from config.var import *  # noqa
from lib.plc import get_setting
from module.utils.handle_union import handleUnion, setUnion
from module.utils.path_manager import PathManager
from module.utils.file_handler import FileHandler
from module.base_sequence_module import BaseSequenceModule
from lib.mymqtt.mqtt_client_module_q import MQTTClient
from module.myfunction import setFigletText, importLibrary, convertReal2Dword, compareLists, convertDword2Real
from module.param.main_mqtt_param import MQTTCommParamToPlc, MQTTCommParamToTcp, MQTTCommParamToObserver, MQTTCommParamToUpload
from setting import Parameter
from setting import *  # noqa


try:
    from logger import setup_logger
    # logger = setup_logger(__name__)
    now = datetime.datetime.now()
    logger = setup_logger(__name__, filename=f'{now:%Y_%m_%d}', htype='FILE')
except Exception:
    from logging import getLogger
    logger = getLogger(__name__)


class PositionData(BaseModel):
    """位置情報の基本データ"""
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    r: float = 0.0


class myException(Exception):
    def __init__(self, e):
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        raise type(e)(str(sys.exc_info()[1]) + ' : [' + str(fname) + '][' + 'Line:' + str(exc_tb.tb_lineno) + ']')


# #################
# NOTE:ライブラリ依存処理
# #################
def makeGlobalVar(name: List[str], val: List[int], offset: int):
    """ グローバル変数を動的に定義する
    Parameters
    ----------
    name : グローバル変数名
    val  : グローバル変数に対応する数値
    """
    # 変数を定義
    for i in range(len(name)):
        exec("{} = {}".format(name[i], val[i] + offset), globals())


def get_dataDict(xlsx_file: str) -> dict:
    name_s, val_s = ([], [])
    name_c, val_c = ([], [])
    name_W, val_W = ([], [])
    name_D, val_D = ([], [])

    print("Start to get plc setting parameter.")
    # NOTE:接続PLCパラメータ読み込み
    get_setting.check_file(xlsx_file)
    plc_param = get_setting.getPLCParam(book_name=xlsx_file,
                                        sheet_name="CONFIG")
    # NOTE:開始アドレス読み込み
    name_s, val_s = get_setting.getParamDict(name_s, val_s,
                                             book_name=xlsx_file,
                                             sheet_name="CONFIG")
    # NOTE:configアドレス読み込み
    name_c, val_c = get_setting.getParamDetails(name_c, val_c,
                                                book_name=xlsx_file,
                                                sheet_name="CONFIG")
    # NOTE:PC2PLC　ビット割付アドレス読み込み
    name_W, val_W = get_setting.getWdataDict(name_W, val_W,
                                             book_name=xlsx_file,
                                             sheet_name="BIT_IN")    # IN_BIT
    # NOTE:PLC2PC　ビット割付アドレス読み込み
    name_W, val_W = get_setting.getWdataDict(name_W, val_W,
                                             book_name=xlsx_file,
                                             sheet_name="BIT_OUT")   # OUT_BIT
    # NOTE:PC2PLC　ワード割付アドレス読み込み
    name_D, val_D = get_setting.getDdataDict(name_D, val_D,
                                             book_name=xlsx_file,
                                             sheet_name="WORD_IN")   # IN_WORD
    # NOTE:PLC2PC　ワード割付アドレス読み込み
    name_D, val_D = get_setting.getDdataDict(name_D, val_D,
                                             book_name=xlsx_file,
                                             sheet_name="WORD_OUT")  # OUT_WORD
    # NOTE:グローバル変数定義
    makeGlobalVar(name_s, val_s, offset=0)
    makeGlobalVar(name_c, val_c, offset=0)
    makeGlobalVar(name_W, val_W, offset=0)
    makeGlobalVar(name_D, val_D, offset=10)

    print("Got plc setting parameter completely.")

    return plc_param


class MainController(BaseSequenceModule):
    def __init__(self):
        super().__init__()
        setFigletText("#######")
        setFigletText("Run FRVP Program")
        setFigletText("#######")
        # カレントディレクトリパス取得
        self.current_dir = os.path.dirname(os.path.abspath(__file__))
        if os.name == "nt":
            self.setting_dir = os.path.dirname(os.path.abspath(__file__))
        else:
            self.setting_dir = ""

        # NOTE:共用体操作クラスのオブジェクト生成
        self.plc_param = get_dataDict(xlsx_file=self.setting_dir + ADDR_PATH)
        # 画像処理エンジンの通信設定パラメータクラス
        self.param = Parameter(path=self.setting_dir)
        # 画像処理エンジンAPIクラス　動的インポート
        mod = importLibrary(Path=self.current_dir + API_PATH, Name=self.param.vision_name + "_api")
        self.v = mod.VisionApi(self.param.dst_vision_ip, self.param.dst_vision_port)
        self.v._init_socket()
        # NOTE:アライメントクラス ロード遅い
        self.a = AlignmentModule(sheet_path=self.setting_dir + ALIGNMENT_PATH)
        # NOTE:パスクラス
        self.pm = PathManager(header=DATA_PATH + TARGET_WORK_NAME, modelname="")
        # NOTE:ファイルクラス
        self.fh = FileHandler(header=MODEL_PATH)
        # NOTE:共用対クラス
        self.hu = handleUnion()
        # 書込みサイズ
        self.plc2pc_len = int(PLC2PC_SUM) + 1  # Ex.99+1
        self.pc2plc_len = int(PC2PLC_SUM) + 1  # Ex.99+1
        # パラメータON状態・OFF状態の定義
        self.BIT_ON = 1
        self.BIT_OFF = 0
        # # ↓運転モード内で使用する定数
        self.RUNOK = 0       # 検査OK
        self.RUNNG = 1       # 検査NG
        self.RUNERR = 2      # 検査ERR
        self.plc_previous_time = time.perf_counter()
        self.mqtt_previous_time = time.perf_counter()
        self.prev_status = self.getStatus()
        self.prev_phase = self.getPhase()
        #
        self.bflag = False
        self.previous_bflag = False

        # NOTE:モデルデータのロード
        self.loadAllModelParamer()

        # MQTTクラス初期化
        if self.param.isPlcProcess == "True":
            self.initializeMqttClientForPlcProcessAsMain()
        else:
            self.initializeMqttClientForTcpProcessAsMain()
        self.initializeMqttClientForObserverProcessAsMain()
        self.initializeMqttClientForUploaderProcessAsMain()
        # upload用の変数定義
        self.upload_param = []

    # NOTE:内部パラメータを初期化

    def resetParam(self):
        print("Reset internal Parameter")
        # NOTE:シーケンスパラメータのリセット
        self.resetSequenceParameter()
        if self.param.isPlcProcess == "True":
            self.resetWriteMqttPlcData()
        else:
            self.resetWriteMqttTcpData()

    # ===============================================================================
    # NOTE: デバッグ用メソッド
    # ===============================================================================

    def showInputPlcdata(self, SHOW=False):
        if SHOW:
            _DATA = self.hu.convBits2Words(loop=self.plc2pc_len,
                                           threshold=PLC2PC_W - 1,
                                           union=self.r_u_data)   # 共用体 -> INT配列変換
            print("Len={},READ=\n{}".format(len(_DATA), _DATA))

    def showOutputPlcdata(self, SHOW=False):
        if SHOW:
            _DATA = self.hu.convBits2Words(loop=self.pc2plc_len,
                                           threshold=PC2PLC_W - 1,
                                           union=self.w_u_data)  # 共用体 -> INT配列変換
            print("Len={},WRITE=\n{}".format(len(_DATA), _DATA))

    # ===============================================================================
    # NOTE: MQTT汎用メソッド
    # ===============================================================================
    def initializeMqttClientForPlcProcessAsMain(self):  # PLC
        # NOTE:MQTT通信クラス
        self.mqtt_main_client = MQTTClient()
        # MQTT通信パラメータ
        self.mqtt_plc_data = MQTTCommParamToPlc()
        # MQTTdataの初期化
        self.setInitialMqttPlcData()
        # Read　writeデータ(union)の初期化　
        rdata, wdata = self.convertDataclass2Union(mqtt_data=self.mqtt_plc_data)
        self.r_u_data = rdata.copy()
        self.prev_r_u_data = rdata.copy()
        self.w_u_data = wdata.copy()
        self.prev_w_u_data = wdata.copy()
        # PLCの時
        self.pub_main_topic = self.param.mqttTopicName + '/FRVP/plc2main/'
        self.sub_main_topic = self.param.mqttTopicName + '/FRVP/main2plc/'
        # Pub/Subを作成
        self.mqtt_main_client.makePublisher()
        self.mqtt_main_client.makeSubscriber(topic_name=self.sub_main_topic)
        # ループ開始
        self.mqtt_main_client.startPublisherLoop()
        self.mqtt_main_client.startSubscriberLoop()

    def initializeMqttClientForTcpProcessAsMain(self):  # Tcp
        # NOTE:MQTT通信クラス
        self.mqtt_main_client = MQTTClient()
        # MQTT通信パラメータ
        self.mqtt_tcp_data = MQTTCommParamToTcp()
        # MQTTdataの初期化
        self.setInitialMqttTcpData()
        # Read　writeデータ(union)の初期化　
        rdata, wdata = self.convertDataclass2Union(mqtt_data=self.mqtt_tcp_data)
        self.r_u_data = rdata.copy()
        self.prev_r_u_data = rdata.copy()
        self.w_u_data = wdata.copy()
        self.prev_w_u_data = wdata.copy()
        # TCPの時
        self.pub_main_topic = self.param.mqttTopicName + '/FRVP/tcp2main/'
        self.sub_main_topic = self.param.mqttTopicName + '/FRVP/main2tcp/'
        # Pub/Subを作成
        self.mqtt_main_client.makePublisher()
        self.mqtt_main_client.makeSubscriber(topic_name=self.sub_main_topic)
        # ループ開始
        self.mqtt_main_client.startPublisherLoop()
        self.mqtt_main_client.startSubscriberLoop()

    def initializeMqttClientForObserverProcessAsMain(self):  # OBSERVER
        # NOTE:MQTT通信クラス
        self.mqtt_observer_client = MQTTClient()
        # MQTT通信パラメータ
        self.mqtt_observer_data = MQTTCommParamToObserver()
        self.pub_observer_topic = self.param.mqttTopicName + '/FRVP/main/online/'
        self.sub_observer_topic = self.param.mqttTopicName + '/FRVP/main/ack_online/'  # do not use
        # Pub/Subを作成
        self.mqtt_observer_client.makePublisher()
        self.mqtt_observer_client.makeSubscriber(topic_name=self.sub_observer_topic)
        # ループ開始
        self.mqtt_observer_client.startPublisherLoop()
        self.mqtt_observer_client.startSubscriberLoop()

    def initializeMqttClientForUploaderProcessAsMain(self):  # UPLOADER
        # NOTE:MQTT通信クラス
        self.mqtt_uploader_client = MQTTClient()
        # MQTT通信パラメータ
        self.mqtt_upload_data = MQTTCommParamToUpload()

        self.pub_uploader_topic = self.param.mqttTopicName + '/FRVP/upload/main/'
        self.sub_uploader_topic = self.param.mqttTopicName + '/FRVP/upload/ack_main/'  # do not use
        # Pub/Subを作成
        self.mqtt_uploader_client.makePublisher()
        self.mqtt_uploader_client.makeSubscriber(topic_name=self.sub_uploader_topic)
        # ループ開始
        self.mqtt_uploader_client.startPublisherLoop()
        self.mqtt_uploader_client.startSubscriberLoop()

    def setInitialMqttPlcData(self):
        self.mqtt_plc_data.comm_data.read = [0] * self.plc2pc_len
        self.mqtt_plc_data.comm_data.write = [0] * self.pc2plc_len

    def setInitialMqttTcpData(self):
        self.mqtt_tcp_data.comm_data.read = [0] * self.plc2pc_len
        self.mqtt_tcp_data.comm_data.write = [0] * self.pc2plc_len

    def resetWriteMqttPlcData(self):
        self.mqtt_plc_data.comm_data.write = [0] * self.pc2plc_len

    def resetWriteMqttTcpData(self):
        self.mqtt_tcp_data.comm_data.write = [0] * self.pc2plc_len

    # ===============================================================================
    # NOTE: MQTT用変換メソッド
    # ===============================================================================

    def convertJson2Dataclass(self, json_data: dict, data_class):
        # JSONをディクショナリに変換
        dict_data = json.loads(json_data)
        # データ型に変換
        data_instance = data_class(**dict_data)
        return data_instance

    def convertList2Union(self, data_list: List[int], loop: int, threshold: int) -> Union[List[int], int]:
        # ListをUnionに変換
        union_data = self.hu.convWords2Bits(loop=loop, threshold=threshold, ary=data_list)
        return union_data

    def convertDataclass2Union(self, mqtt_data: MQTTCommParamToPlc) -> Tuple[Union[List[int], int], Union[List[int], int]]:
        # PLCデータをUnionに変換
        read_union_data = self.convertList2Union(mqtt_data.comm_data.read, self.plc2pc_len, self.plc2pc_len)
        write_union_data = self.convertList2Union(mqtt_data.comm_data.write, self.pc2plc_len, self.pc2plc_len)
        return read_union_data, write_union_data

    def convertDataclass2SingleUnion(self, mqtt_data: MQTTCommParamToPlc, key: str) -> Union[List[int], int]:
        # PLCデータをUnionに変換
        if key == 'read':
            union_data = self.convertList2Union(mqtt_data.comm_data.read, self.plc2pc_len, self.plc2pc_len)
        elif key == 'write':
            union_data = self.convertList2Union(mqtt_data.comm_data.write, self.pc2plc_len, self.pc2plc_len)
        return union_data
    #####################################################################

    def convertUnion2List(self, union_data: Union[List[int], int], loop: int, threshold: int) -> List[int]:
        # UnionをListに変換
        list_data = self.hu.convBits2Words(loop=loop, threshold=threshold, union=union_data)
        return list_data

    def convertUnion2Dataclass(self, mqtt_data: MQTTCommParamToPlc, read_union_data: Union[List[int], int], write_union_data: Union[List[int], int]) -> MQTTCommParamToPlc:
        # UnionデータをPLCデータに変換して代入
        mqtt_data.comm_data.read = self.convertUnion2List(read_union_data, self.plc2pc_len, PLC2PC_W - 1)
        mqtt_data.comm_data.write = self.convertUnion2List(write_union_data, self.pc2plc_len, PC2PLC_W - 1)
        return mqtt_data

    def convertDataclass2Json(self, mqtt_data: MQTTCommParamToPlc) -> str:
        # Dataclassをディクショナリに変換し、それをJSONに変換
        dict_data = mqtt_data.dict()
        json_data = json.dumps(dict_data)
        return json_data

    # ===============================================================================
    # NOTE: MQTT用汎用メソッド
    # ===============================================================================

    def _subscribeFromBroker(self, mqtt_client: MQTTClient, _mqtt_data, data_class):
        #####################################################################
        # NOTE:Subscribe処理  (MQTT ->Any プロセス )
        #####################################################################
        # Subscribe from MQTTBroker
        _json = mqtt_client.SubscribeFromBroker()
        if _json is not None:
            # convert json->Dataclass
            _mqtt_data = self.convertJson2Dataclass(json_data=_json, data_class=data_class)
            return _json, _mqtt_data

        else:
            return None, _mqtt_data

    def _publishToBroker(self,
                         mqtt_client: MQTTClient,
                         mqtt_data,
                         topic_name,
                         qos: int = 1):
        #####################################################################
        # NOTE:Publish処理  ()
        #####################################################################
        # Publish to MQTTBroker
        # convert dataclass->json
        send_json = self.convertDataclass2Json(mqtt_data=mqtt_data)
        # Publish to MQTTBroker
        mqtt_client.publishToBroker(topic_name=topic_name,
                                    payload=send_json,
                                    qos=qos)

    def mqttHeartBeat(self, mqtt_data: MQTTCommParamToObserver):
        current_time = time.perf_counter()
        beat_freq = 2.0
        current_beat = current_time - self.mqtt_previous_time
        if current_beat > beat_freq:
            if mqtt_data.main_beat.online:
                mqtt_data.main_beat.online = False
                self.bflag = False
            elif not mqtt_data.main_beat.online:
                mqtt_data.main_beat.online = True
                self.bflag = True
            # print(f"BEAT is {mqtt_data.main_beat.online}")
            # 現在時刻を前の時刻とする
            self.mqtt_previous_time = current_time
        return mqtt_data

    # データベースへ送信するデータを作成
    def makeVisionDataForDB(self,):
        judge, seq, pos, custom_values = self.upload_param
        # judge, seq, pos, custom_values = [2, 12, [111.123, 234.222, 345.123, 55.45], [34, 56, 78, 24, 234]] #debug

        self.mqtt_upload_data.upload.vision.judge = judge
        self.mqtt_upload_data.upload.vision.seq = seq
        for i in range(4):
            setattr(self.mqtt_upload_data.upload.vision, ["x", "y", "z", "r"][i], pos[i])

        # リストの長さに応じて動的に変数を代入
        for j, value in enumerate(custom_values, start=1):
            setattr(self.mqtt_upload_data.upload.vision, f"custom{j}", value)

    # ===============================================================================
    # NOTE: PLCデータ確認用
    # ===============================================================================
    # NOTE:立ち上がり確認

    def triggerUp(self, tag: str = "REQUEST_COMMON", key: str = "READY"):
        try:
            flag = False
            current_bin = self.r_u_data[tag].bit[key]
            previous_bin = self.prev_r_u_data[tag].bit[key]

            # 現在のビットと以前のビットを比較、差が１ならば立ち上がり、0 OR -1は無視
            if current_bin - previous_bin == 1:
                flag = True
        except Exception as e:
            print(f"triggerup err {e}")
        return flag

    # NOTE:立ち下がり確認
    def triggerDown(self, tag: str = "REQUEST_COMMON", key: str = "READY"):
        try:
            flag = False
            current_bin = self.r_u_data[tag].bit[key]
            previous_bin = self.prev_r_u_data[tag].bit[key]

            # 現在のビットと以前のビットを比較、差が-１ならば立ち上がり、0 OR 1は無視
            if current_bin - previous_bin == -1:
                flag = True
        except Exception as e:
            print(f"triggedown err {e}")
        return flag

    # PLCユニオンデータの更新を確認する
    def compareDoubleLists(self,
                           rc_u_list,
                           rp_u_list,
                           wc_u_list,
                           wp_u_list):
        rc_list = self.convertUnion2List(rc_u_list, self.plc2pc_len, PLC2PC_W - 1)
        rp_list = self.convertUnion2List(rp_u_list, self.plc2pc_len, PLC2PC_W - 1)
        wc_list = self.convertUnion2List(wc_u_list, self.pc2plc_len, PC2PLC_W - 1)
        wp_list = self.convertUnion2List(wp_u_list, self.pc2plc_len, PC2PLC_W - 1)

        is_r_change = compareLists(rc_list, rp_list)
        is_w_change = compareLists(wc_list, wp_list)

        return is_r_change, is_w_change

    # ===============================================================================
    # NOTE: モデルロードメソッド
    # ===============================================================================

    def atoi(self, text):
        return int(text) if text.isdigit() else text

    def natural_keys(self, text):
        return [self.atoi(c) for c in re.split(r'(\d+)', text)]

    def loadAllModelParamer(self):
        # model path
        _path = self.current_dir + self.fh._header
        # 1d連想配列作成

        _calib_dict_data = {}
        _opt_dict_data = {}

        # NOTE:modelフォルダリスト取得
        f_list = self.fh._get_filelist(path=_path)
        # NOTE：文字列名前順ソート
        f_list = sorted(f_list, key=self.natural_keys)

        # NOTE:各モデルをロード
        for idx, m in enumerate(f_list):
            _calib_data = self.fh.load_config(path=_path + m + CALIB_FILE,
                                              modelname=m,
                                              no_log=True,)
            _opt_data = self.fh.load_config(path=_path + m + OPT_FILE,
                                            modelname=m,
                                            no_log=True,)
            # NOTE:Base Class
            try:
                calib_cfg = CalibrationDataModel(**_calib_data)
                option_cfg = OptionModel(**_opt_data)
            except Exception as e:
                calib_cfg = CalibrationDataModel()
                option_cfg = OptionModel()

            # NOTE:dict append
            _calib_dict_data[idx] = calib_cfg
            _opt_dict_data[idx] = option_cfg
        # selfつけて更新
        self.calib_dict_data = _calib_dict_data.copy()
        self.opt_dict_data = _opt_dict_data.copy()
    # ===============================================================================
    # NOTE: アライメントメソッド
    # ===============================================================================

    def calculate_alignment_data(self, pos: PositionData, calib_num: int) -> list:
        """補正量計算"""
        _method = self.opt_dict_data[calib_num].correction_config.correction_method
        _base_rpos = self.calib_dict_data[calib_num].base_position.robot_position
        _base_vpos = self.calib_dict_data[calib_num].base_position.image_position
        
        # NOTE: 結果を計算
        if _method == 'absolute':
            # NOTE: pix2mm 絶対座標で出力
            dx, dy, dr = self.a.abs_correction(PositionData(
                x=pos.x, y=pos.y, r=pos.r), self.calib_dict_data[calib_num])
        elif _method == 'relative':
            # NOTE: pix2mm 相対座標で出力
            # dx, dy, dr = self.rel_correction(PositionData(x=pos.x, y=pos.y, r=pos.r), self.calib_cfg)
            dx, dy, dr = self.a.relative_correction(
                PositionData(x=pos.x, y=pos.y, r=pos.r), self.calib_dict_data[calib_num])

        elif _method == 'absolute2':
            # NOTE: mm2mm 絶対座標で出力
            dx, dy, dr = pos.x, pos.y, pos.r

        elif _method == 'relative2':
            # NOTE: mm2mm 相対座標で出力
            dx, dy, dr = pos.x - _base_rpos.x, pos.y - _base_rpos.y, pos.r - _base_rpos.r

        return [round(dx, 3), round(dy, 3), 0.0, round(dr, 3)]

    # NOTE:キャリブレーションシートに記載の通りにデータのソート
    def alignVisionData(self, data, flow_num=0):
        # NOTE:補正後の変数用意
        _data = data.copy()
        # NOTE:補正用の箱用意　xyzr
        _align_xyz_idx = [-1, -1, -1, -1]
        # NOTE：シートタグ確認
        for i, val in enumerate(self.a.ccp.calib_config[flow_num].items()):
            tag = val[1]  # (idx,要素)
            if tag == "Xpos" or tag == "xpos" or tag == "X" or tag == "x":
                _align_xyz_idx[X] = i  # 0

            elif tag == "Ypos" or tag == "ypos" or tag == "Y" or tag == "y":
                _align_xyz_idx[Y] = i  # 1

            elif tag == "Rpos" or tag == "rpos" or tag == "R" or tag == "r":
                _align_xyz_idx[R] = i  # 3

            # 終了条件　data長と比較
            if i >= len(data):
                break
        # print(_align_xyz_idx, _data, flow_num)
        # NOTE:XYRセットで補正
        align_pos = self.calculate_alignment_data(pos=PositionData(x=data[_align_xyz_idx[X]],
                                                                   y=data[_align_xyz_idx[Y]],
                                                                   r=data[_align_xyz_idx[R]]),
                                                  calib_num=self.a.ccp.calib_num[flow_num])

        # NOTE:補正結果上書き
        _data[_align_xyz_idx[X]] = align_pos[X]
        _data[_align_xyz_idx[Y]] = align_pos[Y]
        _data[_align_xyz_idx[R]] = align_pos[R]
        return _data

    # ###########################################################################
    # NOTE:運転モード中の共通関数
    # 1.PC ⇒　画像処理システムに実行命令
    # 2.実行状態をPLC管理変数に展開

    def modeExecution(
        self,
        word_tag: int = 0,                   # PLCTag 1W   下記1bitが存在する1W領域
        bit_tag: int = 0,                    # PLCTag 1bit 実行状態を通知するフラグ
    ):

        # PLCヘ ON通知　PLC←PC
        self.w_u_data[word_tag].bit[bit_tag] = self.BIT_ON
        # フロー番号READ　PLC⇒PC
        self.v.flow = self.r_u_data[PROGRAM_NO].word
        self.v.config = self.r_u_data[CONFIG_NO].word
        self.v.model = self.r_u_data[MODEL_NO].word
        self.v.position = self.r_u_data[POSITION_NO].word
        # 画像処理システムへ撮影フロー番号送信　PLC⇒画像処理システム
        self.v.SendAndReceive(flow=self.r_u_data[PROGRAM_NO].word,
                              cfg=self.r_u_data[CONFIG_NO].word,
                              mdl=self.r_u_data[MODEL_NO].word,
                              pos=self.r_u_data[POSITION_NO].word,)

    # ###########################################################################
    # NOTE:運転モード中の共通関数
    # 1.実行フェーズのリセット
    # 2.IDLE状態へ遷移

    def modeReset(self, key: str = "", is_all=False):
        # key名指定　:指定Phaseのカウントリセット
        # key名無指定:全てのPhaseのカウントリセット
        if is_all:
            self.resetPhase(key="n_reset")
            self.resetPhase(key="n_inspection")
        else:
            self.resetPhase(key=key)

        # Status更新 Status ⇒ IDLE
        self.updateStatus(val="IDLE")

    def forceSequenceReset(self):
        if self.checkPhase(key="n_reset", val=0):
            ret = (self.r_u_data[REQUEST_COMMON].bit[RST_PC_ERR] == self.BIT_ON)
            if ret:
                self.w_u_data[COMPLETE_COMMON].bit[ALARM_RESET] = self.BIT_ON  # ALARM_RESET ON
                self.modeReset(key="n_inspection")
                # Status更新 phaseTag ⇒ IDLE
                self.updateStatus(val="IDLE")
                self.incrementPhase("n_reset")

        elif self.checkPhase(key="n_reset", val=1):
            ret = (self.r_u_data[REQUEST_COMMON].bit[RST_PC_ERR] == self.BIT_OFF)
            if ret:
                self.w_u_data[COMPLETE_COMMON].bit[ALARM_RESET] = self.BIT_OFF  # ALARM_RESET OFF
                self.resetPhase("n_reset")

    # ###########################################################################
    # SEQ Reset

    def sequenceReset(self):
        self.updateStatus(val="RESET")
        if self.r_u_data[REQUEST_COMMON].bit[IDLE_MODE] == self.BIT_OFF:
            self.modeReset(key="", is_all=True)

    # INI
    def initSequence(self):
        # 機種切替
        self.updateStatus(val="IDLE")

    # IDLE トリガー入力を得て各モードに遷移する
    def idleSequence(self):

        # Status更新 IDLE ⇒ INSPECTION
        if self.r_u_data[REQUEST_COMMON].bit[INSPECT_START] == self.BIT_ON:  # この条件いらないか？
            self.updateStatus(val="INSPECTION")

        # Status更新 IDLE ⇒ INSPECTION    CAPTURE有り
        if self.r_u_data[REQUEST_COMMON].bit[CAPTURE_START] == self.BIT_ON:
            self.updateStatus(val="INSPECTION")

    # RealToDoubleWord ビジョンの結果をセットする
    def setVisionData(self, data, start_addr):
        i = 0   # 書込み開始位置
        for v in data:  # LoWorrdData,HiWordDataに分割
            low_word_data, high_word_data = convertReal2Dword(v)
            self.w_u_data[start_addr + i].word = low_word_data
            self.w_u_data[start_addr + 1 + i].word = high_word_data
            # print(i, ":", start_addr + i, self.w_u_data[start_addr + i].word, ":", start_addr + 1 + i, self.w_u_data[start_addr + 1 + i].word)
            i += 2

    # DoubleWordToReal ビジョンの結果を取り出す
    def ejectVisionData(self, start_addr=DATA1_LOWER):
        i = 0   # 書込み開始位置
        data = []
        for i in range(20):  # DATA20までのため
            _low = self.w_u_data[start_addr + i].word
            _up = self.w_u_data[start_addr + 1 + i].word
            real_word_data = convertDword2Real(low_word_data=_low, high_word_data=_up)
            data.append(real_word_data)
            # print(i, ":", start_addr + i, self.w_u_data[start_addr + i].word, ":", start_addr + 1 + i, self.w_u_data[start_addr + 1 + i].word)
            i += 2
        return data

    # 検査SEQ 撮影信号有りバージョン
    def captureInspectionSequence(self):
        insp_ret = False

        # phase:0 Dummy撮影(STATUS:CAPTURE START ON確認 & CAPTURING ON)
        if self.checkPhase(key="n_inspection", val=0):
            self.insp_t1 = time.perf_counter()  # 測定開始
            if self.r_u_data[REQUEST_COMMON].bit[CAPTURE_START] == self.BIT_ON:
                self.w_u_data[STATUS_COMMON].bit[CAPTURING] = self.BIT_ON  # CAPTURING ON
                # NG・ERR　CODEの初期化
                self.w_u_data[NG_CODE].word = self.BIT_OFF
                self.w_u_data[ERR_CODE].word = self.BIT_OFF
                # phase インクリメント
                self.incrementPhase(key="n_inspection")

        # phase:1 Dummy撮影中(STATUS:CAPTURING OFF)
        elif self.checkPhase(key="n_inspection", val=1):
            time.sleep(0.05)  # DummyTimer(重要)将来的にはなくしたい...
            self.w_u_data[STATUS_COMMON].bit[CAPTURING] = self.BIT_OFF  # CAPTURING OFF
            # phase インクリメント
            self.incrementPhase(key="n_inspection")

        # phase:2 Dummy撮影完了(STATUS:CAPTURE RECV　CMP　ON確認)
        elif self.checkPhase(key="n_inspection", val=2):
            print("Debug phase2")
            if self.r_u_data[COMPLETE_COMMON].bit[CAPTURE_RECV_COMP] == self.BIT_ON:  # CAPTURE RECV COMP
                # phase インクリメント
                self.incrementPhase(key="n_inspection")

        # phase:3 実行(STATUS:INSPECTING ON)
        elif self.checkPhase(key="n_inspection", val=3):
            if self.r_u_data[REQUEST_COMMON].bit[INSPECT_START] == self.BIT_ON:
                self.w_u_data[STATUS_COMMON].bit[INSPECTING] = self.BIT_ON  # INSPECTING ON
                self.modeExecution(word_tag=STATUS_COMMON,
                                   bit_tag=INSPECTING,
                                   )

                # phase インクリメント
                self.incrementPhase(key="n_inspection")

        # phase:4 検査実行中(画像処理システムから結果待機)
        elif self.checkPhase(key="n_inspection", val=4):
            ret = self.v.getReslut(self.v.judge)  # ret = 0:OK, 1:NG, 2:Err, None：待機
            # print("ret4", ret)
            if ret is not None:
                # 実行シーケンスの送信　
                self.w_u_data[ACK_PROGRAM_NO].word = self.v.seq
                # phase インクリメント
                self.incrementPhase(key="n_inspection")
        
        # phase:5 画像処理システム結果確認・結果をPLC転送Bufferに保管
        elif self.checkPhase(key="n_inspection", val=5):
        
            self.w_u_data[STATUS_COMMON].bit[INSPECTING] = self.BIT_OFF  # INSPECTING OFF
            # print("inspecting offed")
            ret = self.v.getReslut(self.v.judge)  # ret = 0:OK, 1:NG, 2:Err, None：待機
            vParam = self.v.param  # judge flow番号を先頭から除いたもの　
            stadrs = DATA1_LOWER    # データ繰り返し書込み開始アドレス　
            # print("ret _ result", ret)
            # 画像処理システム OK
            if ret == self.RUNOK:
                try:
                    _vParam = self.alignVisionData(data=vParam, flow_num=self.v.flow)
                    # print("calibnum : ",self.a.ccp.calib_num[self.v.flow])
                    # 検出時間
                    insp_t2 = time.perf_counter() - self.insp_t1
                    print("Execute Flow:[{}] ".format(self.v.flow))
                    print("Vision Engine Param:{}".format(vParam))
                    print("Proc Time: [{}ms], Method:[{}]".format(round(insp_t2 * 1000, 6),
                                                                self.opt_dict_data[self.a.ccp.calib_num[self.v.flow]].correction_config.correction_method))
                    print("FRVP Param{}".format(_vParam))

                    # # test用CSV書き込み
                    # proc_time = round(insp_t2 * 1000, 6)
                    # desktop_path = os.path.join(os.path.expanduser('~'), 'Desktop')
                    # file_path = os.path.join(desktop_path, 'aa.csv')
                    # data = [1, proc_time]
                    # with open(file_path, 'a', newline='') as file:
                    #     writer = csv.writer(file)
                    #     writer.writerow(data)
                    # ## end

                except Exception as e:
                    print("Exception inspectionSequence:", e)

                self.w_u_data[NG_CODE].word = ret
                print("OK判定=", self.v.judge)
                self.w_u_data[COMPLETE_COMMON].bit[INSPECT_OK] = self.BIT_ON  # INSPECT_OK

            # 画像処理システム Err⇒OK判定以外、FLOWErr判定以外をErrとする
            elif ret == self.RUNNG:
                print("Execute Flow:[{}] ".format(self.v.flow))
                self.w_u_data[NG_CODE].word = ret
                print("NG判定=", self.v.judge)
                self.w_u_data[COMPLETE_COMMON].bit[INSPECT_NG] = self.BIT_ON  # INSPECT_NG
                _vParam = vParam.copy()

            # PLCヘ画像処理システムのエラー情報を通知
            elif ret == self.RUNERR:
                print("RUNERR")
                print("Execute Flow:[{}] ".format(self.v.Flow))
                self.updateStatus(val="ERROR")  # Status更新 INSPECTION ⇒ ERROR
                self.w_u_data[COMPLETE_COMMON].bit[INSPECT_ERR] = self.BIT_ON  # INSPECT_ERR
                _vParam = vParam.copy()

            # 取得データ数の回数データの分割解析を行う
            # ビジョン結果書き込み（そのまま）
            self.setVisionData(data=_vParam, start_addr=stadrs)
            # uploader用データへ
            self.upload_param = [ret, self.v.seq, _vParam[:4],
                                _vParam[4:]]  # [int, int, list(x,y,z,r),list(c1,c2,c3....)]
            # phase インクリメント
            self.incrementPhase(key="n_inspection")

        # phase:6 PLCが結果を受け取ったか確認
        elif self.checkPhase(key="n_inspection", val=6):
            # print("Phase6 start")
            if self.r_u_data[COMPLETE_COMMON].bit[INSPECT_RECV_COMP] == self.BIT_ON:
                # COMPLETE_COMMON INSPECT_OK・NG・ERRのOFF
                keyAry = [INSPECT_OK, INSPECT_NG, INSPECT_ERR]
                for v in keyAry:
                    # print("phase6", v)
                    self.w_u_data[COMPLETE_COMMON].bit[v] = self.BIT_OFF
                # phase インクリメント
                self.incrementPhase(key="n_inspection")

        # phase:7 モードのリセット
        elif self.checkPhase(key="n_inspection", val=7):
            self.modeReset(key="n_inspection")
            insp_ret = True
        return insp_ret

    # Error SEQ
    #   self.v.judge = 画像処理システム ErrCode
    #   送信対象外:
    #       OK判定  OK = "0"
    #       NG判定  FLOW_ERR = "2"
    #   送信対象:
    #       Err判定 REQUESTDATANO_ERR = "1" or RESPONSE_ERR = "3" or REQUEST_ERR = "4"
    #               REQUESTDATATHRESH_ERR = "5" or REQUESTDATACOUNT_ERR = "6"
    def errorSequence(self):
        ret = (self.r_u_data[REQUEST_COMMON].bit[RST_PC_ERR] == self.BIT_ON)
        # Err Reset
        if ret:
            self.w_u_data[STATUS_COMMON].bit[PC_ERR] = self.BIT_OFF
            self.w_u_data[PC_ERR_CODE].word = self.v.judge

            # 撮影中解除
            self.w_u_data[STATUS_COMMON].bit[CAPTURING] = self.BIT_OFF
            # 検査中解除
            self.w_u_data[STATUS_COMMON].bit[INSPECTING] = self.BIT_OFF
            # ErrorSEQ解除
            self.modeReset(key="n_error")

        # Err Set
        else:
            self.w_u_data[STATUS_COMMON].bit[PC_ERR] = self.BIT_ON
            self.w_u_data[PC_ERR_CODE].word = self.v.judge

    # NOTE:メソッド

    # NOTE:プログラムバージョンを書き込み
    def writeInformation(self, number):
        # プログラムバージョンの書き込み
        self.w_u_data[MAJOR_V].word = PROGRAM_VERSION_MAJOR
        self.w_u_data[MINOR_V].word = PROGRAM_VERSION_MINOR
        self.w_u_data[PATCH_V].word = PROGRAM_VERSION_PATCH

        self.w_u_data[TARGET_NO].word = number

    # NOTE:PLCへの生存通知
    def heartBeat(self):
        current_time = time.perf_counter()
        beat_freq = 1.0
        current_beat = current_time - self.plc_previous_time
        if current_beat > beat_freq:

            if self.checkFlag(key="is_pc_online"):
                # STATUS_ONLINEフラグをOFF
                self.w_u_data[STATUS_COMMON].bit[PC_ONLINE] = self.BIT_OFF
                # フラグをOFF
                self.updateFlag(key="is_pc_online", val=False)
            elif not self.checkFlag(key="is_pc_online"):
                # STATUS_ONLINEフラグをON
                self.w_u_data[STATUS_COMMON].bit[PC_ONLINE] = self.BIT_ON
                # フラグをON
                self.updateFlag(key="is_pc_online", val=True)
            # 現在時刻を前の時刻とする
            self.plc_previous_time = current_time

    # NOTE:PLCデータを保持
    def savePreviousPlcData(self):
        self.prev_r_u_data = copy.deepcopy(self.r_u_data)
        self.prev_w_u_data = copy.deepcopy(self.w_u_data)

    def saveFlagAsPreviousFlag(self, flag: bool):
        self.previous_bflag = copy.deepcopy(flag)

    #############################################################
    # メインプログラム
    #############################################################
    def main(self):
        # try:
        print("Run Main")
        cnt = 100                       # ループカウント
        self.updateStatus(val="INIT")   # ループ用ステータス

        # 画像処理システム　TCPサーバー接続確認
        ref = self.v._connect_server()
        try:
            while ref is False:   # 起動待機
                if USE_DUMMY_ENGINE:
                    break
                ref = self.v._connect_server()
                if ref is True:
                    break
                print('画像処理システム Connect待機')
            esc = False
        except KeyboardInterrupt:   # Ctrl + C で強制終了
            esc = True
        if esc:
            print('ToEnd')
            return  # 強制終了

        # 初期パラメータをPLCへ書き込み
        self.writeInformation(self.v.TARGET_NO)

        # メインのループ動作
        while True:
            try:
                # Wait
                t1 = time.perf_counter()
                sleep(0.001)

                #####################################################################
                # NOTE:Subscribe処理 PLC or TCP(MQTT -> MAIN)
                #####################################################################
                if self.param.isPlcProcess == "True":
                    # Subscribe from MQTTBroker
                    self.main_plc_json, self.mqtt_plc_data = self._subscribeFromBroker(
                        self.mqtt_main_client, self.mqtt_plc_data, MQTTCommParamToPlc)
                    if self.main_plc_json is not None:
                        # convert dataclass->union
                        self.r_u_data = self.convertDataclass2SingleUnion(mqtt_data=self.mqtt_plc_data,
                                                                          key="read")
                else:
                    # Subscribe from MQTTBroker
                    self.main_tcp_json, self.mqtt_tcp_data = self._subscribeFromBroker(
                        self.mqtt_main_client, self.mqtt_tcp_data, MQTTCommParamToTcp)
                    if self.main_tcp_json is not None:
                        # convert dataclass->union
                        self.r_u_data = self.convertDataclass2SingleUnion(mqtt_data=self.mqtt_tcp_data,
                                                                          key="read")

                #####################################################################

                # NOTE:メイン処理,VISIONシステム操作及び、状態フィードバック
                #####################################################################
                # 状態遷移
                # val="IDLE"        アイドルモード
                # val="INSPECTION"　検査モード
                # val="ERROR"       エラー
                # val="INIT"        初期状態
                #####################################################################
                if self.checkStatus(val="IDLE"):
                    self.idleSequence()

                elif self.checkStatus(val="INSPECTION"):
                    self.captureInspectionSequence()  # CAPTUREシグナル有り

                elif self.checkStatus(val="ERROR"):
                    self.errorSequence()

                else:
                    self.initSequence()  # val="INIT"

                if self.r_u_data[REQUEST_COMMON].bit[IDLE_MODE] == self.BIT_ON:
                    self.modeReset(key="", is_all=True)

                self.forceSequenceReset()  # 強制シーケンスリセット

                #####################################################################

                # NOTE:PLC生存通知
                self.heartBeat()

                #####################################################################
                # NOTE:Publish処理 PLC or TCP(MAIN -> MQTT)
                #####################################################################
                if self.param.isPlcProcess == "True":
                    # convert union->dataclass
                    self.mqtt_plc_data = self.convertUnion2Dataclass(mqtt_data=self.mqtt_plc_data,
                                                                     read_union_data=self.r_u_data,
                                                                     write_union_data=self.w_u_data,)
                    # # convert dataclass->json
                    self._publishToBroker(mqtt_client=self.mqtt_main_client,
                                          mqtt_data=self.mqtt_plc_data,
                                          topic_name=self.pub_main_topic,
                                          )
                else:
                    # convert union->dataclass
                    self.mqtt_tcp_data = self.convertUnion2Dataclass(mqtt_data=self.mqtt_tcp_data,
                                                                     read_union_data=self.r_u_data,
                                                                     write_union_data=self.w_u_data,)
                    # # convert dataclass->json
                    self._publishToBroker(mqtt_client=self.mqtt_main_client,
                                          mqtt_data=self.mqtt_tcp_data,
                                          topic_name=self.pub_main_topic,
                                          )
                #####################################################################
                #####################################################################
                # NOTE:Publish処理 Uploader(MAIN -> MQTT)
                #####################################################################

                # inspectionステータスでphase=6(検査完了)の時にデータをアップロード
                if self.checkPhase(key="n_inspection", val=7):
                    # データアップロードフラグをON
                    self.mqtt_upload_data.upload.flag = True
                    # アップロードデータを作成
                    self.makeVisionDataForDB()
                    # Publish to MQTTBroker
                    self._publishToBroker(mqtt_client=self.mqtt_uploader_client,
                                          mqtt_data=self.mqtt_upload_data,
                                          topic_name=self.pub_uploader_topic,
                                          )
                else:
                    # データアップロードフラグをOFF
                    self.mqtt_upload_data.upload.flag = False
                    # Publish to MQTTBroker
                    self._publishToBroker(mqtt_client=self.mqtt_uploader_client,
                                          mqtt_data=self.mqtt_upload_data,
                                          topic_name=self.pub_uploader_topic,
                                          )

                #####################################################################
                # NOTE:MQTT生存通知
                self.mqtt_observer_data = self.mqttHeartBeat(mqtt_data=self.mqtt_observer_data)
                #####################################################################
                # NOTE:Publish処理 Observer(MAIN -> MQTT)
                #####################################################################
                if self.bflag != self.previous_bflag:
                    # Publish to MQTTBroker
                    self._publishToBroker(mqtt_client=self.mqtt_observer_client,
                                          mqtt_data=self.mqtt_observer_data,
                                          topic_name=self.pub_observer_topic,
                                          )
                #####################################################################
                # ステータスの更新確認
                if self.prev_status != self.getStatus() or self.prev_phase != self.getPhase():
                    self.prev_status = self.getStatus()  # prev_status更新
                    self.prev_phase = self.getPhase()  # prev_phase更新
                    print("status:[ " + str(self.getStatus()) + " ]"
                          + "Phase:" + "INSPECTION:[ " + str(self.getPhase()) + " ]")

                if self.param.isDubugMode == "True":
                    # PLCデータの更新確認
                    is_r_change, is_w_change = self.compareDoubleLists(self.r_u_data,
                                                                       self.prev_r_u_data,
                                                                       self.w_u_data,
                                                                       self.prev_w_u_data,)

                    if is_r_change:
                        if self.param.isPlcProcess == "True":
                            print("read", self.mqtt_plc_data.comm_data.read)
                        else:
                            print("read", self.mqtt_tcp_data.comm_data.read)

                    if is_w_change:
                        if self.param.isPlcProcess == "True":
                            print("write", self.mqtt_plc_data.comm_data.write)
                        else:
                            print("write", self.mqtt_tcp_data.comm_data.write)

                # NOTE:前周期の値を保持
                self.savePreviousPlcData()
                self.saveFlagAsPreviousFlag(flag=self.bflag)

                if cnt > 100:
                    # s = "program freq {}ms".format(round((time.perf_counter() - t1) * 1000, 6))
                    # print(s)
                    # print("status:[ " + str(self.getStatus()) + " ]" +
                    #       "Phase:" + "INSPECTION:[ " + str(self.getPhase()) + " ]")
                    # print("write", self.mqtt_data.comm_data.write)
                    cnt = 0
                else:
                    cnt += 1

            except Exception as e:
                myException(e)


if __name__ == "__main__":
    main_seq = MainController()     # メインシーケンスクラスの初期化
    main_seq.main()                 # メイン制御スタート
