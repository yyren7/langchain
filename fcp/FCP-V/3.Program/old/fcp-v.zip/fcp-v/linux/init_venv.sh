#!/bin/bash

echo "Move to Current Dir..."
cd "$(dirname "$0")"

cd src

echo "Make an env folder..."
mkdir env

echo "Make a virtual environment..."
cd env
python -m venv .venv

echo "Activate a virtual environment..."
source .venv/bin/activate

echo "Move to Current Dir..."
cd "$(dirname "$0")"
cd src

echo "Install Libraries..."
pip install -r requirements.txt

read -p "Press Enter to continue..."