from logging import (getLogger,
                     handlers,
                     StreamHandler,
                     Formatter,
                     # config
                     )
from logging import (DEBUG,
                     INFO,
                     WARNING,
                     ERROR,
                     CRITICAL,
                     NOTSET
                     )


def setup_logger(modname: str,
                 log_dir: str = 'log',
                 filename: str = 'log',
                 level: str = 'DEBUG',
                 htype: str = 'STREAM'):

    # choose log level
    if level == 'DEBUG':
        log_level = DEBUG
    elif level == 'INFO':
        log_level = INFO
    elif level == 'WARNING':
        log_level = WARNING
    elif level == 'ERROR':
        log_level = ERROR
    elif level == 'CRITICAL':
        log_level = CRITICAL
    else:
        log_level = NOTSET

    file_path = f'{log_dir}/{filename}.log'

    # logging.basicConfig(filename=file_path, level=log_level)
    logger = getLogger(modname)
    logger.setLevel(log_level)

    # NOTE: loggerのフォーマット
    handler_format = Formatter(
        '%(asctime)s - %(name)s - %(funcName)s - %(levelname)s - %(message)s')
    # handler_format = Formatter('%(message)s')

    if htype == 'STREAM':
        hdl = StreamHandler()
        hdl.setFormatter(handler_format)
        hdl.setLevel(log_level)

    elif htype == 'FILE':
        hdl = handlers.TimedRotatingFileHandler(
            file_path, encoding='utf-8',
            when='MIDNIGHT',
            backupCount=3,
        )
        hdl.setFormatter(handler_format)
        hdl.setLevel(log_level)

    else:
        hdl = handlers.RotatingFileHandler(file_path,
                                           maxBytes=5000,
                                           backupCount=10)
        hdl.setFormatter(handler_format)
        hdl.setLevel(log_level)

    logger.addHandler(hdl)
    logger.propagate = False

    return logger
