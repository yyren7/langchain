# ===============================================================================
# Name      : pyqtgraph_view.py
# Version   : 1.0.0
# Brief     :
# Time-stamp: 2023-06-27 13:43
# Copyirght 2022 Hiroya Aoyama
# ===============================================================================

import pyqtgraph as pg
import numpy as np
import copy
import cv2
from typing import Union, Tuple, Optional


class CustomViewBox(pg.ViewBox):
    """
    ViewBoxのカスタム継承クラス

    Args:
        pg (_type_): _description_
    """

    def __init__(self, parent=None):
        super(CustomViewBox, self).__init__(parent)
        # NOTE: アスペクト比を固定
        self.setAspectLocked()
        # NOTE: 描画するアイテムを管理
        self.img = np.zeros((640, 480, 3), dtype=np.uint8)
        self.img_item = pg.ImageItem(image=self.img)
        self.addItem(self.img_item)
        self.default_state = self.getState()
        # NOTE: roiのみひとつのviewboxに複数描画する可能性がある
        self.rois = []

    def set_image(self, img: np.ndarray) -> None:
        """画像を貼り付け

        Args:
            img (_type_): _description_

        Returns:
            _type_: _description_
        """
        # NOTE: setConfigOptionsか、dtypeのせいで方向がおかしい気がする
        img = np.rot90(img, 2)
        img = cv2.flip(img, 1)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        self.img = img.copy()
        # NOTE: レベルを手動調整
        self.img_item.setImage(image=self.img, autoLevels=False)
        # self.img_item.setLevels([np.min(self.img), np.max(self.img)])
        self.img_item.setLevels([0, 255])
        self.default_state = self.getState()
        # NOTE: 画像全体が収まるように自動調整
        self.autoRange()

    def set_frame(self, img: np.ndarray) -> None:
        """ストリーミングの貼り付け

        Args:
            img (_type_): _description_

        Returns:
            _type_: _description_
        """
        # NOTE: setConfigOptionsか、dtypeのせいで方向がおかしい気がする
        img = np.rot90(img, 2)
        img = cv2.flip(img, 1)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        self.img = img.copy()
        # NOTE: レベルを手動調整
        self.img_item.setImage(image=self.img, autoLevels=False)
        self.img_item.setLevels([0, 255])
        self.default_state = self.getState()

    def reset_vb(self) -> None:
        """vbの状態を画像を貼り付けた初めの状態にリセット"""
        self.setState(copy.deepcopy(self.default_state))

    def get_roi_cvimg(self, roi: pg.ROI):
        success = True
        try:
            img_float64 = self.rois[0].getArrayRegion(self.img.copy(), self.img_item)
            img = img_float64.astype(np.uint8)
            img = np.rot90(img, 2)
            img = cv2.flip(img, 1)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        except Exception as e:
            print(e)
            img = -1
            success = False

        return success, img

    def add_roi(self, roi: pg.ROI) -> None:
        """_summary_

        Args:
            roi (pg.ROI): _description_
        """
        self.addItem(roi)
        self.rois.append(roi)

    def reset_roi(self, img: np.ndarray) -> None:
        """
        Args:
            img (np.ndarray): _description_
        """
        self.clear()
        img = np.rot90(img, 2)
        img = cv2.flip(img, 1)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        self.img_item = pg.ImageItem(image=img)
        self.addItem(self.img_item)

    def get_pt_rgb(self, src: np.ndarray, pt: tuple) -> Tuple[int, int, int]:
        """RGBの成分を返す"""
        h, w = src.shape[:2]
        if pt[0] < 0 or pt[0] > w - 1:
            return -1, -1, -1
        if pt[1] < 0 or pt[1] > h - 1:
            return -1, -1, -1
        b, g, r = src[pt[1], pt[0], :]
        return b, g, r

    def get_pt_gray(self, src: np.ndarray, pt: tuple) -> Tuple[int, int, int]:
        """RGBの成分を返す"""
        h, w = src.shape[:2]
        if pt[0] < 0 or pt[0] > w - 1:
            return -1, -1, -1
        if pt[1] < 0 or pt[1] > h - 1:
            return -1, -1, -1
        val = src[pt[1], pt[0]]
        return val, val, val

    @staticmethod
    def cv2pg(roi: Union[list, np.ndarray], img: np.ndarray) -> Tuple[list, list]:
        """ [xmin, ymin, xmax, ymax]をpyqtgraph座標の[x, y] [l_x, l_y]に変換"""
        h, _ = img.shape[:2]
        x = roi[0]
        l_x = roi[2] - roi[0]
        l_y = roi[3] - roi[1]
        y = h - roi[3]  # NOTE: yは正負逆
        return [x, y], [l_x, l_y]

    @staticmethod
    def _cv2pg(roi: Union[list, np.ndarray], h: int) -> Tuple[list, list]:
        x = roi[0]
        l_x = roi[2] - roi[0]
        l_y = roi[3] - roi[1]
        y = h - roi[3]
        return [x, y], [l_x, l_y]

    @staticmethod
    def pg2cv(pos: pg.Point, len: pg.Point, img: np.ndarray) -> list:
        h, _ = img.shape[:2]
        xmin = int(pos[0])
        xmax = int(pos[0] + len[0])
        ymin = int(h - (pos[1] + len[1]))
        ymax = int(h - pos[1])

        return [xmin, ymin, xmax, ymax]

    @staticmethod
    def _pg2cv(pos: pg.Point, len: pg.Point, h: int) -> list:
        xmin = int(pos[0])
        xmax = int(pos[0] + len[0])
        ymin = int(h - (pos[1] + len[1]))
        ymax = int(h - pos[1])

        return [xmin, ymin, xmax, ymax]

    @staticmethod
    def xyr2pg(xyr: Union[list, np.ndarray], img: np.ndarray) -> Tuple[list, list]:
        h, _ = img.shape[:2]
        x = xyr[0] - xyr[2]
        l_x = int(xyr[2] * 2)
        l_y = int(xyr[2] * 2)
        y = h - (xyr[1] + xyr[2])

        return [x, y], [l_x, l_y]

    @staticmethod
    def pg2xyr(pos: pg.Point, len: pg.Point, img: np.ndarray) -> list:
        h, _ = img.shape[:2]
        r = int(len[0] / 2)
        x = int(pos[0] + len[0] / 2)
        y_inv = int(pos[1] + len[1] / 2)
        y = h - y_inv

        return [x, y, r]


class ViewWidget(pg.GraphicsLayoutWidget):
    pg.setConfigOptions(imageAxisOrder='row-major')

    def __init__(self):
        super(ViewWidget, self).__init__()
        self.box_layout = self.addLayout(row=0, col=0)
        self.box_layout.setContentsMargins(0, 0, 0, 0)
        self.box_layout.setBorder((255, 255, 255, 255), width=0.8)
        self.viewboxs = []
        self.default_state = []
        self.img_items = []
        self.imgs = []

    def add_viewbox(self, img: Optional[np.ndarray] = None,
                    row: int = 0, col: int = 0,
                    rowspan: int = 1, colspan: int = 1
                    ) -> CustomViewBox:
        """GraphicsLayoutWidgetにViewBoxとImageItemを追加"""
        # NOTE: ViewBoxを追加
        vb = CustomViewBox()
        self.box_layout.addItem(vb, row=row, col=col, rowspan=rowspan, colspan=colspan)
        # NOTE: 画像を加工して追加
        if img is None:
            img = np.zeros((640, 480, 3), dtype=np.uint8)
        vb.set_image(img)
        return vb
