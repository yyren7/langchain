# ===============================================================================
# Name      : utils_dialog.py
# Version   : 1.0.0
# Brief     :
# Time-stamp: 2023-03-20 14:53
# Copyirght 2021 Hiroya Aoyama
# ===============================================================================
from ..dialog.response import (
    SuccessResponse,
    FailedResponse,
    ErrorResponse,
    NoticeResponse,
    DialogResponse,
    ShowRoi
)
from ..dialog.software_keyboard import (
    KeyBoard,
    NumPad
)

from typing import Any


def show_response(res: bool = True) -> None:
    if res:
        dlg = SuccessResponse()
        dlg.setWindowTitle("Success")
    else:
        dlg = FailedResponse()
        dlg.setWindowTitle("Failed")
    dlg.exec_()


def show_error(message: str) -> None:
    dlg = ErrorResponse(message=message)
    dlg.setWindowTitle("Error")
    dlg.exec_()


def show_notice(message: str) -> None:
    dlg = NoticeResponse(message=message)
    dlg.setWindowTitle("Notice")
    dlg.exec_()


def show_dialog(text: str) -> bool:
    dlg = DialogResponse(text=text)
    dlg.setWindowTitle("Notice")
    dlg.exec_()
    if dlg.is_enabled():
        return True
    else:
        return False


def open_numpad(widget: Any, numType: str) -> None:
    dlg = NumPad(widget=widget, numType=numType)
    dlg.setWindowTitle("NUMPAD")
    dlg.exec_()


def open_keyboard(widget: Any) -> str:
    if widget is None:
        # NOTE: パスワード入力
        dlg = KeyBoard(widget=None)
        dlg.exec_()
        input_word = dlg.get_input_word()
        return input_word

    else:
        # NOTE: LineEditに転記
        dlg = KeyBoard(widget=widget)
        dlg.setWindowTitle("KEYBOARD")
        dlg.exec_()
        return ""


def show_roi(image: Any, *, thickness: int = -1, title: str = 'Result') -> None:
    dlg = ShowRoi(img=image)
    if thickness > 0:
        dlg.scene.set_thickness(thickness)
    dlg.setWindowTitle(title)
    dlg.exec_()
