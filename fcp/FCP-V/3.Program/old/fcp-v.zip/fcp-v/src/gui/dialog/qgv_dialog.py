# ===============================================================================
# Name      : area_selector.py
# Version   : 1.0.0
# Brief     :
# Time-stamp: 2023-02-13 20:31
# Copyirght 2021 Hiroya Aoyama
# ===============================================================================
import os
import sys
import numpy as np
import cv2
import copy

# from typing import Tuple
from PySide2 import QtWidgets  # , QtCore, QtGui
from PySide2.QtUiTools import QUiLoader

from .graphics_dialog import GraphicsRectangleDialog, GraphicsPolygonDialog
from ..pyside_lib import crop_roi

try:
    from logger import setup_logger
    logger = setup_logger(__name__)
except Exception:
    from logging import getLogger
    logger = getLogger(__name__)

from .ui_path import (
    GET_AREA_UI,
    CREATE_ROI_UI,
    CREATE_MASK_UI
)


class AreaSelector(GraphicsRectangleDialog):
    def __init__(self, img: np.ndarray, *, rect: list = [], title: str = 'Dialog'):
        """ROIを設定するダイアログ

        Args:
            img (np.ndarray): _description_
            roi_pos (list, optional): _description_. Defaults to [].
            title (str, optional): _description_. Defaults to ''.
        """
        ui = QUiLoader().load(GET_AREA_UI)
        super().__init__(ui=ui, image=img,
                         view_widget=ui.graphicsView)

        # NOTE: 内部管理
        self._roi_image = np.array([0])
        self._roi_position = [0, 0, 0, 0]

        self.connect_function()
        self.set_dialog(rect, title)

    def set_dialog(self, rect: list, title: str) -> None:
        """ダイアログの表示処理

        Args:
            rect (list): _description_
            title (str): _description_
        """
        self.ui.setWindowTitle(title)
        self.ui.setModal(True)
        self.ui.show()
        # NOTE: showの後に呼び出し(widgetの大きさを正確に取得するため)
        self.zoom_out()
        self.load_rect(rect)

    def connect_function(self):
        # widgets connect
        self.ui.applyButton.clicked.connect(lambda: self.apply())
        self.ui.exitButton.clicked.connect(lambda: self.ui.reject())
        self.ui.zoomIn.clicked.connect(lambda: self.zoom_in())
        self.ui.zoomOut.clicked.connect(lambda: self.zoom_out())

    def apply(self):
        # NOTE: 座標取得
        ret, rect = self._get_rectangle()
        if not ret:
            self._show_error('ROI is not set')
            return

        roi = crop_roi(self.image, rect)
        self._roi_image = roi.copy()
        self._roi_position = copy.copy(rect)
        self._applied = True
        self.ui.accept()

    def get_roi(self) -> np.ndarray:
        return self._roi_image

    def get_roi_position(self) -> list:
        return self._roi_position


class CreateRoi(GraphicsRectangleDialog):
    def __init__(self, img: np.ndarray, *, rect: list = [], title: str = 'Dialog'):
        """テンプレートを登録するダイアログ

        Args:
            img (np.ndarray): _description_
            roi_pos (list, optional): _description_. Defaults to [].
            title (str, optional): _description_. Defaults to 'Dialog'.
        """

        ui = QUiLoader().load(CREATE_ROI_UI)
        super().__init__(ui=ui, image=img,
                         view_widget=ui.graphicsView)

        # NOTE: 内部管理
        self._roi_image = np.array([0])
        self._roi_position = [0, 0, 0, 0]

        self.connect_function()
        self.set_dialog(rect, title)

    def set_dialog(self, rect: list, title: str) -> None:
        """ダイアログの表示処理

        Args:
            rect (list): _description_
            title (str): _description_
        """
        self.ui.setWindowTitle(title)
        self.ui.setModal(True)
        self.ui.show()
        # NOTE: showの後に呼び出し(widgetの大きさを正確に取得するため)
        self.zoom_out()
        self.load_rect(rect)

    def connect_function(self):
        # widgets connect
        self.ui.applyButton.clicked.connect(lambda: self.apply())
        self.ui.exitButton.clicked.connect(lambda: self.ui.reject())
        self.ui.zoomIn.clicked.connect(lambda: self.zoom_in())
        self.ui.zoomOut.clicked.connect(lambda: self.zoom_out())
        # numpad
        # self.ui.tool_angle_min.clicked.connect(lambda: self._open_numpad(widget=self.ui.minAngle, num_type='str'))
        # self.ui.tool_angle_max.clicked.connect(lambda: self._open_numpad(widget=self.ui.maxAngle, num_type='str'))
        # self.ui.tool_angle_step.clicked.connect(lambda: self._open_numpad(widget=self.ui.stepAngle, num_type='str'))
        self.ui.switcher.clicked.connect(lambda: self.show_roi())

    def apply(self):
        # NOTE: 座標取得
        ret, rect = self._get_rectangle()
        if not ret:
            self._show_error('roi not set')
            return

        roi = crop_roi(self.image, rect)
        self._roi_image = roi.copy()
        self._roi_position = copy.copy(rect)
        self._applied = True
        self.ui.accept()

    def show_roi(self):
        r = self.scene.get_rect_data()
        if r is None:
            self._show_error('no image')
            return
        roi = crop_roi(self.image, r)
        self._show_img(roi)

    def get_roi(self) -> np.ndarray:
        return self._roi_image

    def get_roi_position(self) -> list:
        return self._roi_position

    # def get_config(self) -> dict:
    #     ret_data = self.call_parameter()
    #     ret_data["roi_data"] = self.roi_data
    #     return ret_data

    # def call_parameter(self):
    #     use_templ = self.ui.checkBox.isChecked()
    #     try:
    #         angle_option = dict(
    #             min=float(self.ui.angle_min.text()),
    #             max=float(self.ui.angle_max.text()),
    #             step=float(self.ui.angle_step.text())
    #         )
    #     except ValueError:
    #         self._show_error('invalid literal')
    #         angle_option = dict(min=0.0, max=0.0, step=0.0)
    #     except Exception:
    #         self._show_error('invalid literal')
    #         angle_option = dict(min=0.0, max=0.0, step=0.0)

    #     return dict(angle_option=angle_option,
    #                 use_templ=use_templ)


class CreateMask(GraphicsPolygonDialog):
    def __init__(self, img: np.ndarray, *, polygons: list = [], title: str = 'Mask Setting'):

        ui = QUiLoader().load(CREATE_MASK_UI)
        super().__init__(ui=ui, image=img,
                         view_widget=ui.graphicsView,
                         combo_widget=ui.comboBox)

        # NOTE: 内部管理
        self._mask_image = np.array([0])
        self._polygons = []
        self._disp = 0

        self.connect_function()
        self.set_dialog(polygons, title)

    def set_dialog(self, polygons: list, title: str) -> None:
        """ダイアログの表示処理

        Args:
            polygons (list): _description_
            title (str): _description_
        """
        self.ui.setWindowTitle(title)
        self.ui.setModal(True)
        self.ui.show()
        # NOTE: showの後に呼び出し(widgetの大きさを正確に取得するため)
        self.zoom_out()
        self.load_polygon(polygons)

    def connect_function(self) -> None:
        # widgets connect
        self.ui.applyButton.clicked.connect(lambda: self.create_mask_image())
        self.ui.exitButton.clicked.connect(lambda: self.ui.reject())
        self.ui.addButton.clicked.connect(lambda: self.add_polygon())
        self.ui.delButton.clicked.connect(lambda: self.del_polygon())
        self.ui.switcher.clicked.connect(lambda: self.show_mask_image())
        self.ui.comboBox.currentIndexChanged.connect(lambda: self.set_polygon())
        self.ui.zoomIn.clicked.connect(lambda: self.zoom_in())
        self.ui.zoomOut.clicked.connect(lambda: self.zoom_out())

    def create_mask_image(self) -> None:
        mask_img = np.zeros((self.h, self.w, 3), np.uint8)
        for polygon in self._polygons:
            # NOTE: 入力はnp
            mask_img = cv2.fillPoly(mask_img, [np.array(polygon)], color=(255, 255, 255))
        self._mask_image = mask_img.copy()
        self._applied = True
        self.ui.accept()

    def show_mask_image(self) -> None:
        mask_img = np.zeros((self.h, self.w, 3), np.uint8)
        img = self.image.copy()
        for polygon in self._polygons:
            mask_img = cv2.fillPoly(mask_img, [np.array(polygon)], color=(255, 255, 255))
        masked_img = cv2.bitwise_and(img, mask_img)
        self._show_img(masked_img)

    def get_mask_image(self) -> np.ndarray:
        return self._mask_image

    def get_polygons(self) -> list:
        return self._polygons


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
