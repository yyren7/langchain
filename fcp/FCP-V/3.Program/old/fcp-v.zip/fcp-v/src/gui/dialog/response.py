# ===============================================================================
# Name      : response.py
# Version   : 1.0.0
# Brief     :
# Time-stamp: 2023-03-20 14:52
# Copyirght 2021 Hiroya Aoyama
# ===============================================================================
import os
import numpy as np
from PySide2 import QtWidgets, QtCore  # , QtGui
from ..graphics.qgv_rect import GraphicsRectangle
from ..pyside_lib import paste_image_on_qgv, crop_roi
from ..pyside_css import pyside_dialog_css
from ..pyside_dynamic import loadUi
from .ui_path import (
    SUCCESS_UI,
    FAILED_UI,
    ERROR_UI,
    DIALOG_UI,
    ROI_UI,
    NOTICE_UI
)


class SuccessResponse(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        loadUi(SUCCESS_UI, self)
        self.pushButton.clicked.connect(lambda: self.accept())
        self.setStyleSheet(pyside_dialog_css())


class FailedResponse(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        loadUi(FAILED_UI, self)
        self.pushButton.clicked.connect(lambda: self.accept())
        self.setStyleSheet(pyside_dialog_css())


class ErrorResponse(QtWidgets.QDialog):
    def __init__(self, message: str):
        super().__init__()
        loadUi(ERROR_UI, self)
        self.textEdit.setText(message)
        self.pushButton.clicked.connect(lambda: self.accept())
        self.setStyleSheet(pyside_dialog_css())


class NoticeResponse(QtWidgets.QDialog):
    def __init__(self, message: str):
        super().__init__()
        loadUi(NOTICE_UI, self)
        self.textEdit.setText(message)
        self.pushButton.clicked.connect(lambda: self.accept())
        self.setStyleSheet(pyside_dialog_css())


class DialogResponse(QtWidgets.QDialog):
    def __init__(self, text=None):
        super().__init__()
        loadUi(DIALOG_UI, self)
        if text is not None:
            self.label.setText(text)
        self._applied = False
        self.setStyleSheet(pyside_dialog_css())
        self.connect_function()

    def connect_function(self):
        self.okButton.clicked.connect(lambda: self._apply())
        self.ngButton.clicked.connect(lambda: self.accept())

    def _apply(self):
        self._applied = True
        self.accept()

    def is_enabled(self):
        return self._applied


class TEMP(GraphicsRectangle):
    def __init__(self):
        super().__init__()

    def focusInEvent(self, event: QtWidgets.QGraphicsSceneResizeEvent) -> None:
        if self.view_widget is not None:
            self.view_widget.fitInView(self.sceneRect(), QtCore.Qt.KeepAspectRatio)


class ShowRoi(QtWidgets.QDialog):
    def __init__(self, img: np.ndarray):
        super().__init__()
        loadUi(ROI_UI, self)
        h, w = img.shape[:2]
        self._img = img.copy()
        self._set_graphics_view(widget=self.graphicsView, w=w, h=h)
        self._connect_function()
        paste_image_on_qgv(self.scene, img)

    def _set_graphics_view(self, widget: QtWidgets.QGraphicsView, w: int, h: int):
        self.scene = TEMP()
        self.scene.set_view_widget(widget)
        widget.setScene(self.scene)
        self.scene.setSceneRect(0, 0, w, h)

    def _connect_function(self):
        self.zoomInButton.clicked.connect(lambda: self.zoom_in())
        self.zoomOutButton.clicked.connect(lambda: self.zoom_out())
        self.exitButton.clicked.connect(lambda: self.accept())

    def zoom_in(self):
        rect = self.scene.get_rect_data()
        self.scene.clear_shape_item()
        # rect = self.scene.get_rect_data()
        try:
            img = crop_roi(self._img, rect)  # type: ignore
            h, w = img.shape[:2]
            self._set_graphics_view(widget=self.graphicsView, w=w, h=h)
            paste_image_on_qgv(self.scene, img)
            self.scene.fit_in_view(w, h)
        except Exception as e:
            print(e)
            self.zoom_out()

    def zoom_out(self):
        h, w = self._img.shape[:2]
        self._set_graphics_view(widget=self.graphicsView, w=w, h=h)
        paste_image_on_qgv(self.scene, self._img)
        self.scene.fit_in_view(w, h)
