import cv2
import numpy as np


class FocusAssistant():
    def __init__(self):
        # NOTE: protected
        self.focus_max: int = 0
        self.focus_score_list: list = []
        self.x_grid: list = []
        self.frame_count: int = 0

        self.DATA_MAX_LENGTH = 300
        self.SETUP_FRAME = 100

    def _crop_roi(self, src: np.ndarray, box: list):
        return src[box[0]:box[2], box[1]:box[3]]

    def initilize(self):
        self.frame_count = 0
        self.focus_max = 0
        self.focus_score_list = []
        self.x_grid = []

    def analys_score(self, src: np.ndarray, roi_data: list):
        # height, width = src.shape[:2]
        # if roi_data is None:
        #     roi = src[int(height * 0.25):int(height * 0.75),
        #               int(width * 0.25):int(width * 0.75)]
        # else:
        roi = self._crop_roi(src, roi_data)

        focus_score = self.calc_score(roi)

        if self.focus_max < focus_score:
            self.focus_max = focus_score

        self.focus_score_list.append(focus_score)
        self.x_grid.append(self.frame_count)

        self.frame_count += 1

        # NOTE: countが16bit超えたら初期化
        if self.frame_count > 65535:
            list_size = len(self.x_grid)
            self.x_grid = [val for val in range(list_size)]
            self.frame_count = list_size

        # NOTE: 配列長を制限
        while len(self.focus_score_list) > self.DATA_MAX_LENGTH:
            del self.focus_score_list[0]
            del self.x_grid[0]

        # NOTE: スコア100%換算
        focus_score_per_list = list(map(lambda y: y / self.focus_max * 100, self.focus_score_list))

        return self.x_grid, focus_score_per_list

    def return_score_result(self, latest_score):
        if self.frame_count < self.SETUP_FRAME:
            result = 'SETUP'
        else:
            if latest_score >= 90:
                result = 'OK'
            else:
                result = 'NG'
        return result

    @staticmethod
    def calc_score(src: np.ndarray):
        gray = cv2.cvtColor(src, cv2.COLOR_BGR2GRAY)
        focus_score = cv2.Laplacian(gray, cv2.CV_64F).var()
        return focus_score

    @staticmethod
    def show_focus_assist_message(flag: str, src: np.ndarray):
        h, w = src.shape[:2]
        SIZE = 0.8 * (w / 640)
        MARGIN = int(h / 8)

        POS = (int(2 * w / 9), int(2 * h / 5) + MARGIN)
        color = (0, 0, 0)

        text = ''

        if flag == 'OK':
            text = "Same as the peak score"
            color = (0, 255, 0)  # NOTE: 色も変化
        elif flag == 'NG':
            text = "Please move the focus"
        elif flag == 'SETUP':
            text = "Please move the focus"

        cv2.putText(src, text,
                    POS,
                    cv2.FONT_HERSHEY_COMPLEX,
                    SIZE,
                    color, lineType=cv2.LINE_AA)

        return src
