import logging
from PySide2 import QtCore, QtWidgets

__version__ = "1.0"


# logの追加をQtのsignalに
class Signaller(QtCore.QObject):
    signal = QtCore.Signal(str, logging.LogRecord)


# loggerに追加するQPlainTextEdit用のハンドラ
class QtHandler(logging.Handler):
    # QPlainTextEditに表示する際の文字色。
    # QPlainTextEditの背景色は黒を想定しているので、INFOが白色
    LOG_COLORS = {
        logging.DEBUG: 'aqua',
        logging.INFO: 'white',
        logging.WARNING: 'yellow',
        logging.ERROR: 'red',
        logging.CRITICAL: 'magenta',
    }

    def __init__(self, plaintextedit: QtWidgets.QPlainTextEdit):
        # 引数は基本的にはplaintexteditのみ。
        # uiのplaintexteditオブジェクトを渡すだけ。
        super().__init__()
        self.signaller = Signaller()
        # Signallerでキャッチしたlogging.LogRecordをupdate_statusに繋げる。
        self.signaller.signal.connect(self.update_status)
        self.plaintextedit = plaintextedit
        # NOTE: stylesheetを追加
        self.plaintextedit.setReadOnly(True)
        self.plaintextedit.setStyleSheet('background-color: #000000;')

    def emit(self, record: logging.LogRecord):
        s = self.format(record)
        self.signaller.signal.emit(s, record)

    @QtCore.Slot(str, logging.LogRecord)  # type:ignore
    def update_status(self, status: str, record: logging.LogRecord):
        # plaintexteditにhtmlを追加する形式で表示する。
        # QTextEditはhtmlが追加できないので"QPlainTextEdit"が必要。
        color = self.LOG_COLORS.get(record.levelno, 'black')
        s = '<pre><font color="%s">%s</font></pre>' % (color, status)
        self.plaintextedit.appendHtml(s)
