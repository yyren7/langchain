# -*- coding : UTF-8 -*-
# ===============================================================================
# Name      : tcp_connection_class.py
# Version   : 1.0.0
# Brief     : tcp_connection_class
# Time-stamp:2024-02-28 12:45
# Copyirght 2024 Tatsuya Sugino
# ===============================================================================
import socket
import threading
from socket import socket, AF_INET, SOCK_STREAM, SOCK_DGRAM, IPPROTO_TCP, TCP_NODELAY, SOL_SOCKET, SO_SNDBUF, SO_RCVBUF
import select
import time
import re


class TCPServer:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.server_socket = socket(AF_INET, SOCK_STREAM)
        self.clients = []  # 接続されたクライアントを格納するリスト
        self.lock = threading.Lock()
        self.buffer_size = 2048

    def _open(self):
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(5)
        print(f"Server listening on {self.host}:{self.port}")
        try:
            while True:
                self.client_socket, self.addr = self.server_socket.accept()
                print(f"Accepted connection from :{self.addr}")
                with self.lock:
                    self.clients.append(self.client_socket)
                    break
        except KeyboardInterrupt:
            print("Server shutting down.")

    def recvFromClient(self):
        timeout = 0.01
        try:
            ready, _, _ = select.select([self.client_socket], [], [], timeout)
            if ready:
                data = self.client_socket.recv(self.buffer_size)
                if not data:
                    return None
                message = data.decode("utf-8")
                # メッセージを処理したり、他のクライアントに送信したりできます
                return message

        except Exception as e:
            print(f"Error handling client: {e}")
            return None

    def send_to_all_clients(self, message):
        with self.lock:
            try:
                for client_socket in self.clients:
                    client_socket.sendall(message.encode("utf-8"))
            except Exception as e:
                print(f"Error sending message to client: {e}")


class TCPClient:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.client_socket = socket(AF_INET, SOCK_STREAM)
        self.buffer_size = 2048

    def _connect(self):
        try:
            self.client_socket.connect((self.host, self.port))
            print(f"Connected to server at {self.host}:{self.port}")

        except Exception as e:
            print(f"Error connecting to server: {e}")

    def send_message(self, message):
        try:
            self.client_socket.sendall(message.encode("utf-8"))
        except Exception as e:
            print(f"Error sending message to server: {e}")

    def recvFromServer(self):
        timeout = 0.01
        try:
            ready, _, _ = select.select([self.client_socket], [], [], timeout)
            if ready:
                data = self.client_socket.recv(self.buffer_size)
                if not data:
                    return None
                message = data.decode("utf-8")
                # メッセージを処理したり、他のクライアントに送信したりできます
                return message

        except Exception as e:
            print(f"Error handling client: {e}")
            return None


# ===============================================================================
# NOTE: TCP文字列変換用
# ===============================================================================
def split_message(message, crlf: str = "\r\n|,"):
    # 正規表現を用いてカンマで分割
    result = re.split(crlf, message)
    # 余分な空白や改行を取り除く
    result = [item.strip() for item in result]
    return result


if __name__ == "__main__":
    ########################################
    # サーバテスト
    ########################################
    # src_ip = "127.0.0.1"
    # src_port = 4001
    # server = TCPServer(src_ip, src_port)
    # server._open()

    # try:
    #     while True:
    #         time.sleep(0.5)
    #         # READ
    #         recv_message = server.recvFromClient()
    #         print(f"recv:{recv_message}")

    #         header, prg, cfg, mdl, pos, _ = split_message(recv_message)
    #         print(f"split:Header={header},program={prg},config={cfg},model={mdl},position={pos},CRLF={_}")
    #         # 受信メッセージがあれば
    #         if recv_message is not None:
    #             send_message = f"got a {recv_message}"
    #             print(f"send:{send_message}")
    #             # WRITE
    #             server.send_to_all_clients(send_message)
    #         else:
    #             print("ToKill")
    #             break

    # except KeyboardInterrupt:
    #     print("ToEnd.")
    # finally:
    #     with server.lock:
    #         server.clients.remove(server.client_socket)
    #         server.server_socket.close()
    #         server.client_socket.close()
    #         print("Connection closed")

    ########################################
    # クライアントテスト
    ########################################
    server_host = "127.0.0.1"
    server_port = 4001

    # Connect the client to the server
    client = TCPClient(server_host, server_port)
    client._connect()
    try:
        while True:
            time.sleep(0.5)
            send_message = input("Enter message to send (or 'exit' to quit): ")
            if send_message.lower() == 'exit':
                break
            # WRITE
            client.send_message(send_message)
            while True:  # 受信ループ
                time.sleep(0.5)
                print("Waiting a message")
                # READ
                recv_message = client.recvFromServer()
                # 受信メッセージがあれば
                if recv_message is not None:
                    recv_message = f"got a [{recv_message}]"
                    print(f"recv:{recv_message}")
                    break

    except KeyboardInterrupt:
        print("ToEnd.")
    finally:
        client.client_socket.close()
        print("Connection closed")
