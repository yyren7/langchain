# ===============================================================================
# Name      : param_basemodel.py
# Version   : 1.0.0
# Brief     : 設定管理用のベースモデル
# Time-stamp: 2023-07-10 16:15
# Copyirght 2023 Hiroya Aoyama
# ===============================================================================
from pydantic import BaseModel, validator, Field
from typing import List
import numpy as np


class CustomBaseModel(BaseModel):
    class Config:
        arbitrary_types_allowed = True


class TemplateArrayModel(CustomBaseModel):
    array_: np.ndarray = Field(default_factory=lambda: np.zeros((10, 10), dtype=np.uint8))


# ===============================================================================
# NOTE: 画像処理関連
# ===============================================================================
class ImagePoint(BaseModel):
    x: int = 0
    y: int = 0


class CircleData(BaseModel):
    """位置情報の基本データ"""
    x: int = 30
    y: int = 30
    r: int = 15


class BoxParam(BaseModel):
    height: int = 0
    width: int = 0


class RegionData(BaseModel):
    """ROIの設定データ"""
    enable_search_area: bool = False
    search_area: List[int] = []


class FilterConfig(BaseModel):
    filter_label: str = 'noise_smooth'
    k_size: int = 3  # NOTE: カーネルサイズ
    iteration: int = 1  # NOTE: 試行回数
    sigma: int = 1  # NOTE: sigma
    binary_thresh: int = 0  # NOTE: 二値化最小値
    binary_thresh2: int = 0  # NOTE: 二値化最大値
    thresh1: int = 0  # NOTE: 最小値
    thresh2: int = 0  # NOTE: 最大値
    bool_var: bool = False  # NOTE: Bool型の変数　汎用的に使うためこの命名


class PreProcList(BaseModel):
    use_proc: bool = False
    color_channel: str = 'gray'
    filter_list: List[FilterConfig] = []


class BlobDetectionParam(BaseModel):
    """ブロブ抽出の設定データ"""
    input_color: str = 'gray'
    binary_thresh: int = 0
    num_of_blob: int = 0
    min_blob_size: int = -1
    max_blob_size: int = -1
    circularity_thresh: float = -1.0
    negative: bool = False


class PickPointData(BaseModel):
    mode: str = 'Points'
    pick_point: ImagePoint = ImagePoint()
    points: List[ImagePoint] = [ImagePoint()]
    circles: List[CircleData] = [CircleData()]


class SearchAngleRange(BaseModel):
    min_angle: float = -5.0
    max_angle: float = 5.0
    step: float = 1.0


class MatchingParam(BaseModel):
    """テンプレートマッチングの設定データ
    今後はこれをベースに"""
    template_area: list = [0, 0, 10, 10]
    angle_range: List[SearchAngleRange] = [SearchAngleRange()]
    compression_ratio: float = 1.0
    use_mask: bool = False
    use_pick: bool = False
    use_chamfer: bool = False
    mask_polygon: List[List[List[int]]] = []
    pick_point: ImagePoint = ImagePoint()
    pick_point_conf: PickPointData = PickPointData()
    score_th: float = 0.0


class EdgeDetectionParam(BaseModel):
    """線検出の設定データ"""
    scan_direction: str = 'right'
    edge_type: str = 'positive'
    peak_position: str = 'maximum'
    num_point: int = 5
    width: int = 5
    enable_outlier_removal: bool = False
    # removal_rate: int = 10
    enable_subpixel: bool = True


class LineDetectionParam(BaseModel):
    """線検出のデータとROI"""
    param: List[EdgeDetectionParam] = []
    roi: List[List[int]] = []


class CornerDetectionParam(BaseModel):
    """4線検出"""
    left: LineDetectionParam = LineDetectionParam()
    right: LineDetectionParam = LineDetectionParam()
    top: LineDetectionParam = LineDetectionParam()
    bottom: LineDetectionParam = LineDetectionParam()


class ColorRangeParam(BaseModel):
    """色検出の設定データ"""
    mode: str = 'rgb'
    lower_value: List[int] = [0, 0, 0]
    upper_value: List[int] = [100, 100, 100]
    outside_region: List[bool] = [False, False, False]
    pixel_rate: int = 5

    @validator('mode')
    def check_mode(cls, v):
        if v not in ['rgb', 'hsv', 'lab']:
            raise ValueError('input_color option is wrong keyword.', v)
        return v


class ColorDetectionParam(BaseModel):
    regions: List[List[List[int]]] = []
    color_range: List[ColorRangeParam] = []


class CircleDetectionParam(BaseModel):
    """線検出の設定データ"""
    circle: CircleData = CircleData()
    edge_type: str = 'positive'
    peak_position: str = 'maximum'
    num_point: int = 5
    search_width: int = 5
    search_length: int = 20
    enable_outlier_removal: bool = False
    removal_rate: int = 95
    enable_subpixel: bool = False


class CornerPoint(BaseModel):
    """隅4点"""
    left_top: ImagePoint = ImagePoint()
    left_bottom: ImagePoint = ImagePoint()
    right_top: ImagePoint = ImagePoint()
    right_bottom: ImagePoint = ImagePoint()


class GridParam(BaseModel):
    """グリッド点数,マージン"""
    rows: int = 0
    columns: int = 0
    left_margin: int = 0
    right_margin: int = 0
    top_margin: int = 0
    bottom_margin: int = 0


class TrayDetectionParam(BaseModel):
    """トレイ上のワークの位置"""
    corner_point: CornerPoint = CornerPoint()
    grid_param: GridParam = GridParam()
    box_param: BoxParam = BoxParam()
    grid_points: List[List[int]] = []


class BoxesInfo(BaseModel):
    boxes: List[List[int]] = []
    score_thresh: float = 0.0
    iou_thresh: float = 0.0
    resize_scale: float = 0.0


class CountConf(BaseModel):
    angle0: BoxesInfo = BoxesInfo()
    # angle90: BoxesInfo = BoxesInfo()
    # angle180: BoxesInfo = BoxesInfo()
    # angle270: BoxesInfo = BoxesInfo()


class WorkPieceCountParam(BaseModel):
    count_conf: CountConf = CountConf()
    template_area: list = [0, 0, 10, 10]
    use_mask: bool = False
    mask_polygon: List[List[List[int]]] = []


class CustomParam(CustomBaseModel):
    grid_point: List[List[int]] = []


class DonutHoleParam(BaseModel):
    circle: CircleData = CircleData()
    outside_len: int = 0
    min_radius: int = 0
    max_radius: int = 0


class TemplateMatchingParam(BaseModel):
    """テンプレートマッチングの設定データ(廃止予定…)"""
    input_color: str = 'gray'
    template_area: list = [0, 0, 10, 10]
    min_angle: float = -5.0
    max_angle: float = 5.0
    step: float = 1.0
    compression_ratio: float = 1.0
    use_mask: bool = False
    mask_polygon: List[List[List[int]]] = []
    score_th: float = 0.0


# class TrayMarker(BaseModel):
#     """パワトレトレイ専用のパラメータクラス"""
#     marker_color: str = 'blue'

class ValueInfo(BaseModel):
    label: str = ''
    value: float = 0.0


# ===============================================================================
# NOTE: キャリブレーション関連
# ===============================================================================


class PositionData(BaseModel):
    """位置情報の基本データ"""
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    r: float = 0.0


class BasePositionData(BaseModel):
    """相対基準位置情報"""
    robot_position: PositionData = PositionData()
    image_position: PositionData = PositionData()


class CalibrationMapData(BaseModel):
    """キャリブレーションマップ"""
    teaching_robot_position: PositionData = PositionData()
    teaching_image_position: PositionData = PositionData()
    image_position: list = []
    robot_position: list = []


class MatrixData(BaseModel):
    """カメラ行列の情報"""
    matrix: list = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]
    x_rmse: float = 0.0
    y_rmse: float = 0.0

    @validator('matrix')
    def check_matrix(cls, v):
        """カメラ行列が3x3出ない場合エラー"""
        h, w = np.array(v).shape[:2]
        if h != 3 or w != 3:
            raise ValueError('Please input 3x3 matrix', v)
        return v


class RotationCenterData(BaseModel):
    """回転中心の情報"""
    center: PositionData = PositionData()
    rmse: float = 0.0


# ===============================================================================
# NOTE: まとめクラス
# ===============================================================================
class ImageProcParamModel(BaseModel):
    filter: PreProcList = PreProcList()  # NOTE: そのうちpreproc_dataをこっちへ移管
    matching: MatchingParam = MatchingParam()
    blob_detection: BlobDetectionParam = BlobDetectionParam()
    circle_detection: CircleDetectionParam = CircleDetectionParam()
    color_detection: ColorDetectionParam = ColorDetectionParam()
    line_detection: CornerDetectionParam = CornerDetectionParam()
    tray_detection: TrayDetectionParam = TrayDetectionParam()
    workpiece_count: WorkPieceCountParam = WorkPieceCountParam()
    region_data: RegionData = RegionData()  # NOTE: 検査領域設定
    custom_data: CustomParam = CustomParam()  # NOTE: カスタム領域 # NOTE: これ使ってたっけ
    donut_data: DonutHoleParam = DonutHoleParam()

    # NOTE: どっかのタイミングで廃止したい
    preproc_data: PreProcList = PreProcList()  # NOTE: 将来的にfilterに名前変更予定
    template_matching: TemplateMatchingParam = TemplateMatchingParam()  # NOTE: 廃止予定

    # NOTE: 第2設定, 将来的には別で管理
    filter2: PreProcList = PreProcList()
    matching2: MatchingParam = MatchingParam()
    blob_detection2: BlobDetectionParam = BlobDetectionParam()
    circle_detection2: CircleDetectionParam = CircleDetectionParam()

    # NOTE: 第3設定, 将来的には別で管理
    filter3: PreProcList = PreProcList()
    matching3: MatchingParam = MatchingParam()
    blob_detection3: BlobDetectionParam = BlobDetectionParam()
    circle_detection3: CircleDetectionParam = CircleDetectionParam()

    value_list: List[ValueInfo] = []


class CalibrationDataModel(BaseModel):
    base_position: BasePositionData = BasePositionData()
    calibration_map: CalibrationMapData = CalibrationMapData()
    matrix_data: MatrixData = MatrixData()
    rotation_center: RotationCenterData = RotationCenterData()
    offset_vector: List[float] = [0.0, 0.0]


if __name__ == '__main__':
    data = dict()
    data.update(dict(blob=BlobDetectionParam().dict()))
    data.update(dict(matching=TemplateMatchingParam().dict()))
    data.update(dict(line=LineDetectionParam().dict()))
    data.update(dict(color=ColorDetectionParam().dict()))
    data.update(dict(corner=CornerDetectionParam().dict()))
    print(data)
