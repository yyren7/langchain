# ===============================================================================
# Name      : read_calibration_sheet.py
# Version   : 1.0.0
# Brief     :
# Time-stamp: 2023-11-06 16:09
# Copyirght 2023 Sugino Tatsuya
# ===============================================================================
import openpyxl
import io
import os
import shutil

def getCalibrationNum(book_name: str, sheet_name: str) -> dict:
    """Bitのキーワードを取得"""
    REF_ROW_NO = 2  # 1行
    REF_COL_NO = 2  # B列

    with open(book_name, "rb") as f:
        in_mem_file = io.BytesIO(f.read())

    wb = openpyxl.load_workbook(in_mem_file, read_only=True,
                                keep_vba=True, data_only=True)
    sheet = wb[sheet_name]
    dict_calib_data = {}
    # 行走査
    for row_i in range(0, sheet.max_row):
        calib_num = sheet.cell(row=row_i + REF_ROW_NO, column=REF_COL_NO)  # 使用するキャリブレーション番号
        # 値があれば
        if calib_num.value is not None:
            # 連想配列作成(Word要タグのID)
            dict_calib_data[row_i] = calib_num.value
    wb.close()
    return dict_calib_data


def getCalibrationConfig(book_name: str, sheet_name: str) -> dict:
    """Bitのキーワードを取得""" 
    # 端から1数え
    REF_ROW_NO = 2  #2行目から
    REF_COL_NO = 5  #E列から
    MAX_COL_NO = 23  # W列 = 21 + 2

    with open(book_name, "rb") as f:
        in_mem_file = io.BytesIO(f.read())

    wb = openpyxl.load_workbook(in_mem_file, read_only=True,
                                keep_vba=True, data_only=True)
    sheet = wb[sheet_name]
    dict_calib_data = {}

    # 行走査
    for row_i in range(0, sheet.max_row):
        # 連想配列作成 2d-dict
        dict_calib_data[row_i] = {}
        # 列走査
        for col_i in range(0, MAX_COL_NO):
            calib_cfg = sheet.cell(row=row_i + REF_ROW_NO, column=REF_COL_NO + col_i)
            # 値があれば
            if (calib_cfg.value is not None):
                # 連想配列作成
                dict_calib_data[row_i][col_i] = calib_cfg.value
            else:
                # 連想配列作成
                dict_calib_data[row_i][col_i] = None

    wb.close()
    return dict_calib_data


class CustomCalibrationParam():
    __version__ = '1.0.0'

    def __init__(self, excel_path: str):
        super().__init__()
        self.check_file(excel_path)
        self.load_excel(excel_path)

    def load_excel(self, path: str):
        """エクセルファイルから読み込み"""
        # NOTE:
        self.calib_num = getCalibrationNum(path, sheet_name="CALIB_CFG")
        self.calib_config = getCalibrationConfig(path, sheet_name="CALIB_CFG")

    def check_file(self, path):
        if os.name == "nt":
            return
        else:
            if os.path.exists(os.path.dirname(path)):
                return
            else:
                shutil.copytree("./config", os.path.dirname(path))
        return


if __name__ == '__main__':
    # NOTE：シートパス
    sheet_path = "Caliblation_Get_ParamSheet.xlsx"
    # NOTE:インスタンス
    ccp = CustomCalibrationParam(sheet_path)
    _data = [0] * 20
    flow_num = 0  # フロー番号指定
    print("Flow No." + str(flow_num), "\n" + "Calib No." + str(ccp.calib_num[flow_num]))
    print("Calib cfg list", ccp.calib_config[flow_num])
    # NOTE：要素確認
    for i, val in enumerate(ccp.calib_config[flow_num].items()):
        print("val",val)
        tag = val[1] #(idx,要素)
        if tag == "Xpos":
            print("index={} X Algin".format(i))
            _data[i] = + 100  # 仮の補正結果
        elif tag == "Ypos":
            print("index={} Y Algin".format(i))
            _data[i] = + 200  # 仮の補正結果

    print("Algin Result", _data)
