# ===============================================================================
# Name      : param_basemodel.py
# Version   : 1.0.0
# Brief     : 設定管理用のベースモデル
# Time-stamp: 2023-04-18 18:02
# Copyirght 2023 Hiroya Aoyama
# ===============================================================================
from pydantic import BaseModel
from typing import List


class SaveImageConfig(BaseModel):
    original_ok_image: bool = False
    processed_ok_image: bool = False
    original_ng_image: bool = False
    processed_ng_image: bool = False
    original_data_format: str = 'bmp'
    processed_data_format: str = 'jpg'
    original_image_size: str = 'full'
    processed_image_size: str = 'vga'


class SecurityConfig(BaseModel):
    password: str = 'pass'


class NetworkConfig(BaseModel):
    ip: str = '192.168.0.100'
    port: str = '10000'


class InspectionConfig(BaseModel):
    p_number: int = 0  # NOTE: Program Number
    c_number: int = 0  # NOTE: Config Number
    m_number: int = 0  # NOTE: Model Number
    modelname: str = ''


class ModelTable(BaseModel):
    """モデルテーブル"""
    use_multi_model: bool = False
    inspection_config: List[InspectionConfig] = []


class CorrectionConfig(BaseModel):
    correction_method: str = 'absolute'


class OptionModel(BaseModel):
    image_save: SaveImageConfig = SaveImageConfig()
    security: SecurityConfig = SecurityConfig()
    network: NetworkConfig = NetworkConfig()
    model_table: ModelTable = ModelTable()
    correction_config: CorrectionConfig = CorrectionConfig()


if __name__ == '__main__':
    pass
