# ===============================================================================
# Name      : main.py
# Version   : 1.0.0
# Brief     : メインのプログラム
# Time-stamp: 2024-03-07 13:48
# Copyirght 2024 Sugino Tatsuya
# ===============================================================================
import os
from PySide2 import QtWidgets
from gui.window_controller import WindowController
from gui.pyside_css import pyside_main_css
from importlib import import_module
from ui_settings import (
    PRG_VERSION,
    FULL_SCREEN_FLAG,
    AUTO_START_MODE,
)
from ui_settings import getDiskPath
from module.component.ui_path_h import (
    MAIN_WINDOW_UI,
    M_CALIBRATION_PAGE_UI,
    FCP_PAGE_UI,
)


# NOTE: 初期設定に必要なデータを読込
INITIAL_DATA = getDiskPath()
DISK_DIR = INITIAL_DATA.disk_dir
CONFIG_DIR = INITIAL_DATA.config_dir

# NOTE:FCP GUI用
print(INITIAL_DATA)
FCPPageController = getattr(import_module(
    f'module.component.page.{INITIAL_DATA.program_name}.fcp_v_page'), 'FCPPageController')


# NOTE: タイトル
TITLE = 'FCP-V : ' + PRG_VERSION


class MainWindow(WindowController):
    def __init__(self):
        super().__init__(MAIN_WINDOW_UI, TITLE,
                         pg_type=f'({INITIAL_DATA.program_name})')
        self.actionCalib: QtWidgets.QAction
        self.actionExit: QtWidgets.QAction
        # NOTE: スタイルシートの適用
        self.setStyleSheet(pyside_main_css())

    def init_process(self):
        # NOTE: ファイル生成
        self.set_manager(CONFIG_DIR)
        # NOTE: カメラ接続
        if not self.set_camera():
            exit(-1)
        self.add_pages()
        self.signal_connect()

    def add_pages(self):
        """ページの追加"""
        self.stackedWidget: QtWidgets.QStackedWidget
        self.p0: QtWidgets.QWidget

        # # NOTE: ページとコントローラーを紐づけ
        self.p0 = FCPPageController(stacked_widget=self.stackedWidget,
                                    ui_path=FCP_PAGE_UI,
                                    #camera=self.camera,
                                    camera=None,
                                    path_manager=self.pm,
                                    file_handler=self.fh
                                    )

        self.connect_action()

    def connect_action(self):
        self.actionExit.triggered.connect(lambda: self.close())

    def signal_connect(self) -> None:
        self.p0.error_signal.connect(self.emit_error_log)

    def process_on_exit(self):
        pass

    # @QtCore.Slot(str)
    def emit_error_log(self, msg: str):
        """
        各コントローラからエラーがemitされる
        エラー内容をUSBに保存
        保存先は/media/usb/VAST/vast_error.log
        """
        # NOTE: 時刻を取得
        time_now = self.fh._get_current_time()
        msg_ = f'[Time] {time_now}\n{msg}\n'
        log_file_path = os.path.join(DISK_DIR, 'fcpv_error.log')
        self.fh._write_file(path=log_file_path, filetype='log',
                            data=dict(message=msg_), mode='a', allow_user=True)


if __name__ == '__main__':
    app = QtWidgets.QApplication()
    window = MainWindow()
    window.apply_qt_material(app)
    window.init_process()
    window.show()

    if FULL_SCREEN_FLAG:
        window.showFullScreen()
    else:
        if os.name != 'nt':
            window.showMaximized()
    app.exec_()
