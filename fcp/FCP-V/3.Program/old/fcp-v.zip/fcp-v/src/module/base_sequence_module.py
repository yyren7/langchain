# ===============================================================================
# Name      : base_sequence_module.py
# Version   : 1.0.0
# Brief     : シーケンスベース関数
# Time-stamp:2024-02-07 11:08
# Copyirght 2023 Tatsuya Sugino
# ===============================================================================
import os
# import sys
# import numpy as np
# from typing import Any, Optional
# from pydantic import BaseModel

try:
    from logger import setup_logger
    logger = setup_logger(__name__)
except Exception:
    from logging import getLogger
    logger = getLogger(__name__)

from .param.base_param.base_sequence_param import SequenceParameter


class BaseSequenceModule(SequenceParameter):
    def __init__(self) -> None:
        super().__init__()
        # カレントディレクトリパス取得
        self.current_dir = os.path.dirname(os.path.abspath(__file__))
        # SequenceParameter.__init__(self)

    # NOTE:パラメータの初期化

    def resetSequenceParameter(self):
        SequenceParameter.__init__(self)

    # ===============================================================================
    # NOTE: シーケンス更新メソッド
    # ===============================================================================
    # NOTE:指定フェーズのインクリメント

    def incrementPhase(self, key: str):
        current_value = getattr(self.phase, key)  # getattr()関数を使ってアクセス
        setattr(self.phase, key, current_value + 1)  # setattr()関数を使って値を変更

    # NOTE:指定フェーズのリセット
    def resetPhase(self, key: str):
        setattr(self.phase, key, 0)  # setattr()関数を使って値を変更

    # NOTE:指定フェーズの更新
    def updatePhase(self, key: str, val: any):
        setattr(self.phase, key, val)  # setattr()関数を使って値を変更

    # NOTE:指定フェーズの確認
    def checkPhase(self, key: str, val: str):
        if getattr(self.phase, key) == val:
            return True
        else:
            return False

    def getPhase(self):
        key = "n_inspection"
        return getattr(self.phase, key)

    # NOTE:指定フラグの更新
    def updateFlag(self, key: str, val: bool):
        setattr(self.flag, key, val)  # setattr()関数を使って値を変更

    # NOTE:指定フラグの取得
    def checkFlag(self, key: str):
        return getattr(self.flag, key)

    # NOTE:ステータスの更新

    def updateStatus(self, val: str):
        key = "str_vs_status"
        setattr(self.string, key, val)  # setattr()関数を使って値を変更

    # NOTE:ステータスの確認
    def checkStatus(self, val: str):
        key = "str_vs_status"
        if getattr(self.string, key) == val:
            return True
        else:
            return False

    # NOTE:ステータスの取得
    def getStatus(self):
        key = "str_vs_status"
        return getattr(self.string, key)

    # NOTE:BusyTimeの更新
    def updateBusyTime(self, val: str):
        key = "custom_busy_time"
        setattr(self.custom, key, val)  # setattr()関数を使って値を変更

    # NOTE:BusyTimeの確認
    def getBusyTime(self):
        key = "custom_busy_time"
        return getattr(self.custom, key)


if __name__ == "__main__":
    bsc = BaseSequenceModule()
    bsc.incrementPhase(key="n_move")
    print(bsc.phase.n_move)
    bsc.incrementPhase(key="n_move")
    print(bsc.phase.n_move)
