# VASTビジョン操作手順マニュアル

## 目次

- [VASTビジョン操作手順マニュアル](#vastビジョン操作手順マニュアル)
  - [目次](#目次)
  - [1.プログラムの切り替え](#1プログラムの切り替え)
  - [2.検査設定ページに移動](#2検査設定ページに移動)
  - [3.基準画像の登録](#3基準画像の登録)
  - [4.画像処理の設定](#4画像処理の設定)
    - [4.1 位置補正（共通設定）](#41-位置補正共通設定)
      - [4.1.1 角度範囲(ANGLE RANGE)](#411-角度範囲angle-range)
      - [4.1.2 圧縮率(Compression Ratio)](#412-圧縮率compression-ratio)
      - [4.1.3 スコア閾値(Score Thresh)](#413-スコア閾値score-thresh)
    - [4.2 検査範囲の設定（共通設定）](#42-検査範囲の設定共通設定)
    - [4.3 接着剤塗布検査の設定](#43-接着剤塗布検査の設定)
  - [5.検査結果の確認](#5検査結果の確認)
  - [6.モデル切り替え設定](#6モデル切り替え設定)
  - [7.画像保存設定](#7画像保存設定)
  - [8.その他検査](#8その他検査)
    - [8.1 マグネット検査](#81-マグネット検査)
      - [8.1.1 検査内容](#811-検査内容)
      - [8.1.2 基準位置の設定](#812-基準位置の設定)
      - [8.1.3 マグネット検出の設定](#813-マグネット検出の設定)
      - [8.1.4 検査閾値の設定](#814-検査閾値の設定)
      - [8.1.5 検査画面](#815-検査画面)
    - [8.2 カシメ検査](#82-カシメ検査)
      - [8.1.1 検査内容](#811-検査内容-1)
      - [8.1.2 基準位置の設定](#812-基準位置の設定-1)
      - [8.1.3　エッジ間計測](#813エッジ間計測)
      - [8.2.4 検査閾値の設定](#824-検査閾値の設定)



## 1.プログラムの切り替え

１．`Selector`の画面の中にある`Program Selector`を起動してください。

![alt text](image.png)

２．起動すると、以下のように使用できるプログラムの一覧が表示されます。
使用したい検査を選択してください。
- 接着剤塗布検査：`Color Inspection v2`
- カシメ検査：`NIST Caulking Inspection`
- マグネット貼付位置検査：`NIST Gel Inspection`

![alt text](image-1.png)

<div style="page-break-before:always"></div>

## 2.検査設定ページに移動
１．選択を終えたら`Selector`から`RobotVision`の起動してください。
左上のマークをクリックし、`Model Setting`をクリックしてください。

![alt text](image-2.png)

２．モデルページに遷移後、最初の一度目は設定が存在しないため、以下の画面がでます。
OKをクリックしてください。

![alt text](image-3.png)

<div style="page-break-before:always"></div>

## 3.基準画像の登録
１．モデル名を登録します。
`Create New`を選択してスパナアイコンのボタンを押してください。

![alt text](image-21.png)

２．キーボードボタンをクリックして名前を設定します。設定できたら`APPLY`ボタンを押してください。
![alt text](image-22.png)

３．モデル名が反映されることを確認します。

![alt text](image-23.png)

４．`CAPTURE`ボタンを押して現在の画像を取得してください。
基準となるワークが撮影出来たら`SET MASTER`ボタンを押してください。
基準画像が登録されます。

![alt text](image-5.png)


<div style="page-break-before:always"></div>

## 4.画像処理の設定
１．`2.Image Processing Setting`選択してください。

![alt text](image-4.png)

２．次のセクション以降を参考に各種パラメータの設定をしてください。

<div style="page-break-before:always"></div>

### 4.1 位置補正（共通設定）

`Method List`から `Template Matching`を選択してください。

- 赤枠：テンプレートエリア。マウスで設定後、`SET RECT`のボタンクリックで設定。
- 青枠：検査エリア。テスト時のみ有効。<span style="color: red; ">検査範囲の設定は別の設定画面で実施。</span>

![alt text](image-17.png)

登録を終えたら、マッチングの各種パラメータの設定を実施してください。

<div style="page-break-before:always"></div>

#### 4.1.1 角度範囲(ANGLE RANGE)
- 検出する角度範囲を設定できます
- 検出する角度範囲を広くしたり、分解能を小さくすると処理の時間が長くなります。
- 検出する角度を0度にする場合は0.0, 0.0, 1.0 と設定してください。
![alt text](image-15.png)

<div style="page-break-before:always"></div>

#### 4.1.2 圧縮率(Compression Ratio)
- テンプレート画像/入力画像の圧縮度が設定できます。
- 圧縮度が低いほど、情報量が減り、処理時間が短くなりますが検出精度が落ちます。

![alt text](image-18.png)

#### 4.1.3 スコア閾値(Score Thresh)
- マッチングスコアがこのスコアを下回った場合、ワークがない（NG）判定になります。

![alt text](image-20.png)

<div style="page-break-before:always"></div>

### 4.2 検査範囲の設定（共通設定）
`Method List`から `Search Area`を選択してください。

- 検査エリアを限定するときは、`Enable Limit Inspection Area`をチェックしてください。
- マウスで検査エリアを囲った後`SET RECT`をクリックしてください。


![alt text](image-19.png)

<div style="page-break-before:always"></div>

### 4.3 接着剤塗布検査の設定

ここでは接着剤塗布検査の設定の例を示します。
マグネット位置検査、カシメ検査はこちらを参考にしてください。

[7.その他検査](#7その他検査)

`Method List`から`Color Detection`を選択してください。
`REGION`ボタンをクリックしてください。

![alt text](image-6.png)


検査する領域をマウスで囲って`ADD`ボタンをクリックしてください。
設定した領域が追加されます。

![alt text](image-7.png)

さらに検査領域を追加する場合は、マウスで領域を囲った後`Polygon ID`に数値が選択していない状態でADDをクリックしてください。
数値が選択された状態で`ADD`ボタンをクリックすると選択されている領域が上書きされます。

| 領域が選択されているとき（上書き追加） | 領域選択されていないとき（新規追加） |
| -------------------------------------- | ------------------------------------ |
| ![alt text](image-8.png)               | ![alt text](image-9.png)             |


<div style="page-break-before:always"></div>

領域の設定が終わると元画面にIDとグラフが反映されます。

領域番号を指定して以下の設定を行います。
- 色空間の選択（RGB, HSV, Lab）
- 抽出する色のレンジを指定
- 判定閾値（ピクセル数）の上下限値を指定
  
![alt text](image-10.png)


検査設定を結果を見たい場合は`TEST`ボタンをクリックしてください。
以下のデータが表示されます。
- `Rate`: 指定した領域に対する抽出した色の割合
- `Pixel`: 指定した領域の中の抽出した色のピクセル数
- `Pixel in Region`: 指定した領域のピクセル数

![alt text](image-14.png)

また、以下の画像を確認することができます。

| result                    | binary                    | region                    |
| ------------------------- | ------------------------- | ------------------------- |
| 抽出部分の輪郭を描画      | 抽出した色を白で表示      | 指定した領域を拡大        |
| ![alt text](image-11.png) | ![alt text](image-12.png) | ![alt text](image-13.png) |


領域ごとの設定が終わったら`APPLY`をクリックしてください。

<div style="page-break-before:always"></div>

## 5.検査結果の確認
全部の設定が完了したら`2.Image Processing Setting`にある`SAVE`ボタンをクリックして、パラメータを保存します。保存が完了したら、`3.Reference points Registration`を選択してRUNボタンを押してください。

![alt text](image-27.png)

登録した画像に対して実施した検査の結果が表示されます。

![alt text](image-25.png)

<div style="page-break-before:always"></div>

現在の画像に対して検査を実施する場合は、`4.Test with Sample Work`を選択してください。
`CAPTURE`ボタンは撮像して画像を取得、`LOAD`はディスクにある保存された画像を取得することができます。

`TEST RUN`ボタンを押すと撮影もしくは読み込んだ画像に対して検査を実施することができます。

![alt text](image-26.png)

接着剤が塗布されていないワーク

![alt text](image-28.png)

<div style="page-break-before:always"></div>

## 6.モデル切り替え設定
一つのカメラで複数の設定を使用する際に使います。

（例．接着剤の箇所が6か所と8か所のワークが混流する場合など）

１．左上のマークをクリックし、`Option`をクリックしてください。

![alt text](image-30.png)

２．`Model Table`を選択し、以下の設定をしてください。
- `Use Model Table`にチェックを入れる。
- `ADD`ボタンをクリックして行を増やす。それぞれ番号を振り、モデル名を設定する。
- `SAVE`ボタンをクリックして設定を保存する。

![alt text](image-29.png)

<div style="page-break-before:always"></div>

## 7.画像保存設定
検査画像の保存設定ができます。
解像度と画像形式によって保存時間が異なりますので、以下を参考にしてください。
※画像保存が完了するまで次の検査を実施できません。
※表記の秒数は参考値です。

| 解像度/拡張子 | .jpg | .bmp |
| ------------- | ---- | ---- |
| 640x480       | 0.1s | 0.5s |
| 1440x1080     | 0.5s | 3.0s |
| 2520x2080     | 1.0s | 8.0s |

![alt text](image-38.png)

<div style="page-break-before:always"></div>

## 8.その他検査

###  8.1 マグネット検査

#### 8.1.1 検査内容

- マスター登録した画像に対して、基準位置とマグネットの距離`du'`を計算
- 検査画像に対して、基準位置とマグネットの距離`du`を計算
- 相対位置ずれ量`|du-du'|`を計算し、規定の量以下であればOK、以上であればNGの判定を行う

![alt text](image-34.png)

<div style="page-break-before:always"></div>

#### 8.1.2 基準位置の設定 
ワークの位置がずれても、基準位置を追従できるようにテンプレート画像を登録します。
`Method List`から `Template Matching`を選択してください。
詳細な設定は[4.1 位置補正（共通設定）](#41-位置補正共通設定)を参考にしてください
![alt text](image-31.png)

<div style="page-break-before:always"></div>

#### 8.1.3 マグネット検出の設定
マグネットの中心を検出するための二値化およびブロブ抽出のフィルター値を設定します。
`Method List`から `Blob Detection`を選択してください。

- `Num of Blob`を2に設定してください（マグネットの個数）
- マグネット二つのみ検出されるように設定値を調整してください。（設定の項目は以下を参照）
- https://docs.google.com/presentation/d/1bEq7IyJcgpy4B7ccXQqHPEkXbD57KDzz/edit#slide=id.p14

![alt text](image-37.png)

<div style="page-break-before:always"></div>

結果画面

![alt text](image-36.png)

<div style="page-break-before:always"></div>

#### 8.1.4 検査閾値の設定
マスター登録した画像と比較した、相対的な位置・角度ずれ量に対してどこまでOKの判定とするかの閾値を設定します。
`Method List`から `Value List`を選択してください。
行を追加して、以下のラベルを追加し、数値を入力してください。

- angle_th: マグネットの角度がそれぞれ何度以下であればOKとするかの閾値
- x_pixel_th: マグネットの相対位置ずれ量X（横軸）が何ピクセル以下であればOKとするかの閾値
- y_pixel_th: マグネットの相対位置ずれ量Y（縦軸）が何ピクセル以下であればOKとするかの閾値

![alt text](image-39.png)

<div style="page-break-before:always"></div>

#### 8.1.5 検査画面
- 上段：検査結果の描画画像
- 下段左：マスター登録した画像
- 下段右：現在の画像

![alt text](image-33.png)

<div style="page-break-before:always"></div>

###  8.2 カシメ検査

#### 8.1.1 検査内容

カシメがされているかされていないか、計測します。

![alt text](image-41.png)

<div style="page-break-before:always"></div>

#### 8.1.2 基準位置の設定 
ワークの位置がずれても、基準位置を追従できるようにテンプレート画像を登録します。
`Method List`から `Template Matching`を選択してください。
詳細な設定は[4.1 位置補正（共通設定）](#41-位置補正共通設定)を参考にしてください。

![alt text](image-40.png)

<div style="page-break-before:always"></div>

#### 8.1.3　エッジ間計測
両端のカシメ後の距離を計測します。
以下のように計測領域を設定します。

![alt text](image-43.png)

最初に`Pair1-1`を選択して、検査領域をマウスで設定します。
その後、`ADD`ボタンをクリックしていただき、`Box Index`から0を選択して下さい。

![alt text](image-45.png)

次にパラメータを設定します。
今回の例では、上から下に対して計測するため、下記の設定にします。
- `Scan Direction`(スキャン方向)を`Down`に
- `Contrast`（色の変化、今回は白から黒）を`high->low`

また、全領域に対して、以下の設定は共通です。
- `Point`は1にすること
- `Peak`は`maximum peak`にすること

設定が終わったら`Update`ボタンをクリックしてください。

![alt text](image-46.png)

`TEST`ボタンをクリックすると結果が確認できます。
以上の設定をPair1-1, 1-2, 2-1, 2-2に対して実施してください。

![alt text](image-47.png)

<div style="page-break-before:always"></div>

#### 8.2.4 検査閾値の設定
カシメ後のエッジ間距離がどこまで開いていればOKの判定とするかの閾値を設定します。
`Method List`から `Value List`を選択してください。
行を追加して、以下のラベルを追加し、数値を入力してください。

- min_thresh1, max_thresh1<br>
  Pair1-1, 1-2間のエッジ距離に対する閾値（ピクセル）
- min_thresh2, max_thresh2<br>
  Pair2-1, 2-2間のエッジ距離に対する閾値（ピクセル）
- angle_thresh1, angle_thresh2<br>
  本検査では不使用。1.0で登録しておくこと。

![alt text](image-48.png)